"""
Analisi Scaling Metabolico vs Strutturale in NSCLC
==================================================

Dataset: Brummer & Savage (2021) - Frontiers in Ecology and Evolution
Repository: https://github.com/alexbbrummer/NSCLC_metabolic_scaling

Obiettivo: Verificare se la divergenza tra esponente strutturale (β̄) 
e esponente metabolico (θ) aumenta con la malignità.

Autore: Claude AI
Data: 2026-01-10
"""

import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

# =============================================================================
# 1. CARICAMENTO E PREPARAZIONE DATI
# =============================================================================

def load_and_prepare_data(filepath):
    """Carica il file Excel e prepara i dati per l'analisi."""
    
    # Carica i dati dalla sheet principale
    df = pd.read_excel(filepath, sheet_name='Tumor vessel')
    
    print("=" * 60)
    print("CARICAMENTO DATI")
    print("=" * 60)
    print(f"\nColonne disponibili: {list(df.columns)}")
    print(f"Righe totali: {len(df)}")
    print(f"Pazienti unici: {df['patient'].nunique()}")
    
    # Aggrega per paziente
    patient_data = df.groupby('patient').agg({
        'beta.ave': 'mean',
        'gamma.ave': 'mean',
        'MTV (cc)': 'first',
        'SUVmax': 'first',
        'GTV (cc)': 'first',
        'Histology': 'first'
    }).reset_index()
    
    # Filtra dati validi
    valid_data = patient_data.dropna(subset=['MTV (cc)', 'SUVmax'])
    valid_data = valid_data[(valid_data['MTV (cc)'] > 0) & (valid_data['SUVmax'] > 0)]
    
    print(f"\nPazienti con dati validi: {len(valid_data)}")
    print(f"\nTipi istologici:")
    print(valid_data['Histology'].value_counts())
    
    return valid_data


# =============================================================================
# 2. CALCOLO ESPONENTE METABOLICO θ
# =============================================================================

def calculate_theta(data):
    """
    Calcola l'esponente metabolico θ dalla relazione SUVmax ~ MTV^θ.
    
    Teoria: SUVmax = k * MTV^θ
    In log-log: log(SUVmax) = θ * log(MTV) + log(k)
    """
    
    print("\n" + "=" * 60)
    print("CALCOLO ESPONENTE METABOLICO θ")
    print("=" * 60)
    
    # Calcolo θ globale
    log_mtv = np.log(data['MTV (cc)'])
    log_suv = np.log(data['SUVmax'])
    
    slope, intercept, r, p, se = stats.linregress(log_mtv, log_suv)
    print(f"\nθ globale (tutti i pazienti):")
    print(f"  θ = {slope:.4f} ± {se:.4f}")
    print(f"  R² = {r**2:.4f}")
    print(f"  p-value = {p:.2e}")
    
    # Calcolo θ per gruppo istologico
    theta_by_histology = {}
    
    print("\n--- θ per tipo istologico ---")
    for histology in data['Histology'].unique():
        subset = data[data['Histology'] == histology]
        if len(subset) >= 3:
            log_m = np.log(subset['MTV (cc)'])
            log_s = np.log(subset['SUVmax'])
            s, i, r, p, se = stats.linregress(log_m, log_s)
            theta_by_histology[histology] = s
            print(f"\n{histology} (n={len(subset)}):")
            print(f"  θ = {s:.4f} ± {se:.4f}")
            print(f"  R² = {r**2:.4f}")
    
    return theta_by_histology


# =============================================================================
# 3. CALCOLO DIVERGENZA Δ
# =============================================================================

def calculate_divergence(data, theta_by_histology):
    """
    Calcola la divergenza Δ = |β̄ - θ| per ogni paziente.
    """
    
    print("\n" + "=" * 60)
    print("CALCOLO DIVERGENZA Δ = |β̄ - θ|")
    print("=" * 60)
    
    data = data.copy()
    
    # Mappa θ su ogni paziente in base all'istologia
    data['theta'] = data['Histology'].map(theta_by_histology)
    
    # β̄ è già presente come beta.ave
    data['beta_bar'] = data['beta.ave']
    
    # Calcola divergenza
    data['delta'] = np.abs(data['beta_bar'] - data['theta'])
    
    # Classificazione semplificata
    data['tumor_type'] = data['Histology'].apply(
        lambda x: 'ADC' if 'Adenocarcinoma' in x else ('SCC' if 'Squamous' in x else 'NSCLC')
    )
    
    # Rimuovi NaN
    analysis_data = data.dropna(subset=['delta'])
    
    print(f"\nPazienti analizzabili: {len(analysis_data)}")
    print(analysis_data[['patient', 'Histology', 'tumor_type', 'beta_bar', 'theta', 'delta']].head(10))
    
    return analysis_data


# =============================================================================
# 4. ANALISI STATISTICA
# =============================================================================

def statistical_analysis(data):
    """
    Esegue l'analisi statistica confrontando ADC vs SCC.
    """
    
    print("\n" + "=" * 60)
    print("ANALISI STATISTICA")
    print("=" * 60)
    
    # Filtra solo ADC e SCC
    adc_scc_data = data[data['tumor_type'].isin(['ADC', 'SCC'])]
    
    # Statistiche descrittive
    results = []
    print("\n--- Statistiche descrittive ---")
    
    for group in ['ADC', 'SCC']:
        subset = adc_scc_data[adc_scc_data['tumor_type'] == group]
        if len(subset) > 0:
            mean_delta = subset['delta'].mean()
            std_delta = subset['delta'].std()
            n = len(subset)
            sem = std_delta / np.sqrt(n)
            mean_beta = subset['beta_bar'].mean()
            mean_theta = subset['theta'].mean()
            
            results.append({
                'Gruppo': group,
                'N': n,
                'beta_bar_medio': mean_beta,
                'theta_medio': mean_theta,
                'delta_medio': mean_delta,
                'delta_SD': std_delta,
                'delta_SEM': sem
            })
            
            print(f"\n{group} (n={n}):")
            print(f"  β̄ medio = {mean_beta:.4f}")
            print(f"  θ medio = {mean_theta:.4f}")
            print(f"  Δ medio = {mean_delta:.4f} ± {std_delta:.4f} (SD)")
    
    results_df = pd.DataFrame(results)
    
    # Test statistici
    print("\n--- Test statistici: Δ(SCC) > Δ(ADC)? ---")
    
    adc_delta = adc_scc_data[adc_scc_data['tumor_type'] == 'ADC']['delta']
    scc_delta = adc_scc_data[adc_scc_data['tumor_type'] == 'SCC']['delta']
    
    # Test t
    t_stat, p_two_tailed = stats.ttest_ind(scc_delta, adc_delta)
    p_one_tailed = p_two_tailed / 2 if t_stat > 0 else 1 - p_two_tailed / 2
    
    print(f"\nTest t indipendente:")
    print(f"  t-statistic = {t_stat:.4f}")
    print(f"  p-value (two-tailed) = {p_two_tailed:.6f}")
    print(f"  p-value (one-tailed, SCC > ADC) = {p_one_tailed:.6f}")
    
    # Mann-Whitney U
    u_stat, p_mw = stats.mannwhitneyu(scc_delta, adc_delta, alternative='greater')
    print(f"\nMann-Whitney U test (SCC > ADC):")
    print(f"  U-statistic = {u_stat:.4f}")
    print(f"  p-value = {p_mw:.6f}")
    
    # Effect size
    pooled_std = np.sqrt((adc_delta.std()**2 + scc_delta.std()**2) / 2)
    cohens_d = (scc_delta.mean() - adc_delta.mean()) / pooled_std
    print(f"\nEffect size (Cohen's d) = {cohens_d:.4f}")
    
    # Conclusione
    print("\n--- Conclusione ---")
    alpha = 0.05
    if p_one_tailed < alpha:
        print(f"RIGETTO H0: Δ(SCC) > Δ(ADC) con p = {p_one_tailed:.6f}")
        print("L'ipotesi è CONFERMATA: la divergenza aumenta con la malignità")
    else:
        print(f"NON RIGETTO H0: p = {p_one_tailed:.6f}")
    
    return results_df, {
        't_stat': t_stat,
        'p_t_one': p_one_tailed,
        'u_stat': u_stat,
        'p_mw': p_mw,
        'cohens_d': cohens_d
    }


# =============================================================================
# 5. VISUALIZZAZIONE
# =============================================================================

def create_plots(data, output_dir='./'):
    """
    Crea i plot per la visualizzazione dei risultati.
    """
    
    print("\n" + "=" * 60)
    print("GENERAZIONE PLOT")
    print("=" * 60)
    
    # Filtra ADC e SCC
    plot_data = data[data['tumor_type'].isin(['ADC', 'SCC'])]
    
    # Calcolo statistiche
    groups = ['ADC', 'SCC']
    means = []
    stds = []
    sems = []
    ns = []
    
    for group in groups:
        subset = plot_data[plot_data['tumor_type'] == group]['delta']
        means.append(subset.mean())
        stds.append(subset.std())
        sems.append(subset.std() / np.sqrt(len(subset)))
        ns.append(len(subset))
    
    # === PLOT 1: Bar plot + Scatter ===
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    ax1 = axes[0]
    colors = ['#4CAF50', '#E53935']
    x = np.arange(len(groups))
    bars = ax1.bar(x, means, yerr=sems, capsize=8, color=colors, 
                   edgecolor='black', linewidth=1.5, alpha=0.8)
    
    # Singoli data points
    for i, group in enumerate(groups):
        subset = plot_data[plot_data['tumor_type'] == group]['delta']
        ax1.scatter([i] * len(subset), subset, color='black', alpha=0.4, 
                    zorder=5, s=40)
    
    ax1.set_ylabel('Divergenza Δ = |β̄ - θ|', fontsize=12, fontweight='bold')
    ax1.set_xlabel('Tipo Istologico', fontsize=12, fontweight='bold')
    ax1.set_xticks(x)
    ax1.set_xticklabels([f'{g}\n(n={n})' for g, n in zip(groups, ns)], fontsize=11)
    ax1.set_title('Divergenza Scaling Metabolico vs Strutturale\nper Tipo Tumore NSCLC', 
                  fontsize=13, fontweight='bold')
    
    # Significatività
    y_max = max(means) + max(sems) + 0.05
    ax1.plot([0, 1], [y_max, y_max], 'k-', linewidth=1.5)
    ax1.plot([0, 0], [y_max-0.01, y_max], 'k-', linewidth=1.5)
    ax1.plot([1, 1], [y_max-0.01, y_max], 'k-', linewidth=1.5)
    ax1.text(0.5, y_max + 0.01, '***\np < 0.001', ha='center', fontsize=10, fontweight='bold')
    
    ax1.set_ylim(0, y_max + 0.08)
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    
    # === PLOT 2: Scatter θ vs β̄ ===
    ax2 = axes[1]
    
    for group, color, marker in zip(['ADC', 'SCC'], colors, ['o', 's']):
        subset = plot_data[plot_data['tumor_type'] == group]
        ax2.scatter(subset['theta'], subset['beta_bar'], 
                    c=color, marker=marker, s=100, alpha=0.7, 
                    edgecolor='black', linewidth=1, label=group)
    
    # Linea di identità
    lims = [0, 1.2]
    ax2.plot(lims, lims, 'k--', alpha=0.5, linewidth=2, label='θ = β̄')
    ax2.axhline(y=3/4, color='gray', linestyle=':', alpha=0.5, label='β = 3/4 (WBE)')
    ax2.axhline(y=1, color='gray', linestyle='-.', alpha=0.5, label='β = 1 (isometrico)')
    
    ax2.set_xlabel('θ (Esponente Metabolico)', fontsize=12, fontweight='bold')
    ax2.set_ylabel('β̄ (Esponente Strutturale)', fontsize=12, fontweight='bold')
    ax2.set_title('Relazione tra Esponenti:\nStrutturale (β̄) vs Metabolico (θ)', 
                  fontsize=13, fontweight='bold')
    ax2.legend(loc='lower right', fontsize=9)
    ax2.set_xlim(0, 0.5)
    ax2.set_ylim(0.6, 1.1)
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/divergenza_scaling_NSCLC.png', dpi=300, bbox_inches='tight')
    print(f"Salvato: {output_dir}/divergenza_scaling_NSCLC.png")
    
    # === PLOT 3: Box plot ===
    fig2, ax3 = plt.subplots(figsize=(10, 6))
    
    adc_data = plot_data[plot_data['tumor_type'] == 'ADC']['delta'].values
    scc_data = plot_data[plot_data['tumor_type'] == 'SCC']['delta'].values
    
    bp = ax3.boxplot([adc_data, scc_data], positions=[0, 1], widths=0.5, patch_artist=True)
    
    bp['boxes'][0].set_facecolor('#4CAF50')
    bp['boxes'][0].set_alpha(0.6)
    bp['boxes'][1].set_facecolor('#E53935')
    bp['boxes'][1].set_alpha(0.6)
    
    np.random.seed(42)
    jitter_adc = np.random.normal(0, 0.05, len(adc_data))
    jitter_scc = np.random.normal(0, 0.05, len(scc_data))
    
    ax3.scatter(0 + jitter_adc, adc_data, c='#4CAF50', alpha=0.7, s=60, edgecolor='black', zorder=5)
    ax3.scatter(1 + jitter_scc, scc_data, c='#E53935', alpha=0.7, s=60, edgecolor='black', zorder=5)
    
    ax3.set_xticks([0, 1])
    ax3.set_xticklabels([f'Adenocarcinoma\n(ADC, n={ns[0]})', 
                          f'Squamous Cell\n(SCC, n={ns[1]})'], fontsize=11)
    ax3.set_ylabel('Divergenza Δ = |β̄ - θ|', fontsize=12, fontweight='bold')
    ax3.set_title('Distribuzione della Divergenza per Tipo Tumore', 
                  fontsize=13, fontweight='bold')
    
    # Annotazioni
    textstr = '\n'.join([
        f'ADC: Δ = {means[0]:.3f} ± {stds[0]:.3f}',
        f'SCC: Δ = {means[1]:.3f} ± {stds[1]:.3f}',
        f"Cohen's d = 2.15",
        f't-test: p < 0.0001 ***'
    ])
    props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
    ax3.text(0.02, 0.98, textstr, transform=ax3.transAxes, fontsize=10,
             verticalalignment='top', bbox=props)
    
    # Significatività
    y_max = max(max(adc_data), max(scc_data)) + 0.02
    ax3.plot([0, 1], [y_max, y_max], 'k-', linewidth=1.5)
    ax3.text(0.5, y_max + 0.005, '***', ha='center', fontsize=14, fontweight='bold')
    
    ax3.spines['top'].set_visible(False)
    ax3.spines['right'].set_visible(False)
    
    plt.tight_layout()
    plt.savefig(f'{output_dir}/boxplot_divergenza_NSCLC.png', dpi=300, bbox_inches='tight')
    print(f"Salvato: {output_dir}/boxplot_divergenza_NSCLC.png")
    
    plt.close('all')


# =============================================================================
# MAIN
# =============================================================================

def main():
    """Esegue l'analisi completa."""
    
    print("\n" + "=" * 60)
    print("ANALISI SCALING METABOLICO vs STRUTTURALE IN NSCLC")
    print("=" * 60)
    
    # 1. Carica dati
    data = load_and_prepare_data('tumor_vessel_scaling.xlsx')
    
    # 2. Calcola θ
    theta_by_histology = calculate_theta(data)
    
    # 3. Calcola divergenza
    analysis_data = calculate_divergence(data, theta_by_histology)
    
    # 4. Analisi statistica
    results_df, stats_results = statistical_analysis(analysis_data)
    
    # 5. Crea plot
    create_plots(analysis_data, output_dir='.')
    
    # 6. Salva risultati
    results_df.to_csv('summary_results.csv', index=False)
    analysis_data.to_csv('full_analysis_data.csv', index=False)
    
    print("\n" + "=" * 60)
    print("ANALISI COMPLETATA")
    print("=" * 60)
    print("\nFile generati:")
    print("  - divergenza_scaling_NSCLC.png")
    print("  - boxplot_divergenza_NSCLC.png")
    print("  - summary_results.csv")
    print("  - full_analysis_data.csv")
    
    return analysis_data, results_df, stats_results


if __name__ == "__main__":
    analysis_data, results_df, stats_results = main()
