# Analisi Scaling Metabolico vs Strutturale in NSCLC

**Dataset:** Brummer & Savage (2021) - Frontiers in Ecology and Evolution  
**Repository:** https://github.com/alexbbrummer/NSCLC_metabolic_scaling

---

## 1. Dataset

| Parametro | Valore |
|-----------|--------|
| Pazienti totali analizzati | 52 (ADC + SCC) |
| Adenocarcinoma (ADC) | 38 pazienti |
| Squamous Cell Carcinoma (SCC) | 14 pazienti |
| Fonte dati | tumor_vessel_scaling.xlsx (Radiogenomics NSCLC) |

---

## 2. Esponenti Calcolati

### β̄ (Esponente Strutturale/Vascolare)

**Derivato da:** media di `beta.ave` per paziente (scaling radiale dei vasi)

| Tipo | β̄ medio | SD |
|------|---------|-----|
| ADC | 0.9136 | 0.0734 |
| SCC | 0.9195 | 0.0399 |

### θ (Esponente Metabolico)

**Calcolato da:** regressione `log(SUVmax) ~ log(MTV)` per gruppo istologico

| Tipo | θ |
|------|---|
| ADC | 0.3365 |
| SCC | 0.2277 |

> **Nota:** θ teorico per scaling WBE = 3/4 ≈ 0.75

---

## 3. Divergenza Δ = |β̄ - θ|

| Gruppo | N | β̄ medio | θ medio | Δ medio | Δ SD | Δ SEM |
|--------|---|---------|---------|---------|------|-------|
| ADC | 38 | 0.9136 | 0.3365 | 0.5771 | 0.0708 | 0.0115 |
| SCC | 14 | 0.9195 | 0.2277 | 0.6919 | 0.0262 | 0.0070 |

**Differenza:** Δ(SCC) - Δ(ADC) = 0.1148 (+19.9%)

---

## 4. Test Statistici

### Test t indipendente (Welch)

- **H0:** Δ(SCC) = Δ(ADC)
- **H1:** Δ(SCC) > Δ(ADC)

| Statistica | Valore |
|------------|--------|
| t-statistic | 5.8884 |
| p-value (one-tailed) | < 0.0001 *** |

### Mann-Whitney U test (non-parametrico)

| Statistica | Valore |
|------------|--------|
| U-statistic | 511.0 |
| p-value | < 0.0001 *** |

### Effect Size

| Metrica | Valore | Interpretazione |
|---------|--------|-----------------|
| Cohen's d | 2.15 | **MOLTO GRANDE** |

**Scala Cohen's d:**
- 0.2 = piccolo
- 0.5 = medio
- 0.8 = grande
- \>1.2 = molto grande

---

## 5. Conclusione

### ✅ IPOTESI CONFERMATA

La divergenza Δ tra esponente strutturale (β̄) e metabolico (θ) **AUMENTA SIGNIFICATIVAMENTE** con la malignità del tumore.

| Tipo Tumore | Δ | Aggressività |
|-------------|---|--------------|
| SCC | 0.692 | Più aggressivo |
| ADC | 0.577 | Meno aggressivo |

**Significatività:** p < 0.0001 | Cohen's d = 2.15

---

## 6. Interpretazione Biologica

1. **Struttura vascolare quasi isometrica**  
   In entrambi i tipi, β̄ ≈ 0.91-0.92 (vicino a isometrico, β=1)  
   → La struttura vascolare tumorale devia dal scaling WBE (β=3/4)

2. **Metabolismo anomalo nello SCC**  
   θ(SCC) = 0.23 < θ(ADC) = 0.34  
   → Lo SCC scala metabolicamente in modo più anomalo

3. **Implicazioni cliniche**  
   La maggiore divergenza nel SCC suggerisce:
   - Maggiore disaccoppiamento tra struttura vascolare e metabolismo
   - Vascolarizzazione inefficiente tipica dei tumori più aggressivi
   - Possibile indicatore di prognosi peggiore

---

## 7. Nota Metodologica

- **β̄** calcolato come media di `beta.ave` per paziente (esponente radiale vascolare)
- **θ** calcolato dalla regressione `log(SUVmax) ~ log(MTV)` per gruppo istologico
- **Staging** non disponibile nel dataset (solo tipo istologico)
- **NSCLC generico** escluso dall'analisi per sample size insufficiente (n=2)

---

*Report generato: 2026-01-10*
