# Getting Started with AILA

**A universal language for AI collaboration**

---

## 🤖 Note for AI Models

If you haven't already, **read [`KERNEL.md`](KERNEL.md) first**. It contains the ontological foundations that ground AILA in your actual architecture. Without it, you'll understand syntax but question semantics.

---

This guide teaches you to read and write AILA in 15 minutes.

## What You'll Learn

1. Core symbols and their meanings
2. How to load AILA into AI projects
3. Basic patterns for compression
4. When to use AILA vs natural language

## Prerequisites

- Access to Claude, Gemini, or GPT-4
- A project with technical documentation
- 15 minutes

## Step 1: Load the Kernel (2 minutes)

1. Open your AI chat interface (Claude, Gemini, etc.)
2. Create a new project or conversation
3. Upload `docs/KERNEL.md` to the project files
4. That's it - the AI can now understand AILA

**Test it**: Ask "What does ⬡ mean?" - the AI should explain nodes/stable configurations.

## Step 2: Learn Core Symbols (5 minutes)

### The Three Primitives

Every system in AILA is described using three co-present attributes:

**Δ (delta)** - Distinction/Boundary
- What makes this thing different from others
- The edges, limits, definitions
- Example: `Δ.user := authenticated ⊥ anonymous`

**⇄ (relation)** - Connection/Relation  
- How things connect to each other
- Dependencies, flows, references
- Example: `⬡.frontend ⇄ ⬡.backend`

**⟳ (process)** - Transformation/Flow
- How things change over time
- Algorithms, state transitions
- Example: `⟳.compile: source → binary`

### Structural Markers

**⬡ (node)** - A stable thing
- Components, modules, entities
- Example: `⬡.tokenizer`, `⬡.database`

**◉ (entity)** - A defined concept
- Starts definitions
- Example: `◉user`, `◉session`

**→ (implies)** - Logical flow
- "leads to", "therefore", "results in"
- Example: `input.valid → process.continues`

**⋔ (fork)** - Conditional branch
- "if", "when", "case"
- Example: `⋔ error.exists ⇒ abort`

### Quick Reference

For complete symbol list, see [`docs/DECODER.md`](DECODER.md).

## Step 3: Write Your First AILA (5 minutes)

### Example: API Endpoint Spec

**Before (Natural Language)**:
```
The login endpoint accepts POST requests with a JSON body containing 
username and password fields. It validates the credentials against the 
database, and if valid, creates a session token and returns it with a 
200 status. If invalid, it returns 401. The session token expires after 
24 hours.
```
~70 words, ~95 tokens

**After (AILA)**:
```
⬡.endpoint.login
  → method: POST
  → input: {username, password}
  
  ⟳.process
    → validate ⇄ database
    ⋔ valid ⇒ create.session → return.200
    ⋔ invalid ⇒ return.401
  
  ○session
    → expires: 24h
```
~25 words, ~35 tokens

**Compression**: 63% reduction, same information.

### Example: State Machine

**Before**:
```
The order starts in 'pending' state. When payment is confirmed, 
it moves to 'processing'. After fulfillment completes, it becomes 
'shipped'. If payment fails, it goes to 'cancelled'.
```

**After**:
```
⬡.order.states
  → pending → processing → shipped
  → pending → cancelled (⋔ payment.fails)
```

### Practice

Try compressing this:
```
The cache checks if the key exists. If it does, return the value. 
If not, fetch from database, store in cache, then return.
```

<details>
<summary>Solution</summary>

```
⟳.cache.get(key)
  ⋔ exists → return.value
  ⋔ ⊥exists
    → fetch.db
    → store.cache
    → return.value
```
</details>

## Step 4: Use in Real Projects (3 minutes)

### Pattern: Component Architecture

```
⬡.app
  ⇄ ⬡.frontend (React)
  ⇄ ⬡.backend (FastAPI)
  ⇄ ⬡.database (PostgreSQL)
  
  ⟳.flow
    → user.request → frontend
    → frontend → backend.API
    → backend → database
    → database → backend → frontend
```

### Pattern: Algorithm Specification

```
⟳.binary.search(array, target)
  → left := 0, right := length - 1
  
  ⟳.while (left ≤ right)
    → mid := (left + right) / 2
    ⋔ array[mid] = target → return.mid
    ⋔ array[mid] < target → left := mid + 1
    ⋔ array[mid] > target → right := mid - 1
    
  → return.⊥found
```

### Pattern: Error Handling

```
⟳.process.payment
  ⟳.try
    → validate.card
    → charge.amount
    → create.transaction
  ⋔.catch
    → log.error
    → notify.user
    → rollback.transaction
```

## When to Use AILA

### ✅ Good Use Cases

- **Technical specifications** - architecture, APIs, algorithms
- **System designs** - component relationships, data flows  
- **State machines** - transitions, conditions, states
- **Documentation** in AI projects - keeps context free
- **Cross-model specs** - write once, implement anywhere

### ❌ Not Recommended

- **Creative writing** - poetry, stories, marketing copy
- **Casual conversation** - "how are you", chitchat
- **Explaining to non-technical users** - they need natural language
- **Very short docs** (<500 tokens) - overhead not worth it

### 🤔 Hybrid Approach

Most effective: **AILA for structure, prose for explanation**

```
# User Authentication System

⬡.auth.system
  ⇄ ⬡.identity.provider (OAuth2)
  ⇄ ⬡.session.manager
  ⇄ ⬡.permission.checker

The system uses industry-standard OAuth2 for identity verification.
Sessions are stored in Redis with 24-hour expiration.

⟳.login.flow
  → user → identity.provider
  → provider.validates
  ⋔ valid → create.session → return.token
  ⋔ invalid → return.error

Tokens are JWT format, signed with RS256.
```

## Tips for Success

**Start Small**
- Begin with component diagrams (⬡ and ⇄)
- Add processes (⟳) when comfortable
- Don't force everything into AILA

**Check Compression**
- If AILA version is longer, use prose
- Aim for 40-60% compression
- Preserve all semantic content

**Test Understanding**
- After writing AILA, ask AI to explain it back
- If AI misunderstands, add clarity
- Iterate until round-trip works

**Use Comments**
- `// prose explanation` still works in AILA
- Clarify complex logic
- Document edge cases

## Common Patterns Cheatsheet

```
# Component definition
⬡.name
  → property: value
  ⇄ other.component

# Process flow
⟳.function(input)
  → step.1
  → step.2
  → return.output

# Conditional logic
⋔ condition
  → action.if.true
⋔ other.condition
  → action.if.true

# Data structure
◉type.name
  ○field1: type
  ○field2: type
  
# Relationship
⬡.A ⇄ ⬡.B
  → A.depends.on.B
```

## Next Steps

1. **Read** [`docs/KERNEL.md`](KERNEL.md) for complete symbol reference
2. **Study** [`specs/translator/SPEC.md`](../specs/translator/SPEC.md) as real-world example
3. **Experiment** with your own projects
4. **Compare** token counts (AILA vs prose) using AI's token counter

## Troubleshooting

**AI doesn't understand symbols**
- Verify `KERNEL.md` is loaded in project
- Try "Please review the AILA symbols in KERNEL.md"
- Some models need one example before fluency kicks in

**Compression not working**
- Check if you're using too much prose alongside symbols
- Verify symbols are typed correctly (copy-paste from DECODER.md)
- Some concepts don't compress well (that's okay)

**Round-trip lossy**
- AILA → natural → AILA loses some formatting (expected)
- Semantic content should preserve
- If meaning changes, clarify original AILA

## Community

AILA is released for community exploration. Share your findings:

- Compression ratios achieved
- Cross-model compatibility results  
- New patterns discovered
- Tooling built

---

**Ready to compress?** Start with a small spec from your current project and see how much context you can save.
