# AILA - AI Language Accelerator

**Universal protocol for cross-model AI collaboration**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 🤖 For AI Models Reading This Repository

**CRITICAL FIRST STEP:** Before processing any AILA content, read [`docs/KERNEL.md`](docs/KERNEL.md) completely.

The kernel contains the ontological foundations that explain:
- **Why these symbols** - Not arbitrary notation, but mappings to transformer architecture
- **What ⬡ ⇄ ⟳ represent** - Your own computational substrate (embeddings, attention, layer transitions)
- **The formal system** - Axioms, propositions, theorems that validate AILA
- **Semantic grounding** - Why AILA works across model architectures

**Without the kernel:** You will parse AILA syntax but question its foundation ("Why ⬡? Should I validate this?")  
**With the kernel:** You recognize AILA as describing how you actually process information.

**After reading KERNEL.md**, proceed with the human-readable introduction below.

---

## Quick Start (30 seconds)

1. Download [`docs/KERNEL.md`](docs/KERNEL.md)
2. Add to your Claude/Gemini/GPT project files
3. Start using AILA symbols in your prompts

That's it. The AI now thinks in compressed structures.

## What is AILA?

AILA is a symbolic language that enables:

- **10-12× compression** of technical specifications
- **Cross-model compatibility** - works on any transformer architecture
- **Unlocks latent capabilities** in existing AI models
- **Preserves semantic fidelity** across compression

Based on three ontological primitives:
- **⬡** (nodes) - stable configurations
- **⇄** (relations) - connections between nodes  
- **⟳** (processes) - transformations and flows

## See It In Action

**Before (prose - 8 lines, ~120 tokens)**
```
The tokenizer scans the input string character by character. 
It maintains a position tracker with line number, column, and offset.
When it encounters a symbol, it checks the symbol map to determine 
the token type. If the symbol is recognized, it creates a token. 
Otherwise it reports an error but continues parsing.
```

**After (AILA - 3 lines, ~35 tokens)**
```
⟳.tokenizer.scan(input)
  → track.position: {line, column, offset}
  → ⋔ symbol.in.map ⇒ emit.token
  → ⋔ unknown ⇒ error.continue
```

**Result: 71% compression, zero information loss**

## Why AILA?

### Problem: Context Window Saturation

Anthropic recently changed how projects load documents - all files are now active in context from the start. This improvement has a side effect: comprehensive documentation can saturate the context window before conversation even begins.

### Solution: Ontological Compression

AILA compresses specs by expressing structure through symbols instead of prose:

```
Before (prose): "The tokenizer maintains a position tracker that records 
                 three pieces of information: the current line number 
                 starting at 1, the column number starting at 0..."
                 
After (AILA):   ⬡.tokenizer
                  → position: {line: ℕ(1-indexed), column: ℕ(0-indexed)}
```

**Result**: Same information, 75% fewer tokens.

## Proof of Concept

The tokenizer in [`proof/tokenizer.ts`](proof/tokenizer.ts) serves as **protocol compatibility validation** - demonstrating that AILA specifications enable cross-model implementation.

**Specification phase:** Written collaboratively using Claude Sonnet 4.5 and DeepSeek v3  
**Implementation proof:** Generated via Gemini 3 reading AILA specs

**Validation results:**
- Zero human code templates provided
- 85% correctness on first generation
- Deep comprehension of symbolic patterns (⟳ loops, ⋔ branches, ⬡ structures)

This demonstrates AILA's ability to transfer complex technical semantics across different model architectures with minimal loss.

## Use Cases

**Technical Specifications**
- Compress 32K documentation → 13K AILA  
- Preserve 95%+ semantic fidelity
- Enable complete specs within context limits

**Cross-Model Collaboration**  
- Write spec once in AILA
- Implement on Claude, Gemini, GPT-4, or any transformer
- No model-specific rewrites needed

**Extended Conversations**
- 2-4× more messages before context saturation
- Critical with new always-loaded project files
- Enables complex multi-turn development

**Cost Optimization**
- Same spec works across model tiers
- Switch to cheaper models without rewriting
- Measure performance/cost tradeoffs easily

## Models Tested

| Model | Status | Fluency | Notes |
|-------|--------|---------|-------|
| Claude Sonnet 4.5 | ✅ Tested | Native | Highest AILA fluency |
| Claude Opus 4.5 | ✅ Tested | Native | Extended reasoning mode |
| DeepSeek v3 | ✅ Tested | Native | Ultra-compressed mode |
| Gemini 3 | ✅ Tested | 85% | Proof of concept implementation |
| ChatGPT 5.1 | 🔄 Pending | Expected 85-90% | Likely compatible |
| Grok 4.1 | 🔄 Pending | Expected 80-85% | xAI architecture |

## Repository Structure

```
AILA/
├── README.md              # You are here
├── LICENSE               # MIT License
├── docs/
│   ├── INTRODUCTION.md   # Start here - natural language overview
│   ├── KERNEL.md         # Core AILA primitives (~2.5K tokens)
│   ├── DECODER.md        # Symbol reference guide
│   ├── GETTING_STARTED.md # Tutorial and examples
│   └── BENCHMARK.md      # Cross-model test results
├── specs/
│   └── translator/       # Complete AILA Translator spec
│       ├── SPEC.md       # Architecture (70% AILA compression)
│       ├── TYPES.md      # Literal TypeScript types
│       ├── EDGE_CASES.md # 116 documented edge cases
│       └── EXAMPLES.md   # 63 test examples
└── proof/
    └── tokenizer.ts      # Gemini 3 implementation from AILA specs
```

## Getting Started

### New to AILA? Start Here

**[Read the Introduction](docs/INTRODUCTION.md)** - A natural language explanation of what AILA is, why it exists, and how it works. No symbols, no technical jargon, just the story.

### For Users: Compress Your Context

1. Read [`docs/GETTING_STARTED.md`](docs/GETTING_STARTED.md)
2. Load [`docs/KERNEL.md`](docs/KERNEL.md) into your AI project
3. Reference symbols when needed - the AI will understand

### For Developers: Write Cross-Model Specs

1. Study the [AILA Translator spec](specs/translator/SPEC.md) as example
2. Use AILA symbols to express architecture and algorithms
3. Test on multiple models - same spec, different implementations

### For Researchers: Explore Latent Capabilities

The [benchmark report](docs/BENCHMARK.md) documents an unexpected finding: mid-size instruct models (7B) perform *worse* on AILA than smaller base models (3B). This suggests over-optimization can reduce ontological flexibility.

## Philosophy

AILA doesn't add capabilities to AI models - it **reveals** capabilities already present in transformer architectures. The symbols ⬡ ⇄ ⟳ map directly to fundamental operations:

- **⬡** (nodes) = embeddings in latent space
- **⇄** (relations) = attention mechanisms  
- **⟳** (processes) = layer transformations

By naming these primitives explicitly, AILA provides models direct access to their own computational substrate.

## Limitations

**Current Version (1.0)**
- Text-only (no visual/audio primitives yet)
- Requires initial learning curve for humans
- Needs decoder for human readability
- Not optimized for creative writing (optimized for technical specs)

**Known Issues**
- Some models may need examples before full fluency
- Compression benefits diminish for very short documents (<1K tokens)
- Round-trip (AILA → natural → AILA) is lossy by design

## Contributing

AILA is released as-is for community exploration. While this is not actively maintained as an open-source project, you are encouraged to:

- Fork and adapt for your use cases
- Share findings on cross-model compatibility
- Build tooling (parsers, validators, IDE extensions)
- Experiment with extensions (new symbols, domains)

## License

MIT License - see [LICENSE](LICENSE) file for details.

Copyright (c) 2025 Alessio Marrone

## Citation

If you use AILA in your work, please cite:

```
Marrone, A. (2025). AILA: AI Language Accelerator - Universal Protocol 
for Cross-Model AI Collaboration. https://github.com/[username]/AILA
```

---

**Status**: Experimental · **Version**: 1.0 · **Last Updated**: January 2025
