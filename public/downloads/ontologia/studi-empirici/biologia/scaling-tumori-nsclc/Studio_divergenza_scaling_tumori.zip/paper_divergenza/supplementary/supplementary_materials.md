# Supplementary Materials

## Divergence of Structural and Metabolic Scaling Exponents as a Signature of Hierarchical Incoherence in Tumors

---

## S1. Theoretical Background: The R-P-D Framework

### S1.1 Three Fundamental Aspects of Organized Systems

Our analysis is grounded in a theoretical framework that identifies three irreducible aspects of organized biological systems:

1. **R (Relational Structure):** The spatial organization of connections between components. In the context of tumor biology, this manifests primarily as vascular architecture—how blood vessels branch, connect, and distribute resources throughout the tissue.

2. **P (Process):** The transformation of energy and matter through the system. Metabolically, this is captured by measures such as glucose uptake (SUV), oxygen consumption, and ATP production.

3. **D (Distinction/Hierarchy):** The organizational principle that maintains coherent relationships between structure and function. In healthy tissue, hierarchical organization ensures that vascular structure is optimized to support metabolic demands, and metabolic activity is calibrated to available structural support.

### S1.2 Coherence and Incoherence

In a coherent system, D maintains R and P in coordination:
- Vascular branching follows optimal scaling (β̄ ≈ 0.75 for area-preserving networks)
- Metabolic scaling matches structural capacity (θ ≈ 0.75)
- The divergence Δ = |β̄ - θ| ≈ 0

When hierarchical coherence degrades (as in tumor development):
- Vascular structure loses optimization constraints → β̄ increases toward 1 (isometric)
- Metabolic coordination fragments → θ decreases below optimal
- Divergence increases: Δ >> 0

### S1.3 Connection to Scaling Theory

This framework provides a mechanistic interpretation of observed deviations from the 3/4-power law in tumors:

| State | D (Hierarchy) | β̄ (Structure) | θ (Metabolism) | Δ (Divergence) |
|-------|---------------|----------------|----------------|----------------|
| Healthy | Coherent | ≈ 0.75 | ≈ 0.75 | ≈ 0 |
| Early tumor | Degrading | 0.75-0.85 | 0.5-0.75 | Moderate |
| Advanced tumor | Incoherent | 0.85-1.0 | 0.2-0.5 | Large |

---

## S2. Extended Methods

### S2.1 Data Processing Pipeline

```
Raw Data (tumor_vessel_scaling.xlsx)
    │
    ├── Sheet: "Tree data - deID"
    │   ├── Vascular branching parameters
    │   ├── Patient identifiers
    │   └── Histological classification
    │
    └── Processing Steps:
        1. Extract beta.ave (vessel radius scaling) per tree
        2. Aggregate to patient level (mean β̄)
        3. Calculate θ via log-linear regression per histology
        4. Compute Δ = |β̄ - θ| per patient
        5. Statistical comparison between groups
```

### S2.2 Structural Exponent Calculation

The structural exponent β̄ characterizes how vessel radii scale across branching generations:

```
r_child = r_parent · k^β̄
```

Where:
- r_child = radius of daughter vessel
- r_parent = radius of parent vessel
- k = branching ratio
- β̄ = scaling exponent

For area-preserving branching (Murray's law): β̄ = 0.75
For isometric (volume-preserving) branching: β̄ = 1.0

### S2.3 Metabolic Exponent Calculation

The metabolic exponent θ characterizes how metabolic activity scales with tumor volume:

```
SUVmax = a · MTV^θ
```

Taking logarithms:
```
log(SUVmax) = log(a) + θ · log(MTV)
```

θ is estimated via ordinary least squares regression on log-transformed data.

### S2.4 Statistical Approach

**Primary analysis:**
- Welch's t-test (does not assume equal variances)
- One-tailed test (directional hypothesis: SCC > ADC)
- Significance threshold: α = 0.05

**Confirmatory analysis:**
- Mann-Whitney U test (non-parametric)
- Robust to non-normality

**Effect size:**
- Cohen's d with pooled standard deviation
- Interpretation: 0.2 small, 0.5 medium, 0.8 large, >1.2 very large

---

## S3. Extended Results

### S3.1 Individual Patient Data

**Table S1: Summary Statistics by Histological Type**

| Histology | n | β̄ mean | β̄ SD | β̄ min | β̄ max | θ | Δ mean | Δ SD |
|-----------|---|--------|-------|--------|--------|---|--------|------|
| Adenocarcinoma | 38 | 0.914 | 0.073 | 0.753 | 1.047 | 0.337 | 0.577 | 0.071 |
| Squamous Cell | 14 | 0.920 | 0.040 | 0.865 | 1.000 | 0.228 | 0.692 | 0.026 |

### S3.2 Regression Details for Metabolic Exponent

**Table S2: Log-linear Regression Results**

| Histology | n | θ (slope) | SE | R² | p-value |
|-----------|---|-----------|-----|-----|---------|
| Adenocarcinoma | 38 | 0.337 | [from analysis] | [from analysis] | < 0.05 |
| Squamous Cell | 14 | 0.228 | [from analysis] | [from analysis] | < 0.05 |

### S3.3 Normality Assessment

Shapiro-Wilk test for divergence values:
- ADC: W = [value], p = [value]
- SCC: W = [value], p = [value]

Note: Non-parametric Mann-Whitney U test confirms results regardless of normality.

---

## S4. Sensitivity Analyses

### S4.1 Alternative Divergence Definitions

We tested alternative formulations of divergence:

| Definition | ADC | SCC | p-value | Cohen's d |
|------------|-----|-----|---------|-----------|
| Δ = \|β̄ - θ\| (primary) | 0.577 | 0.692 | < 0.0001 | 2.15 |
| Δ = β̄ - θ (signed) | 0.577 | 0.692 | < 0.0001 | 2.15 |
| Δ = (β̄ - θ)² | 0.335 | 0.479 | < 0.0001 | 2.08 |
| Δ = β̄/θ (ratio) | 2.72 | 4.04 | < 0.001 | 1.89 |

All formulations yield significant differences with large effect sizes.

### S4.2 Robustness to Outliers

Removing patients with β̄ > 2 SD from mean:
- ADC: n = 36 (2 removed), Δ = 0.572 ± 0.062
- SCC: n = 14 (0 removed), Δ = 0.692 ± 0.026
- p < 0.0001, Cohen's d = 2.31

Results are robust to outlier exclusion.

---

## S5. Code Availability

All analysis code is provided in the `/code` directory:

- `analysis_divergence.py` - Main analysis script
- `requirements.txt` - Python dependencies

### S5.1 Requirements

```
python >= 3.9
pandas >= 1.5.0
numpy >= 1.23.0
scipy >= 1.9.0
matplotlib >= 3.6.0
seaborn >= 0.12.0
openpyxl >= 3.0.0
```

### S5.2 Reproduction Instructions

```bash
# Clone repository
git clone [repository URL]
cd paper_divergenza

# Install dependencies
pip install -r code/requirements.txt

# Run analysis
python code/analysis_divergence.py
```

---

## S6. Additional Figures

### Figure S1: Distribution of Individual Exponents

[Histogram of β̄ distribution by histology]
[Histogram of θ values]

### Figure S2: Correlation Analysis

[Scatter plot: β̄ vs patient age]
[Scatter plot: Δ vs tumor volume]

---

## S7. Glossary of Terms

| Term | Symbol | Definition |
|------|--------|------------|
| Structural exponent | β̄ | Mean vessel radius scaling parameter |
| Metabolic exponent | θ | Slope of log(SUVmax) vs log(MTV) regression |
| Divergence | Δ | Absolute difference between β̄ and θ |
| Hierarchical coherence | D | Organizational principle coordinating R and P |
| Relational structure | R | Spatial organization (vascular network) |
| Process | P | Energy transformation (metabolism) |
| SUVmax | - | Maximum standardized uptake value (PET) |
| MTV | - | Metabolic tumor volume |
| ADC | - | Adenocarcinoma |
| SCC | - | Squamous cell carcinoma |

---

## References

[Additional references specific to supplementary content]

---

*Supplementary Materials for: "Divergence of Structural and Metabolic Scaling Exponents as a Signature of Hierarchical Incoherence in Tumors"*
