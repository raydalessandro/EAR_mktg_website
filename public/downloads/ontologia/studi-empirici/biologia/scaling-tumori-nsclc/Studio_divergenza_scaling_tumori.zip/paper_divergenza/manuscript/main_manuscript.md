# Divergence of Structural and Metabolic Scaling Exponents as a Signature of Hierarchical Incoherence in Tumors

**Authors:** [To be added]

**Affiliations:** [To be added]

**Corresponding Author:** [To be added]

**Keywords:** metabolic scaling, tumor biology, allometry, vascular networks, cancer diagnostics, scaling exponents

---

## Abstract

Metabolic scaling in biological systems has long been characterized by the 3/4-power law, attributed to optimized hierarchical distribution networks. Tumors deviate from this scaling, but the nature of this deviation remains poorly understood. Here we propose that tumor pathology is not characterized by a shift in a single scaling exponent, but by the *divergence* between structural (vascular) and metabolic scaling exponents. We hypothesize that this divergence reflects the loss of hierarchical coherence that normally coordinates structure and function. Analyzing PET-CT and vascular data from 52 non-small cell lung cancer (NSCLC) patients, we find that the divergence Δ = |β̄ - θ| between structural exponent β̄ and metabolic exponent θ is significantly greater in squamous cell carcinoma (SCC: Δ = 0.69) than in adenocarcinoma (ADC: Δ = 0.58), with p < 0.0001 and Cohen's d = 2.15. This divergence metric outperforms individual exponents in distinguishing tumor subtypes. We propose that hierarchical incoherence—the decoupling of relational structure from metabolic process—provides a unifying framework for understanding tumor scaling anomalies and may offer a novel diagnostic marker.

**Word count:** 186

---

## 1. Introduction

### 1.1 The Problem of Biological Scaling

The metabolic rate of organisms scales with body mass according to power laws that have fascinated biologists for nearly a century (Kleiber, 1932). The observation that basal metabolic rate scales as M^0.75 across species spanning many orders of magnitude led to the search for universal principles underlying this regularity. West, Brown, and Enquist (1997) proposed that the 3/4 exponent emerges from the fractal geometry of resource distribution networks optimized for efficiency.

However, the universality of the 3/4 law has been increasingly questioned. Glazier (2005) documented substantial variation in scaling exponents across taxa and developmental stages, identifying four distinct patterns of intraspecific scaling. Recent comprehensive reviews (van Valkengoed et al., 2024) conclude that no single universal exponent exists and that the theoretical framework supporting 3/4 scaling remains contested.

### 1.2 Tumor Scaling Anomalies

Tumors present a particularly interesting case for scaling theory. As systems that have escaped normal regulatory control, tumors might be expected to deviate from optimal scaling relationships. Indeed, several studies have documented that tumor metabolic scaling differs from healthy tissue (Herman et al., 2011; Brummer & Savage, 2021).

However, previous work has focused on measuring *single* scaling exponents and comparing them to the theoretical 3/4 value. This approach yields inconsistent results: some studies find tumor exponents below 0.75, others above, and the biological interpretation remains unclear.

### 1.3 A New Perspective: Divergence as Signature

We propose a fundamentally different approach. Rather than asking whether tumors scale with exponent 0.75 or some other value, we ask: **do the structural and metabolic aspects of tumor scaling remain coordinated?**

In healthy tissue, the vascular network (structure) and metabolic activity (function) are tightly coupled through hierarchical organization. We hypothesize that this coupling is maintained by what we term *hierarchical coherence*—the organizational principle that coordinates spatial structure with functional process.

When hierarchical coherence is lost, as in tumor development, we predict that structural and metabolic scaling exponents will *diverge*. The magnitude of this divergence, rather than the value of either exponent alone, should characterize the degree of pathological disorganization.

### 1.4 Theoretical Framework

Our framework posits three fundamental aspects of organized biological systems:

- **R (Relational structure):** How components connect spatially—manifested in vascular architecture
- **P (Process):** How the system transforms energy—manifested in metabolism  
- **D (Distinction/hierarchy):** The organizational principle that maintains coherence between R and P

In healthy systems, D maintains R and P in coordination, yielding similar scaling exponents (both ≈ 0.75 for optimally organized systems). When D becomes incoherent:

- R (structure) tends toward isometric scaling (exponent → 1), reflecting loss of hierarchical optimization
- P (process) tends toward fragmented scaling (exponent → lower values), reflecting metabolic disintegration
- The divergence Δ = |R - P| increases with the degree of hierarchical incoherence

This framework generates a testable prediction: **tumor malignancy should correlate with the divergence between structural and metabolic scaling exponents, not with either exponent alone.**

---

## 2. Methods

### 2.1 Data Source

We analyzed data from the NSCLC Radiogenomics dataset as compiled by Brummer & Savage (2021), available at https://github.com/alexbbrummer/NSCLC_metabolic_scaling. This dataset contains PET-CT imaging data and vascular measurements for patients with non-small cell lung cancer.

### 2.2 Patient Selection

From the original dataset, we included patients with complete data for both vascular scaling parameters and metabolic measurements, classified as either adenocarcinoma (ADC) or squamous cell carcinoma (SCC). This yielded:
- Adenocarcinoma (ADC): n = 38 patients
- Squamous cell carcinoma (SCC): n = 14 patients
- Total: n = 52 patients

Two patients classified as generic "NSCLC" were excluded due to insufficient sample size for statistical comparison.

### 2.3 Structural Scaling Exponent (β̄)

The structural scaling exponent β̄ was calculated as the mean of the vessel radius scaling parameter (beta.ave) for each patient. This parameter characterizes how vessel radii scale across branching generations in the tumor vasculature. 

For optimal area-preserving branching (Murray's law), β̄ = 0.75. Values approaching 1.0 indicate area-increasing (less efficient) branching.

### 2.4 Metabolic Scaling Exponent (θ)

The metabolic scaling exponent θ was derived from the relationship between maximum standardized uptake value (SUVmax, a measure of metabolic activity) and metabolic tumor volume (MTV). For each histological group, we performed log-linear regression:

```
log(SUVmax) = a + θ · log(MTV)
```

The slope θ represents the metabolic scaling exponent.

### 2.5 Divergence Metric

For each patient, we calculated the divergence:

```
Δᵢ = |β̄ᵢ - θ_group|
```

Where β̄ᵢ is the individual patient's structural exponent and θ_group is the metabolic exponent for their histological group (ADC or SCC).

### 2.6 Statistical Analysis

We compared Δ between ADC and SCC groups using:
- Welch's t-test (unequal variances)
- Mann-Whitney U test (non-parametric confirmation)
- Cohen's d for effect size

All analyses were performed in Python 3.11 using scipy.stats. Code is available in Supplementary Materials.

---

## 3. Results

### 3.1 Scaling Exponents by Tumor Type

**Table 1: Scaling Exponents**

| Tumor Type | n | β̄ (structural) | SD | θ (metabolic) |
|------------|---|-----------------|-----|---------------|
| ADC | 38 | 0.914 | 0.073 | 0.337 |
| SCC | 14 | 0.920 | 0.040 | 0.228 |

Both tumor types show structural exponents elevated above the theoretical optimum (0.75), approaching isometric scaling (1.0). Metabolic exponents are markedly depressed below 0.75, with SCC showing lower values than ADC.

### 3.2 Divergence Analysis

**Table 2: Divergence Metrics**

| Tumor Type | n | Δ mean | Δ SD | Δ SEM |
|------------|---|--------|------|-------|
| ADC | 38 | 0.577 | 0.071 | 0.012 |
| SCC | 14 | 0.692 | 0.026 | 0.007 |

The divergence Δ is 19.9% greater in SCC compared to ADC.

### 3.3 Statistical Significance

**Table 3: Statistical Tests**

| Test | Statistic | p-value |
|------|-----------|---------|
| Welch's t-test | t = 5.888 | p < 0.0001 |
| Mann-Whitney U | U = 511.0 | p < 0.0001 |
| Cohen's d | 2.15 | Very large effect |

The difference in divergence between tumor types is highly significant by both parametric and non-parametric tests, with a very large effect size.

### 3.4 Visualization

Figure 1 (left panel) shows the divergence Δ by tumor type, with SCC exhibiting significantly higher divergence. Figure 1 (right panel) plots structural vs. metabolic exponents, showing that all tumor samples lie far from the diagonal (θ = β̄) that would indicate coordinated scaling, with SCC samples showing greater displacement.

---

## 4. Discussion

### 4.1 Principal Findings

Our analysis reveals that tumors are characterized not by a simple shift in scaling exponent, but by a *divergence* between structural and metabolic scaling. This divergence is significantly greater in more aggressive tumor types (SCC vs. ADC), supporting our hypothesis that hierarchical incoherence underlies tumor scaling anomalies.

### 4.2 Interpretation: Structure and Function Decouple

In healthy tissue, vascular structure and metabolic function are coordinated by hierarchical organization. The vascular network is optimized to deliver resources efficiently (β̄ ≈ 0.75), and metabolism scales accordingly (θ ≈ 0.75).

In tumors, this coordination breaks down:

1. **Structural disorganization:** The vascular network loses hierarchical optimization. Without the constraints of efficient design, vessel scaling approaches isometric (β̄ → 1), reflecting chaotic, uncoordinated growth.

2. **Metabolic fragmentation:** Metabolic activity becomes decoupled from structural support. The metabolic exponent falls (θ → lower values), reflecting inefficient, fragmented energy utilization.

3. **Divergence as pathology:** The divergence Δ = |β̄ - θ| quantifies the degree to which structure and function have decoupled—a direct signature of lost hierarchical coherence.

### 4.3 Comparison with Previous Work

Our findings are consistent with previous observations while providing a unifying interpretation:

- **Herman et al. (2011)** predicted that tumor vascular disorganization would affect scaling. Our divergence metric quantifies this effect.

- **Guiot et al. (2006)** found that tumor scaling exponents evolve dynamically. Our framework suggests this reflects progressive loss of hierarchical coherence.

- **Glazier (2005, 2022)** documented the variability of scaling exponents and proposed multi-constraint models. Our three-component framework (R, P, D) provides a specific mechanism for this variability.

### 4.4 Clinical Implications

The divergence metric Δ may have diagnostic utility:

1. **Tumor characterization:** Δ distinguishes ADC from SCC with very large effect size (d = 2.15), potentially complementing histological classification.

2. **Prognostic potential:** If Δ correlates with hierarchical incoherence, it may predict tumor aggressiveness and treatment response.

3. **Non-invasive measurement:** Both components of Δ (vascular structure from CT angiography, metabolism from PET) are obtainable from standard clinical imaging.

### 4.5 Theoretical Implications

Our results support a shift in how we understand biological scaling:

1. **Beyond single exponents:** The field has focused on whether the "true" scaling exponent is 3/4, 2/3, or some other value. Our work suggests that the *relationship* between exponents may be more informative than any single value.

2. **Hierarchy as organizing principle:** The divergence between structural and metabolic scaling may reflect a general principle: hierarchical organization coordinates multiple aspects of biological systems, and pathology disrupts this coordination.

3. **Connection to ontological frameworks:** Our R-P-D framework resonates with broader theoretical perspectives on how distinction, relation, and process constitute organized systems. The mathematical structure of these relationships merits further investigation.

### 4.6 Limitations

Several limitations should be noted:

1. **Sample size:** Our analysis includes 52 patients (38 ADC, 14 SCC). Larger cohorts are needed to confirm these findings.

2. **Staging data:** The dataset lacks detailed staging information, preventing analysis of whether Δ increases with disease progression.

3. **Single cancer type:** We analyzed only NSCLC. Generalization to other cancer types requires additional study.

4. **Metabolic exponent calculation:** θ was calculated at the group level due to data structure. Individual-level metabolic exponents would provide more precise divergence estimates.

### 4.7 Future Directions

Several extensions of this work are warranted:

1. **Longitudinal analysis:** Track Δ over time in individual patients to test whether divergence increases with disease progression.

2. **Multi-cancer study:** Calculate divergence across cancer types to test generality of the hierarchical incoherence hypothesis.

3. **Mechanistic investigation:** Examine molecular and cellular correlates of scaling divergence.

4. **Biophotonic validation:** Test whether biophotonic emission patterns (Murugan et al.) correlate with scaling divergence, providing independent validation.

---

## 5. Conclusion

We have demonstrated that tumor pathology is characterized by divergence between structural and metabolic scaling exponents, with more aggressive tumors (SCC) showing greater divergence than less aggressive tumors (ADC). This finding supports the hypothesis that hierarchical incoherence—the decoupling of relational structure from metabolic process—underlies tumor scaling anomalies.

The divergence metric Δ = |β̄ - θ| offers a quantitative signature of this incoherence and may provide a novel approach to tumor characterization. More broadly, our work suggests that the coordination between different scaling relationships, rather than any single exponent, may be the key to understanding biological organization and its disruption in disease.

---

## Acknowledgments

We thank Brummer and Savage for making their data publicly available. [Additional acknowledgments to be added]

---

## Data Availability

All data analyzed in this study are available from the NSCLC Radiogenomics dataset at https://github.com/alexbbrummer/NSCLC_metabolic_scaling. Analysis code is provided in Supplementary Materials.

---

## Conflicts of Interest

The authors declare no conflicts of interest.

---

## References

Brummer, A. B., & Savage, V. M. (2021). Cancer as a Model System for Testing Metabolic Scaling Theory. *Frontiers in Ecology and Evolution*, 9, 691830. https://doi.org/10.3389/fevo.2021.691830

Glazier, D. S. (2005). Beyond the '3/4-power law': variation in the intra- and interspecific scaling of metabolic rate in animals. *Biological Reviews*, 80(4), 611-662. https://doi.org/10.1017/S1464793105006834

Glazier, D. S. (2022). How Metabolic Rate Relates to Cell Size. *Biology*, 11(8), 1106. https://doi.org/10.3390/biology11081106

Guiot, C., Degiorgis, P. G., Delsanto, P. P., Gabriele, P., & Deisboeck, T. S. (2006). The Dynamic Evolution of the Power Exponent in a Universal Growth Model of Tumors. *Journal of Theoretical Biology*, 240(3), 459-463. https://doi.org/10.1016/j.jtbi.2005.10.006

Herman, A. B., Savage, V. M., & West, G. B. (2011). A Quantitative Theory of Solid Tumor Growth, Metabolic Rate and Vascularization. *PLoS ONE*, 6(9), e22973. https://doi.org/10.1371/journal.pone.0022973

Hu, T. M. (2022). A General Biphasic Bodyweight Model for Scaling Basal Metabolic Rate, Glomerular Filtration Rate, and Drug Clearance from Birth to Adulthood. *The AAPS Journal*, 24(3), 67. https://doi.org/10.1208/s12248-022-00716-y

Kleiber, M. (1932). Body size and metabolism. *Hilgardia*, 6(11), 315-353.

van Valkengoed, D. W., Krekels, E. H. J., & Knibbe, C. A. J. (2024). All You Need to Know About Allometric Scaling: An Integrative Review on the Theoretical Basis, Empirical Evidence, and Application in Human Pharmacology. *Clinical Pharmacokinetics*, 64(2), 173-192. https://doi.org/10.1007/s40262-024-01444-6

West, G. B., Brown, J. H., & Enquist, B. J. (1997). A General Model for the Origin of Allometric Scaling Laws in Biology. *Science*, 276(5309), 122-126. https://doi.org/10.1126/science.276.5309.122

---

## Figure Legends

**Figure 1.** Divergence between structural and metabolic scaling exponents in NSCLC tumors. (A) Bar plot showing mean divergence Δ = |β̄ - θ| for adenocarcinoma (ADC, n=38) and squamous cell carcinoma (SCC, n=14). Error bars indicate standard error of the mean. *** p < 0.001, Welch's t-test. (B) Scatter plot of structural exponent (β̄) versus metabolic exponent (θ) for individual patients. Dashed diagonal line indicates θ = β̄ (no divergence). Horizontal dotted line indicates β̄ = 0.75 (WBE theoretical optimum). Note that all tumor samples show substantial divergence from coordinated scaling.

---

## Tables

[Tables 1-3 are embedded in Results section]

---

*Manuscript word count: ~2,800*
