# Divergence of Structural and Metabolic Scaling Exponents in Tumors

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

This repository contains the data, code, and manuscript for the paper:

**"Divergence of Structural and Metabolic Scaling Exponents as a Signature of Hierarchical Incoherence in Tumors"**

## Key Finding

Tumors are characterized not by a shift in a single scaling exponent, but by a **divergence** between structural (vascular) and metabolic scaling exponents. This divergence:

- Is significantly greater in more aggressive tumors (SCC vs ADC)
- Reflects loss of hierarchical coherence between structure and function
- May serve as a novel diagnostic marker

| Tumor Type | β̄ (structural) | θ (metabolic) | Δ (divergence) |
|------------|-----------------|---------------|----------------|
| ADC | 0.914 | 0.337 | 0.577 |
| SCC | 0.920 | 0.228 | 0.692 |

**Statistical significance:** p < 0.0001, Cohen's d = 2.15

## Repository Structure

```
paper_divergenza/
├── README.md                    # This file
├── manuscript/
│   └── main_manuscript.md       # Main paper text
├── code/
│   ├── analysis_divergence.py   # Main analysis script
│   └── requirements.txt         # Python dependencies
├── data/
│   └── tumor_vessel_scaling.xlsx # Source data (Brummer & Savage 2021)
├── figures/
│   ├── Figure1_divergence_analysis.png
│   ├── divergenza_scaling_NSCLC.png
│   └── boxplot_divergenza_NSCLC.png
└── supplementary/
    └── supplementary_materials.md
```

## Quick Start

### Prerequisites

- Python 3.9 or higher
- pip package manager

### Installation

```bash
# Clone the repository
git clone [repository-url]
cd paper_divergenza

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r code/requirements.txt
```

### Running the Analysis

```bash
python code/analysis_divergence.py
```

This will:
1. Load and process the tumor scaling data
2. Calculate structural (β̄) and metabolic (θ) exponents
3. Compute divergence (Δ) for each patient
4. Perform statistical tests
5. Generate figures and tables

## Data Source

The analysis uses data from:

> Brummer, A. B., & Savage, V. M. (2021). Cancer as a Model System for Testing Metabolic Scaling Theory. *Frontiers in Ecology and Evolution*, 9, 691830.

Original data repository: https://github.com/alexbbrummer/NSCLC_metabolic_scaling

## Theoretical Framework

We propose that tumor pathology reflects **hierarchical incoherence**—the decoupling of relational structure (R) from metabolic process (P) due to degradation of organizing hierarchy (D).

In healthy tissue:
- D (hierarchy) coordinates R and P
- Both scale with exponent ≈ 0.75
- Divergence Δ ≈ 0

In tumors:
- D becomes incoherent
- R → 1 (structural disorganization)
- P → lower values (metabolic fragmentation)
- Divergence Δ increases

## Citation

If you use this code or build upon this work, please cite:

```bibtex
@article{[author]2026divergence,
  title={Divergence of Structural and Metabolic Scaling Exponents as a Signature of Hierarchical Incoherence in Tumors},
  author={[Authors]},
  journal={[Journal]},
  year={2026}
}
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

[Contact information to be added]

## Acknowledgments

- Brummer and Savage for making their data publicly available
- [Additional acknowledgments]
