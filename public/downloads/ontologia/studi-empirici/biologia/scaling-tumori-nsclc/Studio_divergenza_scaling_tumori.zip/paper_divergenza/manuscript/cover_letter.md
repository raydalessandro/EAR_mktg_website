# Cover Letter

[Date]

Dear Editor,

We are pleased to submit our manuscript entitled **"Divergence of Structural and Metabolic Scaling Exponents as a Signature of Hierarchical Incoherence in Tumors"** for consideration for publication in [Journal Name].

## Summary

Metabolic scaling in biological systems has long been characterized by the 3/4-power law. While tumors are known to deviate from this scaling, the biological meaning of these deviations has remained unclear. Our work introduces a fundamentally new perspective: we show that tumor pathology is characterized not by a shift in any single scaling exponent, but by the **divergence between structural and metabolic scaling exponents**.

## Key Findings

Analyzing data from 52 non-small cell lung cancer patients, we demonstrate that:

1. The divergence Δ = |β̄ - θ| between structural and metabolic exponents is significantly greater in more aggressive tumors (squamous cell carcinoma) than in less aggressive tumors (adenocarcinoma)

2. This effect is highly significant (p < 0.0001) with a very large effect size (Cohen's d = 2.15)

3. The divergence metric outperforms individual exponents in distinguishing tumor subtypes

## Significance

Our findings have both theoretical and clinical implications:

- **Theoretically**, we propose that divergence reflects "hierarchical incoherence"—the decoupling of structure and function that characterizes tumor development

- **Clinically**, the divergence metric may provide a novel, non-invasively measurable marker of tumor aggressiveness

## Fit for [Journal]

This manuscript is appropriate for [Journal Name] because it:
- Addresses a fundamental question in biological scaling theory
- Provides new insights into tumor biology
- Offers potential clinical applications
- Uses publicly available data with fully reproducible analysis

## Declarations

- This manuscript has not been published and is not under consideration elsewhere
- All authors have approved the manuscript
- We have no conflicts of interest to declare
- Data and code are publicly available

We believe this work will be of interest to your readership and look forward to your consideration.

Sincerely,

[Corresponding Author Name]
[Affiliation]
[Email]
[Phone]
