# Abstract

## Divergence of Structural and Metabolic Scaling Exponents as a Signature of Hierarchical Incoherence in Tumors

### Authors
[To be added]

### Background
Metabolic scaling in biological systems follows power laws, with the 3/4 exponent attributed to optimized hierarchical distribution networks. Tumors deviate from this scaling, but whether this reflects a shift in the scaling exponent or a more fundamental organizational change remains unclear.

### Hypothesis
We propose that tumor pathology is characterized by **divergence** between structural (vascular) and metabolic scaling exponents, reflecting loss of hierarchical coherence—the organizational principle that normally coordinates structure and function.

### Methods
We analyzed PET-CT and vascular data from 52 non-small cell lung cancer patients (38 adenocarcinoma, 14 squamous cell carcinoma) from the NSCLC Radiogenomics dataset. We calculated structural exponent (β̄) from vessel radius scaling and metabolic exponent (θ) from SUVmax-MTV regression, then computed divergence Δ = |β̄ - θ| for each patient.

### Results
| Tumor Type | β̄ | θ | Δ |
|------------|-----|-----|-----|
| Adenocarcinoma (ADC) | 0.914 | 0.337 | 0.577 |
| Squamous Cell (SCC) | 0.920 | 0.228 | 0.692 |

Divergence was significantly greater in SCC than ADC (p < 0.0001, Cohen's d = 2.15).

### Conclusions
Tumor malignancy correlates with divergence between structural and metabolic scaling—not with either exponent alone. This supports the hypothesis that hierarchical incoherence underlies tumor scaling anomalies and suggests divergence as a novel diagnostic marker.

### Keywords
metabolic scaling, tumor biology, allometry, vascular networks, cancer diagnostics, hierarchical organization

---

**Word count:** 247

**Corresponding author:** [To be added]

**Data availability:** https://github.com/alexbbrummer/NSCLC_metabolic_scaling

**Code availability:** [Repository URL]
