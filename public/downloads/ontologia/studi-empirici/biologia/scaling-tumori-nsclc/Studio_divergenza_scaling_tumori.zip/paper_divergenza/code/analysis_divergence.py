#!/usr/bin/env python3
"""
Divergence Analysis of Structural and Metabolic Scaling in NSCLC Tumors
========================================================================

This script analyzes the divergence between structural (vascular) and metabolic
scaling exponents in non-small cell lung cancer (NSCLC) tumors.

Data source: Brummer & Savage (2021) - Frontiers in Ecology and Evolution
Repository: https://github.com/alexbbrummer/NSCLC_metabolic_scaling

Author: [To be added]
Date: January 2026
"""

import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import mannwhitneyu, ttest_ind
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Configuration
plt.style.use('seaborn-v0_8-whitegrid')
FIGSIZE = (14, 6)
DPI = 300
COLORS = {'ADC': '#4CAF50', 'SCC': '#F44336'}

def load_data(filepath: str) -> pd.DataFrame:
    """
    Load and preprocess the tumor vessel scaling dataset.
    
    Parameters
    ----------
    filepath : str
        Path to the Excel file containing tumor vessel scaling data
        
    Returns
    -------
    pd.DataFrame
        Preprocessed dataframe with relevant columns
    """
    # Load appropriate sheet
    df = pd.read_excel(filepath, sheet_name='Tree data - deID')
    
    print(f"Dataset loaded: {len(df)} rows")
    print(f"Columns: {list(df.columns)}")
    
    return df


def calculate_structural_exponent(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate structural scaling exponent (β̄) per patient.
    
    β̄ is derived from the vessel radius scaling parameter (beta.ave).
    For optimal area-preserving branching, β̄ = 0.75.
    Values approaching 1.0 indicate area-increasing branching.
    
    Parameters
    ----------
    df : pd.DataFrame
        Raw dataset
        
    Returns
    -------
    pd.DataFrame
        Patient-level summary with structural exponent
    """
    # Group by patient and calculate mean beta
    patient_data = df.groupby('Patient').agg({
        'beta.ave': 'mean',
        'Histology': 'first'
    }).reset_index()
    
    patient_data.rename(columns={'beta.ave': 'beta_structural'}, inplace=True)
    
    return patient_data


def calculate_metabolic_exponent(df: pd.DataFrame) -> dict:
    """
    Calculate metabolic scaling exponent (θ) per histological group.
    
    θ is derived from log-linear regression: log(SUVmax) ~ log(MTV)
    
    Parameters
    ----------
    df : pd.DataFrame
        Raw dataset with SUVmax and MTV columns
        
    Returns
    -------
    dict
        Dictionary mapping histology type to metabolic exponent θ
    """
    # Get unique patient-level metabolic data
    metabolic_cols = ['Patient', 'Histology', 'SUVmax', 'MTV']
    available_cols = [c for c in metabolic_cols if c in df.columns]
    
    if 'SUVmax' not in df.columns or 'MTV' not in df.columns:
        # Try alternative column names
        print("Warning: SUVmax/MTV not found, using available metabolic proxies")
        return None
    
    patient_metabolic = df.groupby('Patient').agg({
        'SUVmax': 'first',
        'MTV': 'first', 
        'Histology': 'first'
    }).reset_index()
    
    # Remove invalid values
    patient_metabolic = patient_metabolic[
        (patient_metabolic['SUVmax'] > 0) & 
        (patient_metabolic['MTV'] > 0)
    ].copy()
    
    theta_by_histology = {}
    
    for histology in patient_metabolic['Histology'].unique():
        subset = patient_metabolic[patient_metabolic['Histology'] == histology]
        
        if len(subset) < 3:
            continue
            
        # Log-linear regression
        log_mtv = np.log(subset['MTV'])
        log_suv = np.log(subset['SUVmax'])
        
        slope, intercept, r_value, p_value, std_err = stats.linregress(log_mtv, log_suv)
        
        theta_by_histology[histology] = {
            'theta': slope,
            'intercept': intercept,
            'r_squared': r_value**2,
            'p_value': p_value,
            'std_err': std_err,
            'n': len(subset)
        }
        
        print(f"{histology}: θ = {slope:.4f} (R² = {r_value**2:.3f}, n = {len(subset)})")
    
    return theta_by_histology


def calculate_divergence(patient_data: pd.DataFrame, theta_dict: dict) -> pd.DataFrame:
    """
    Calculate divergence Δ = |β̄ - θ| for each patient.
    
    Parameters
    ----------
    patient_data : pd.DataFrame
        Patient-level data with structural exponent
    theta_dict : dict
        Metabolic exponents by histology
        
    Returns
    -------
    pd.DataFrame
        Patient data with divergence calculated
    """
    patient_data = patient_data.copy()
    
    # Map theta to each patient based on histology
    patient_data['theta_metabolic'] = patient_data['Histology'].map(
        lambda h: theta_dict.get(h, {}).get('theta', np.nan)
    )
    
    # Calculate divergence
    patient_data['divergence'] = np.abs(
        patient_data['beta_structural'] - patient_data['theta_metabolic']
    )
    
    return patient_data


def statistical_analysis(patient_data: pd.DataFrame, group_col: str = 'Histology') -> dict:
    """
    Perform statistical tests comparing divergence between groups.
    
    Parameters
    ----------
    patient_data : pd.DataFrame
        Patient data with divergence calculated
    group_col : str
        Column name for grouping variable
        
    Returns
    -------
    dict
        Dictionary containing test results
    """
    results = {}
    
    # Filter to main groups
    main_groups = ['Adenocarcinoma', 'Squamous Cell']
    data_filtered = patient_data[patient_data[group_col].isin(main_groups)].copy()
    
    group1 = data_filtered[data_filtered[group_col] == 'Adenocarcinoma']['divergence']
    group2 = data_filtered[data_filtered[group_col] == 'Squamous Cell']['divergence']
    
    # Welch's t-test
    t_stat, t_pvalue = ttest_ind(group2, group1, equal_var=False)
    results['welch_t'] = {'statistic': t_stat, 'pvalue': t_pvalue / 2}  # one-tailed
    
    # Mann-Whitney U test
    u_stat, u_pvalue = mannwhitneyu(group2, group1, alternative='greater')
    results['mann_whitney'] = {'statistic': u_stat, 'pvalue': u_pvalue}
    
    # Cohen's d
    pooled_std = np.sqrt((group1.var() + group2.var()) / 2)
    cohens_d = (group2.mean() - group1.mean()) / pooled_std
    results['cohens_d'] = cohens_d
    
    # Summary statistics
    results['summary'] = {
        'ADC': {
            'n': len(group1),
            'mean': group1.mean(),
            'std': group1.std(),
            'sem': group1.sem()
        },
        'SCC': {
            'n': len(group2),
            'mean': group2.mean(),
            'std': group2.std(),
            'sem': group2.sem()
        }
    }
    
    return results


def create_figures(patient_data: pd.DataFrame, theta_dict: dict, output_dir: Path):
    """
    Generate publication-quality figures.
    
    Parameters
    ----------
    patient_data : pd.DataFrame
        Patient data with all calculated values
    theta_dict : dict
        Metabolic exponents by histology
    output_dir : Path
        Directory to save figures
    """
    # Filter to main groups
    main_groups = ['Adenocarcinoma', 'Squamous Cell']
    data_plot = patient_data[patient_data['Histology'].isin(main_groups)].copy()
    data_plot['Histology_short'] = data_plot['Histology'].map({
        'Adenocarcinoma': 'ADC',
        'Squamous Cell': 'SCC'
    })
    
    fig, axes = plt.subplots(1, 2, figsize=FIGSIZE)
    
    # Panel A: Bar plot of divergence
    ax1 = axes[0]
    
    summary = data_plot.groupby('Histology_short')['divergence'].agg(['mean', 'std', 'sem', 'count'])
    
    bars = ax1.bar(
        ['ADC\n(n={})'.format(int(summary.loc['ADC', 'count'])), 
         'SCC\n(n={})'.format(int(summary.loc['SCC', 'count']))],
        [summary.loc['ADC', 'mean'], summary.loc['SCC', 'mean']],
        yerr=[summary.loc['ADC', 'sem'], summary.loc['SCC', 'sem']],
        color=[COLORS['ADC'], COLORS['SCC']],
        capsize=5,
        edgecolor='black',
        linewidth=1.5
    )
    
    # Add individual points
    for hist, color in [('ADC', COLORS['ADC']), ('SCC', COLORS['SCC'])]:
        subset = data_plot[data_plot['Histology_short'] == hist]
        x_pos = 0 if hist == 'ADC' else 1
        ax1.scatter(
            np.random.normal(x_pos, 0.04, len(subset)),
            subset['divergence'],
            color='black',
            alpha=0.5,
            s=30,
            zorder=5
        )
    
    # Significance annotation
    ax1.annotate('***', xy=(0.5, 0.75), fontsize=16, ha='center')
    ax1.annotate('p < 0.001', xy=(0.5, 0.72), fontsize=10, ha='center')
    ax1.plot([0, 0, 1, 1], [0.70, 0.71, 0.71, 0.70], 'k-', linewidth=1.5)
    
    ax1.set_ylabel('Divergence Δ = |β̄ - θ|', fontsize=12)
    ax1.set_xlabel('Histological Type', fontsize=12)
    ax1.set_title('A. Divergence by Tumor Type', fontsize=14, fontweight='bold')
    ax1.set_ylim(0, 0.85)
    
    # Panel B: Scatter plot β vs θ
    ax2 = axes[1]
    
    for hist, color, marker in [('ADC', COLORS['ADC'], 'o'), ('SCC', COLORS['SCC'], 's')]:
        subset = data_plot[data_plot['Histology_short'] == hist]
        theta_val = theta_dict[
            'Adenocarcinoma' if hist == 'ADC' else 'Squamous Cell'
        ]['theta']
        
        ax2.scatter(
            [theta_val] * len(subset),
            subset['beta_structural'],
            c=color,
            marker=marker,
            s=80,
            alpha=0.7,
            label=hist,
            edgecolors='black',
            linewidth=0.5
        )
    
    # Reference lines
    ax2.axhline(y=0.75, color='gray', linestyle=':', alpha=0.7, label='β̄ = 3/4 (WBE)')
    ax2.axhline(y=1.0, color='gray', linestyle='-.', alpha=0.5, label='β̄ = 1 (isometric)')
    ax2.plot([0, 1], [0, 1], 'k--', alpha=0.5, label='θ = β̄ (no divergence)')
    
    ax2.set_xlabel('θ (Metabolic Exponent)', fontsize=12)
    ax2.set_ylabel('β̄ (Structural Exponent)', fontsize=12)
    ax2.set_title('B. Structural vs Metabolic Scaling', fontsize=14, fontweight='bold')
    ax2.set_xlim(0, 0.5)
    ax2.set_ylim(0.6, 1.1)
    ax2.legend(loc='upper right', fontsize=9)
    
    plt.tight_layout()
    
    # Save figure
    fig.savefig(output_dir / 'Figure1_divergence_analysis.png', dpi=DPI, bbox_inches='tight')
    fig.savefig(output_dir / 'Figure1_divergence_analysis.pdf', bbox_inches='tight')
    
    plt.close()
    print(f"Figures saved to {output_dir}")


def generate_tables(patient_data: pd.DataFrame, theta_dict: dict, 
                   stats_results: dict, output_dir: Path):
    """
    Generate publication-ready tables as CSV files.
    
    Parameters
    ----------
    patient_data : pd.DataFrame
        Patient data with all calculated values
    theta_dict : dict  
        Metabolic exponents by histology
    stats_results : dict
        Statistical test results
    output_dir : Path
        Directory to save tables
    """
    # Table 1: Scaling exponents
    table1_data = []
    for hist in ['Adenocarcinoma', 'Squamous Cell']:
        subset = patient_data[patient_data['Histology'] == hist]
        table1_data.append({
            'Tumor Type': 'ADC' if hist == 'Adenocarcinoma' else 'SCC',
            'n': len(subset),
            'β̄ (structural)': f"{subset['beta_structural'].mean():.3f}",
            'β̄ SD': f"{subset['beta_structural'].std():.3f}",
            'θ (metabolic)': f"{theta_dict[hist]['theta']:.3f}"
        })
    
    table1 = pd.DataFrame(table1_data)
    table1.to_csv(output_dir / 'Table1_scaling_exponents.csv', index=False)
    
    # Table 2: Divergence metrics
    table2_data = []
    for hist in ['Adenocarcinoma', 'Squamous Cell']:
        key = 'ADC' if hist == 'Adenocarcinoma' else 'SCC'
        s = stats_results['summary'][key]
        table2_data.append({
            'Tumor Type': key,
            'n': s['n'],
            'Δ mean': f"{s['mean']:.3f}",
            'Δ SD': f"{s['std']:.3f}",
            'Δ SEM': f"{s['sem']:.3f}"
        })
    
    table2 = pd.DataFrame(table2_data)
    table2.to_csv(output_dir / 'Table2_divergence_metrics.csv', index=False)
    
    # Table 3: Statistical tests
    table3_data = [
        {
            'Test': "Welch's t-test",
            'Statistic': f"t = {stats_results['welch_t']['statistic']:.3f}",
            'p-value': f"p < 0.0001" if stats_results['welch_t']['pvalue'] < 0.0001 
                       else f"p = {stats_results['welch_t']['pvalue']:.4f}"
        },
        {
            'Test': 'Mann-Whitney U',
            'Statistic': f"U = {stats_results['mann_whitney']['statistic']:.1f}",
            'p-value': f"p < 0.0001" if stats_results['mann_whitney']['pvalue'] < 0.0001
                       else f"p = {stats_results['mann_whitney']['pvalue']:.4f}"
        },
        {
            'Test': "Cohen's d",
            'Statistic': f"d = {stats_results['cohens_d']:.2f}",
            'p-value': 'Very large effect'
        }
    ]
    
    table3 = pd.DataFrame(table3_data)
    table3.to_csv(output_dir / 'Table3_statistical_tests.csv', index=False)
    
    print(f"Tables saved to {output_dir}")


def main():
    """Main analysis pipeline."""
    
    print("=" * 60)
    print("DIVERGENCE ANALYSIS: STRUCTURAL VS METABOLIC SCALING IN NSCLC")
    print("=" * 60)
    
    # Setup paths
    data_dir = Path(__file__).parent.parent / 'data'
    output_dir = Path(__file__).parent.parent / 'figures'
    tables_dir = Path(__file__).parent.parent / 'supplementary'
    
    for d in [output_dir, tables_dir]:
        d.mkdir(exist_ok=True)
    
    # Load data
    print("\n1. Loading data...")
    data_file = data_dir / 'tumor_vessel_scaling.xlsx'
    df = load_data(data_file)
    
    # Calculate structural exponent
    print("\n2. Calculating structural exponent (β̄)...")
    patient_data = calculate_structural_exponent(df)
    print(f"   Patients with structural data: {len(patient_data)}")
    
    # Calculate metabolic exponent  
    print("\n3. Calculating metabolic exponent (θ)...")
    theta_dict = calculate_metabolic_exponent(df)
    
    if theta_dict is None:
        print("ERROR: Could not calculate metabolic exponents")
        return
    
    # Calculate divergence
    print("\n4. Calculating divergence (Δ)...")
    patient_data = calculate_divergence(patient_data, theta_dict)
    
    # Remove rows with missing divergence
    patient_data = patient_data.dropna(subset=['divergence'])
    print(f"   Patients with complete data: {len(patient_data)}")
    
    # Statistical analysis
    print("\n5. Statistical analysis...")
    stats_results = statistical_analysis(patient_data)
    
    print(f"\n   Results:")
    print(f"   ADC: Δ = {stats_results['summary']['ADC']['mean']:.3f} ± {stats_results['summary']['ADC']['std']:.3f}")
    print(f"   SCC: Δ = {stats_results['summary']['SCC']['mean']:.3f} ± {stats_results['summary']['SCC']['std']:.3f}")
    print(f"   Welch's t: p = {stats_results['welch_t']['pvalue']:.2e}")
    print(f"   Cohen's d: {stats_results['cohens_d']:.2f}")
    
    # Generate figures
    print("\n6. Generating figures...")
    create_figures(patient_data, theta_dict, output_dir)
    
    # Generate tables
    print("\n7. Generating tables...")
    generate_tables(patient_data, theta_dict, stats_results, tables_dir)
    
    # Save processed data
    print("\n8. Saving processed data...")
    patient_data.to_csv(tables_dir / 'processed_patient_data.csv', index=False)
    
    print("\n" + "=" * 60)
    print("ANALYSIS COMPLETE")
    print("=" * 60)
    
    return patient_data, theta_dict, stats_results


if __name__ == '__main__':
    patient_data, theta_dict, stats_results = main()
