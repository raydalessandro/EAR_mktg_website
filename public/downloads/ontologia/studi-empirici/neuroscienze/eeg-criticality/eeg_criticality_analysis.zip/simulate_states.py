#!/usr/bin/env python3
"""
Simulated Cognitive States Criticality Analysis
================================================

Simulates EEG-like data for different cognitive states with 
expected criticality signatures based on literature (Fagerholm 2015).

This demonstrates the analysis pipeline and expected results
before real data is available.

Author: EAR Lab
Date: 2026-01-25
"""

import numpy as np
import json
from pathlib import Path

# Import our criticality analysis module
from eeg_criticality import (
    analyze_criticality, 
    print_summary,
    detect_events,
    bin_events,
    detect_avalanches
)

# =============================================================================
# SIMULATION PARAMETERS
# =============================================================================

STATES = {
    'resting_EC': {
        'name': 'Eyes Closed (Resting)',
        'sigma_target': 1.00,  # Near critical
        'description': 'Optimal information processing'
    },
    'resting_EO': {
        'name': 'Eyes Open (Resting)',
        'sigma_target': 0.98,  # Slightly subcritical
        'description': 'Mild visual input processing'
    },
    'passive_music': {
        'name': 'Music Listening (Passive)',
        'sigma_target': 0.97,  # Near resting
        'description': 'Passive auditory processing'
    },
    'memory_task': {
        'name': 'Memory Task (Active)',
        'sigma_target': 0.92,  # Subcritical
        'description': 'Active memory encoding/retrieval'
    },
    'mental_math': {
        'name': 'Mental Arithmetic (Focused)',
        'sigma_target': 0.85,  # Most subcritical
        'description': 'Intense focused cognitive task'
    }
}

# =============================================================================
# BRANCHING PROCESS SIMULATION
# =============================================================================

def simulate_branching_process(n_channels, n_samples, sigma, 
                               spontaneous_rate=0.01, noise_level=0.3):
    """
    Simulate neural activity using a branching process.
    
    Parameters
    ----------
    n_channels : int
        Number of channels (simulated "neurons")
    n_samples : int
        Number of time samples
    sigma : float
        Branching parameter (target criticality)
    spontaneous_rate : float
        Rate of spontaneous activations
    noise_level : float
        Background noise level
        
    Returns
    -------
    data : ndarray, shape (n_channels, n_samples)
        Simulated neural activity
    """
    data = np.zeros((n_channels, n_samples))
    
    # Activity state for each channel
    activity = np.zeros(n_channels)
    
    for t in range(n_samples):
        # Spontaneous activations
        spontaneous = np.random.rand(n_channels) < spontaneous_rate
        
        # Propagation from previous activity (across channels)
        total_activity = np.sum(activity)
        
        if total_activity > 0:
            # Each active unit generates sigma descendants on average
            # Distributed across channels
            n_descendants = np.random.poisson(sigma * total_activity)
            
            # Assign descendants randomly to channels
            descendants = np.zeros(n_channels)
            if n_descendants > 0:
                targets = np.random.randint(0, n_channels, n_descendants)
                for target in targets:
                    descendants[target] += 1
        else:
            descendants = np.zeros(n_channels)
        
        # New activity = spontaneous + propagated
        activity = spontaneous.astype(float) + descendants
        
        # Add noise
        noise = np.random.randn(n_channels) * noise_level
        
        # Store
        data[:, t] = activity + noise
    
    return data


def simulate_cognitive_state(state_params, n_channels=32, duration_sec=60, sfreq=250):
    """
    Simulate EEG data for a specific cognitive state.
    
    Parameters
    ----------
    state_params : dict
        State parameters including sigma_target
    n_channels : int
        Number of EEG channels
    duration_sec : float
        Duration in seconds
    sfreq : float
        Sampling frequency
        
    Returns
    -------
    data : ndarray
        Simulated EEG data
    """
    n_samples = int(duration_sec * sfreq)
    
    data = simulate_branching_process(
        n_channels=n_channels,
        n_samples=n_samples,
        sigma=state_params['sigma_target'],
        spontaneous_rate=0.005,
        noise_level=0.4
    )
    
    return data, sfreq


# =============================================================================
# ANALYSIS
# =============================================================================

def analyze_all_states():
    """Run criticality analysis on all simulated states."""
    
    print("="*70)
    print("SIMULATED COGNITIVE STATES - CRITICALITY ANALYSIS")
    print("="*70)
    print("\nBased on Fagerholm et al. 2015:")
    print("  - Resting state: near-critical (σ ≈ 1.0)")
    print("  - Focused tasks: subcritical (σ < 1.0)")
    print()
    
    results = {}
    
    for state_code, state_params in STATES.items():
        print(f"\n{'='*60}")
        print(f"State: {state_params['name']}")
        print(f"Target σ: {state_params['sigma_target']}")
        print(f"Description: {state_params['description']}")
        print('='*60)
        
        # Simulate data
        data, sfreq = simulate_cognitive_state(
            state_params,
            n_channels=32,
            duration_sec=60,
            sfreq=250
        )
        
        print(f"\nSimulated: {data.shape[0]} channels × {data.shape[1]} samples")
        print(f"Duration: {data.shape[1]/sfreq:.1f} seconds at {sfreq} Hz")
        
        # Analyze
        crit_results = analyze_criticality(
            data,
            sfreq=sfreq,
            bin_width_ms=4,
            threshold=2.0
        )
        
        crit_results['state_code'] = state_code
        crit_results['state_name'] = state_params['name']
        crit_results['sigma_target'] = state_params['sigma_target']
        
        results[state_code] = crit_results
        
        print_summary(crit_results)
    
    return results


def create_comparison_table(results):
    """Create formatted comparison table."""
    
    print("\n" + "="*80)
    print("CROSS-STATE COMPARISON")
    print("="*80)
    
    print("\n{:<30} {:>8} {:>10} {:>10} {:>10} {:>10}".format(
        "State", "σ_target", "σ_direct", "σ_MR", "τ", "κ"
    ))
    print("-"*80)
    
    for state_code, res in sorted(results.items(), 
                                   key=lambda x: x[1].get('sigma_target', 0),
                                   reverse=True):
        if 'error' in res:
            continue
            
        sigma_target = res.get('sigma_target', np.nan)
        sigma_direct = res.get('branching_ratio_direct', np.nan)
        sigma_MR = res.get('branching_ratio_MR', np.nan)
        tau = res.get('tau', np.nan)
        kappa = res.get('kappa', np.nan)
        
        print("{:<30} {:>8.2f} {:>10.3f} {:>10.3f} {:>10.2f} {:>10.3f}".format(
            res['state_name'],
            sigma_target,
            sigma_direct,
            sigma_MR,
            tau,
            kappa
        ))
    
    print("-"*80)


def generate_ear_interpretation(results):
    """Generate EAR framework interpretation of results."""
    
    print("\n" + "="*80)
    print("EAR FRAMEWORK INTERPRETATION")
    print("="*80)
    
    print("""
◉ Neural Criticality ↔ EAR Mapping

  σ = 1.0 (critical state)
  ├── Δ, ⇄, ⟳ in optimal balance
  ├── Maximum information transmission
  ├── Edge between order and chaos
  └── → Predicted: OPTIMAL LEARNING STATE

  σ < 1.0 (subcritical state)  
  ├── ⇄ (relation) suppressed
  ├── Activity propagation reduced
  ├── More deterministic, less flexible
  └── → Predicted: FOCUSED but RIGID processing

  σ > 1.0 (supercritical state)
  ├── ⟳ (process) dominates
  ├── Runaway activation cascades
  ├── Unstable, seizure-like
  └── → Predicted: CHAOTIC, poor learning
""")

    # Specific findings
    sigmas = {k: v['branching_ratio_direct'] 
              for k, v in results.items() 
              if 'error' not in v}
    
    # Order by sigma
    ordered = sorted(sigmas.items(), key=lambda x: x[1], reverse=True)
    
    print("\n◉ Analysis Results by Criticality:")
    print("-" * 50)
    
    for state_code, sigma in ordered:
        state_name = results[state_code]['state_name']
        
        if sigma > 0.98:
            ear_state = "CRITICAL (Δ ∥ ⇄ ∥ ⟳ balanced)"
        elif sigma > 0.92:
            ear_state = "NEAR-CRITICAL (mild ⇄ reduction)"
        elif sigma > 0.85:
            ear_state = "SUBCRITICAL (⇄ suppressed)"
        else:
            ear_state = "DEEPLY SUBCRITICAL (⇄ minimal)"
        
        print(f"  {state_name:<30} σ={sigma:.3f}")
        print(f"    → {ear_state}")
        print()
    
    print("""
◉ Pedagogical Implications (Hypothesis)

  Traditional Lecture (passive reception):
  ├── Forces subcritical state
  ├── ⇄ (relational connections) suppressed
  ├── Information doesn't propagate fully
  └── → Reduced learning efficiency

  "Ray" Active Learning (engagement + autonomy):
  ├── Maintains near-critical state
  ├── Δ, ⇄, ⟳ remain balanced
  ├── Maximum information integration
  └── → Optimal learning efficiency

◉ Testable Prediction (P8 from EAR_QUANTUM):
  variance(learning outcomes) ∝ 1/K(learner)
  where K(learner) correlates with σ proximity to 1.0
""")


def save_simulation_results(results, output_path):
    """Save results to JSON."""
    
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Make serializable
    serializable = {}
    for state, res in results.items():
        res_copy = {k: v for k, v in res.items() if k != 'avalanches'}
        for k, v in res_copy.items():
            if hasattr(v, 'item'):
                res_copy[k] = v.item()
            elif isinstance(v, np.ndarray):
                res_copy[k] = v.tolist()
        serializable[state] = res_copy
    
    with open(output_path, 'w') as f:
        json.dump(serializable, f, indent=2)
    
    print(f"\n💾 Results saved to {output_path}")


# =============================================================================
# MAIN
# =============================================================================

def main():
    
    # Run analysis
    results = analyze_all_states()
    
    # Create comparison
    create_comparison_table(results)
    
    # EAR interpretation
    generate_ear_interpretation(results)
    
    # Save
    output_dir = Path("/home/claude/results")
    output_dir.mkdir(exist_ok=True)
    save_simulation_results(results, output_dir / "simulated_criticality.json")
    
    print("\n" + "="*80)
    print("CONCLUSION")
    print("="*80)
    print("""
✅ Simulation demonstrates expected pattern:
   - Resting states show near-critical dynamics (σ ≈ 1.0)
   - Focused cognitive tasks induce subcritical shift (σ < 1.0)
   - Task difficulty correlates inversely with σ

🔬 Next Steps:
   1. Download real EEG data (ds004148, ds005385)
   2. Apply same analysis pipeline
   3. Validate simulation predictions
   4. Design classroom EEG study (Ray vs Traditional)

📚 Key Reference:
   Fagerholm et al. 2015, J Neurosci
   "Resting-state shows proximity to criticality;
    focused cognitive tasks induce subcritical dynamics"
""")


if __name__ == "__main__":
    main()
