# EEG Criticality Analysis Plan
## Proxy Analysis on Available Datasets

**Date:** 2026-01-25  
**Status:** Research Design  
**Goal:** Apply neural criticality metrics to existing cognitive EEG datasets

---

## §1. TARGET DATASETS

### Primary Dataset: ds004148
**"A test-retest resting and cognitive state EEG dataset"**

| Property | Value |
|----------|-------|
| Participants | 60 |
| Channels | EEG (standard) |
| Format | BIDS |
| States | 5 cognitive conditions |
| DOI | 10.18112/openneuro.ds004148.v1.0.1 |
| Paper | Wang et al. 2022, Scientific Data |

**Cognitive States Available:**
1. Eyes Closed (resting)
2. Eyes Open (resting)
3. Memory Task
4. Music Listening
5. Mental Subtraction

→ **Critical for hypothesis:** Compare resting vs active task criticality

### Secondary Dataset: ds005385
**"Dortmund Vital Study"**

| Property | Value |
|----------|-------|
| Participants | 608 |
| Channels | 64-channel EEG |
| Format | BIDS |
| Age range | 20-70 years |
| Follow-up | 5-year (208 participants) |
| DOI | 10.18112/openneuro.ds005385.v1.0.2 |

**Structure:**
- Resting EEG BEFORE cognitive battery
- Resting EEG AFTER cognitive battery
- 2-hour cognitive task block between

→ **Critical for hypothesis:** Compare pre/post task criticality shift

---

## §2. ANALYSIS PIPELINE

### Phase 1: Data Acquisition
```
OpenNeuro → DataLad clone
├── ds004148/
│   ├── sub-001/
│   │   └── eeg/
│   └── derivatives/
└── ds005385/
    ├── sub-001/
    │   ├── ses-1/
    │   └── ses-2/
    └── ...
```

### Phase 2: Preprocessing (MNE-Python)
```python
Pipeline:
1. Load BIDS data (mne_bids)
2. Filter: 0.1-100 Hz bandpass
3. Notch filter: 50 Hz (EU) / 60 Hz (US)
4. Bad channel detection + interpolation
5. ICA for artifact removal (EOG, EMG)
6. Re-reference: average reference
7. Epoch by condition
```

### Phase 3: Avalanche Detection
```python
Method (Beggs & Plenz 2003):
1. Z-score transform each channel
2. Threshold detection (2-3 SD)
3. Time binning (Δt = 1-32 ms sweep)
4. Avalanche = contiguous active bins
5. Measure: size (total events), duration (bins)
```

### Phase 4: Criticality Metrics

**4.1 Branching Ratio (σ)**
```
σ = descendants / ancestors
σ = 1.0 → critical
σ < 1.0 → subcritical  
σ > 1.0 → supercritical
```

**4.2 Power Law Exponents**
```
Size distribution: P(s) ~ s^(-τ)
Duration distribution: P(d) ~ d^(-α)
Critical prediction: τ ≈ 1.5, α ≈ 2.0
```

**4.3 Shape Collapse**
```
Scale avalanche shapes by duration
Critical: all shapes collapse to universal form
Use NCC Toolbox automated method
```

**4.4 κ (Kappa) Index**
```
κ = 1 + (power law range) × (σ - 1)
κ ≈ 1.0 → critical
```

---

## §3. TOOLS & SOFTWARE

### Required Stack
```
Python 3.10+
├── mne (≥1.6)
├── mne-bids (≥0.14)
├── numpy
├── scipy
├── matplotlib
└── powerlaw (Python package for heavy-tailed distributions)

Optional (for advanced analysis):
├── MATLAB + NCC Toolbox (Marshall et al. 2016)
└── oct2py (Python-MATLAB bridge)
```

### Key References
1. **NCC Toolbox**: Marshall et al. 2016, Front. Physiol.
   - Power law fitting with MLE
   - Automated shape collapse
   - Branching ratio estimation

2. **MR Estimator**: Wilting & Priesemann 2018
   - Subsampling-corrected branching ratio
   - More accurate for EEG (partial coverage)

3. **Powerlaw Python**: Alstott et al. 2014
   - Heavy-tail distribution fitting
   - Model comparison (power law vs exponential vs lognormal)

---

## §4. HYPOTHESIS TESTING

### Primary Hypothesis
```
H0: σ(task) = σ(rest)
H1: σ(task) < σ(rest)  [subcritical shift during task]
```

### Secondary Hypotheses

**H2: Task type modulates criticality**
```
Passive (music) → σ ≈ σ(rest)
Active (mental subtraction) → σ < σ(rest)
Memory → intermediate
```

**H3: Post-task fatigue effect**
```
ds005385: σ(pre-task) > σ(post-task)
Cognitive load depletes criticality?
```

**H4: Age correlation**
```
ds005385: σ vs age (20-70 years)
Does criticality change across lifespan?
```

---

## §5. EXPECTED RESULTS (Based on Fagerholm 2015)

| Condition | Expected σ | Expected τ |
|-----------|-----------|-----------|
| Resting (eyes closed) | ~1.0 | ~1.5 |
| Resting (eyes open) | ~0.98 | ~1.5 |
| Memory task | ~0.95 | ~1.6 |
| Mental subtraction | ~0.90 | ~1.7 |
| Music (passive) | ~0.97 | ~1.5 |

→ Subcritical shift correlates with task difficulty/focus

---

## §6. LIMITATIONS & CONSIDERATIONS

### Known Issues

1. **Subsampling**: EEG samples only scalp activity
   - Use MR estimator (Wilting & Priesemann)
   - Acknowledge underestimation of true σ

2. **Time bin selection**: Affects avalanche detection
   - Sweep multiple Δt values
   - Report optimal bin (where σ → 1 for rest)

3. **Threshold selection**: Affects event detection
   - Test 2.0, 2.5, 3.0 SD thresholds
   - Report sensitivity analysis

4. **Volume conduction**: EEG channels are correlated
   - Source localization (optional)
   - Or use sensor-space with caution

### Not Directly Testable (Yet)
- Actual pedagogical methods (no dataset exists)
- Real classroom comparison
- Ray vs traditional learning environments

---

## §7. IMPLEMENTATION ROADMAP

### Week 1: Setup
- [ ] Download datasets via DataLad
- [ ] Setup MNE-Python environment
- [ ] Verify BIDS data structure

### Week 2: Preprocessing
- [ ] Develop preprocessing pipeline
- [ ] Quality control on sample subjects
- [ ] Document artifact rejection rates

### Week 3: Avalanche Analysis
- [ ] Implement avalanche detection
- [ ] Parameter sweep (Δt, threshold)
- [ ] Validate on simulated critical data

### Week 4: Criticality Metrics
- [ ] Implement branching ratio calculation
- [ ] Implement power law fitting
- [ ] Run on ds004148 (5 conditions)

### Week 5: Statistical Analysis
- [ ] Compare conditions within subjects
- [ ] Group-level statistics
- [ ] Generate figures

### Week 6: Extend to ds005385
- [ ] Pre/post task comparison
- [ ] Age correlation analysis
- [ ] Longitudinal analysis (if feasible)

---

## §8. CONNECTION TO EAR FRAMEWORK

### EAR Interpretation of Neural Criticality

```
◉ σ = 1.0 (critical)
  → Δ, ⇄, ⟳ in balance
  → maximum information processing
  → optimal learning state?

◉ σ < 1.0 (subcritical)
  → ⇄ (relation) suppressed
  → activity dies out quickly
  → focused but rigid processing

◉ σ > 1.0 (supercritical)
  → ⟳ (process) dominates
  → runaway activation
  → seizure-like dynamics
```

### Pedagogical Prediction
```
Traditional lecture → forces subcritical (passive reception)
Ray-style active learning → maintains criticality (engagement)

◉ hypothesis.testable
  → measure σ during different learning conditions
  → correlate σ with learning outcomes
  → optimize pedagogy for σ ≈ 1.0
```

---

## §9. OUTPUT DELIVERABLES

1. **Technical Report**: Criticality metrics across cognitive states
2. **Figures**: 
   - Avalanche size distributions by condition
   - Branching ratio comparison
   - Shape collapse visualization
3. **Code Repository**: Reproducible analysis pipeline
4. **Pilot Data**: Foundation for future classroom study

---

#END
