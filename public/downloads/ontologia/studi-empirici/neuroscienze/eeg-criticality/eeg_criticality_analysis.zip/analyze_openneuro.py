#!/usr/bin/env python3
"""
OpenNeuro EEG Dataset Analysis
==============================

Downloads and analyzes ds004148:
"A test-retest resting and cognitive state EEG dataset"

Compares criticality metrics across 5 cognitive states:
1. Eyes Closed (resting)
2. Eyes Open (resting)
3. Memory Task
4. Music Listening  
5. Mental Subtraction

Author: EAR Lab
Date: 2026-01-25
"""

import os
import subprocess
import json
from pathlib import Path

# =============================================================================
# CONFIGURATION
# =============================================================================

DATASET_ID = "ds004148"
DATASET_URL = f"https://github.com/OpenNeuroDatasets/{DATASET_ID}.git"
DATA_DIR = Path("/home/claude/eeg_data")
OUTPUT_DIR = Path("/home/claude/results")

# Cognitive states in ds004148
STATES = {
    'EC': 'Eyes Closed',
    'EO': 'Eyes Open', 
    'ME': 'Memory Task',
    'MU': 'Music Listening',
    'MA': 'Mental Arithmetic'
}

# =============================================================================
# DATA DOWNLOAD
# =============================================================================

def download_dataset():
    """Download dataset from OpenNeuro via DataLad or git."""
    
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    dataset_path = DATA_DIR / DATASET_ID
    
    if dataset_path.exists():
        print(f"Dataset already exists at {dataset_path}")
        return dataset_path
    
    print(f"Downloading {DATASET_ID}...")
    
    # Try DataLad first
    try:
        subprocess.run(
            ["datalad", "install", "-s", DATASET_URL, str(dataset_path)],
            check=True,
            capture_output=True
        )
        print("Downloaded via DataLad")
        return dataset_path
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass
    
    # Fallback to git clone
    try:
        subprocess.run(
            ["git", "clone", "--depth", "1", DATASET_URL, str(dataset_path)],
            check=True
        )
        print("Downloaded via git clone")
        return dataset_path
    except subprocess.CalledProcessError as e:
        print(f"Error downloading: {e}")
        return None


def download_subject_data(dataset_path, subject_id):
    """Download actual EEG files for a subject using DataLad."""
    
    subj_dir = dataset_path / f"sub-{subject_id}" / "eeg"
    
    if not subj_dir.exists():
        print(f"Subject directory not found: {subj_dir}")
        return False
    
    # Use DataLad to get actual file content
    try:
        subprocess.run(
            ["datalad", "get", str(subj_dir)],
            cwd=str(dataset_path),
            check=True,
            capture_output=True
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("DataLad get failed - files may be symlinks only")
        return False


# =============================================================================
# BIDS DATA LOADING
# =============================================================================

def load_bids_eeg(bids_path, subject_id, task=None):
    """
    Load EEG data from BIDS format.
    
    Parameters
    ----------
    bids_path : Path
        Root of BIDS dataset
    subject_id : str
        Subject ID (without 'sub-' prefix)
    task : str, optional
        Task name to load
        
    Returns
    -------
    data : dict
        Loaded data with 'raw', 'events', 'metadata'
    """
    try:
        import mne
        from mne_bids import read_raw_bids, BIDSPath
    except ImportError:
        print("MNE-Python and mne-bids required. Install with:")
        print("  pip install mne mne-bids")
        return None
    
    bids_path = BIDSPath(
        subject=subject_id,
        task=task,
        datatype='eeg',
        root=bids_path
    )
    
    try:
        raw = read_raw_bids(bids_path, verbose=False)
        return {
            'raw': raw,
            'sfreq': raw.info['sfreq'],
            'n_channels': len(raw.ch_names),
            'duration': raw.times[-1]
        }
    except Exception as e:
        print(f"Error loading {bids_path}: {e}")
        return None


# =============================================================================
# ANALYSIS WORKFLOW
# =============================================================================

def analyze_subject_all_states(dataset_path, subject_id):
    """
    Analyze criticality across all cognitive states for one subject.
    """
    from eeg_criticality import analyze_criticality, print_summary
    
    results = {}
    
    for state_code, state_name in STATES.items():
        print(f"\n{'='*60}")
        print(f"Analyzing {state_name} (task-{state_code})")
        print('='*60)
        
        data = load_bids_eeg(dataset_path, subject_id, task=state_code)
        
        if data is None:
            print(f"  ⚠️ Could not load data for {state_code}")
            continue
        
        # Get raw data array
        raw = data['raw']
        raw.load_data()
        
        # Basic preprocessing
        raw.filter(1, 100, verbose=False)  # Bandpass
        raw.notch_filter(50, verbose=False)  # Line noise (EU)
        
        # Get data matrix
        eeg_data = raw.get_data(picks='eeg')
        
        # Run criticality analysis
        crit_results = analyze_criticality(
            eeg_data,
            sfreq=data['sfreq'],
            bin_width_ms=4,
            threshold=2.5
        )
        
        crit_results['state_code'] = state_code
        crit_results['state_name'] = state_name
        
        results[state_code] = crit_results
        
        print_summary(crit_results)
    
    return results


def compare_states(results):
    """Compare criticality metrics across states."""
    
    print("\n" + "="*70)
    print("CROSS-STATE COMPARISON")
    print("="*70)
    
    print("\n{:<25} {:>10} {:>10} {:>10} {:>10}".format(
        "State", "σ_direct", "σ_MR", "τ", "κ"
    ))
    print("-"*70)
    
    for state_code, res in results.items():
        if 'error' in res:
            print(f"{res['state_name']:<25} ERROR: {res['error']}")
            continue
            
        print("{:<25} {:>10.3f} {:>10.3f} {:>10.2f} {:>10.3f}".format(
            res['state_name'],
            res['branching_ratio_direct'],
            res['branching_ratio_MR'],
            res['tau'],
            res['kappa']
        ))
    
    print("-"*70)
    
    # Statistical comparison
    sigmas = {k: v['branching_ratio_direct'] 
              for k, v in results.items() 
              if 'error' not in v and not np.isnan(v['branching_ratio_direct'])}
    
    if len(sigmas) >= 2:
        print("\n📊 Key Findings:")
        
        # Find most/least critical
        most_critical = max(sigmas, key=lambda x: abs(1 - sigmas[x]))
        closest_to_one = min(sigmas, key=lambda x: abs(1 - sigmas[x]))
        
        print(f"   Most critical state: {STATES[closest_to_one]} (σ = {sigmas[closest_to_one]:.3f})")
        print(f"   Furthest from critical: {STATES[most_critical]} (σ = {sigmas[most_critical]:.3f})")
        
        # Compare resting vs task
        rest_states = ['EC', 'EO']
        task_states = ['ME', 'MA']
        
        rest_sigma = np.mean([sigmas[s] for s in rest_states if s in sigmas])
        task_sigma = np.mean([sigmas[s] for s in task_states if s in sigmas])
        
        if not np.isnan(rest_sigma) and not np.isnan(task_sigma):
            print(f"\n   Resting average σ: {rest_sigma:.3f}")
            print(f"   Task average σ:    {task_sigma:.3f}")
            print(f"   Difference:        {rest_sigma - task_sigma:.3f}")
            
            if task_sigma < rest_sigma:
                print("   → Tasks induce SUBCRITICAL shift ✓ (matches Fagerholm 2015)")
            else:
                print("   → No subcritical shift observed")


def save_results(results, output_path):
    """Save results to JSON file."""
    
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Convert to serializable format
    serializable = {}
    for state, res in results.items():
        res_copy = {k: v for k, v in res.items() if k != 'avalanches'}
        # Convert numpy types
        for k, v in res_copy.items():
            if hasattr(v, 'item'):  # numpy scalar
                res_copy[k] = v.item()
        serializable[state] = res_copy
    
    with open(output_path, 'w') as f:
        json.dump(serializable, f, indent=2)
    
    print(f"\n💾 Results saved to {output_path}")


# =============================================================================
# MAIN
# =============================================================================

import numpy as np

def main():
    """Main analysis workflow."""
    
    print("="*70)
    print("EEG CRITICALITY ANALYSIS - ds004148")
    print("="*70)
    
    # Step 1: Download dataset
    print("\n📥 Step 1: Downloading dataset...")
    dataset_path = download_dataset()
    
    if dataset_path is None:
        print("❌ Failed to download dataset")
        print("\nAlternative: Manual download from")
        print("  https://openneuro.org/datasets/ds004148/versions/1.0.1")
        return
    
    # Step 2: Check structure
    print("\n📂 Step 2: Checking dataset structure...")
    
    participants_file = dataset_path / "participants.tsv"
    if not participants_file.exists():
        print("⚠️ participants.tsv not found")
        # List available subjects
        subjects = [d.name for d in dataset_path.iterdir() 
                   if d.is_dir() and d.name.startswith('sub-')]
        print(f"Found {len(subjects)} subject directories")
    else:
        print("✓ Dataset structure valid")
    
    # Step 3: Analyze first subject as demo
    print("\n🔬 Step 3: Analyzing subject 001...")
    
    # Check if MNE is available
    try:
        import mne
        import mne_bids
        print(f"  MNE version: {mne.__version__}")
    except ImportError:
        print("❌ MNE-Python not installed")
        print("Install with: pip install mne mne-bids")
        print("\n📋 Dataset is ready at:", dataset_path)
        print("Run analysis after installing dependencies.")
        return
    
    # Download actual data for subject
    print("  Downloading EEG files for sub-001...")
    download_subject_data(dataset_path, "001")
    
    # Run analysis
    results = analyze_subject_all_states(dataset_path, "001")
    
    # Compare states
    if results:
        compare_states(results)
        
        # Save results
        OUTPUT_DIR.mkdir(exist_ok=True)
        save_results(results, OUTPUT_DIR / "sub-001_criticality.json")
    
    print("\n✅ Analysis complete!")


if __name__ == "__main__":
    main()
