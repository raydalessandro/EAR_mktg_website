#!/usr/bin/env python3
"""
EEG Neural Criticality Analysis Pipeline
=========================================

Calculates criticality metrics from EEG data:
- Neuronal avalanche detection
- Branching ratio (σ)
- Power law exponents (τ, α)
- Kappa index (κ)

Based on:
- Beggs & Plenz 2003 (avalanche detection)
- Marshall et al. 2016 (NCC methods)
- Wilting & Priesemann 2018 (MR estimator)

Author: EAR Lab
Date: 2026-01-25
"""

import numpy as np
from scipy import stats
from scipy.optimize import curve_fit
import warnings

# =============================================================================
# AVALANCHE DETECTION
# =============================================================================

def detect_events(data, threshold=2.5, method='zscore'):
    """
    Detect discrete events from continuous EEG data.
    
    Parameters
    ----------
    data : ndarray, shape (n_channels, n_times)
        EEG data matrix
    threshold : float
        Detection threshold (in SD or absolute)
    method : str
        'zscore' - threshold in standard deviations
        'percentile' - threshold as percentile
        
    Returns
    -------
    events : ndarray, shape (n_channels, n_times)
        Binary event matrix (1 = event, 0 = no event)
    """
    n_channels, n_times = data.shape
    events = np.zeros_like(data, dtype=int)
    
    if method == 'zscore':
        # Z-score each channel independently
        z_data = stats.zscore(data, axis=1)
        # Detect positive and negative deflections
        events = (np.abs(z_data) > threshold).astype(int)
        
    elif method == 'percentile':
        for ch in range(n_channels):
            thresh_val = np.percentile(np.abs(data[ch]), threshold)
            events[ch] = (np.abs(data[ch]) > thresh_val).astype(int)
    
    return events


def bin_events(events, bin_width):
    """
    Bin events into time windows.
    
    Parameters
    ----------
    events : ndarray, shape (n_channels, n_times)
        Binary event matrix
    bin_width : int
        Number of samples per bin
        
    Returns
    -------
    binned : ndarray, shape (n_channels, n_bins)
        Binned event counts
    """
    n_channels, n_times = events.shape
    n_bins = n_times // bin_width
    
    # Reshape and sum within bins
    trimmed = events[:, :n_bins * bin_width]
    reshaped = trimmed.reshape(n_channels, n_bins, bin_width)
    binned = np.sum(reshaped, axis=2)
    
    return (binned > 0).astype(int)  # Binary: any event in bin


def detect_avalanches(binned_events):
    """
    Detect avalanches as contiguous sequences of active bins.
    
    Parameters
    ----------
    binned_events : ndarray, shape (n_channels, n_bins)
        Binary binned event matrix
        
    Returns
    -------
    avalanches : list of dict
        Each avalanche contains:
        - 'size': total number of events
        - 'duration': number of time bins
        - 'profile': activity per time bin
        - 'start': starting bin index
    """
    n_channels, n_bins = binned_events.shape
    
    # Total activity per bin (across all channels)
    total_activity = np.sum(binned_events, axis=0)
    
    avalanches = []
    in_avalanche = False
    current = {'size': 0, 'duration': 0, 'profile': [], 'start': 0}
    
    for t in range(n_bins):
        activity = total_activity[t]
        
        if activity > 0:
            if not in_avalanche:
                # Start new avalanche
                in_avalanche = True
                current = {
                    'size': activity,
                    'duration': 1,
                    'profile': [activity],
                    'start': t
                }
            else:
                # Continue avalanche
                current['size'] += activity
                current['duration'] += 1
                current['profile'].append(activity)
        else:
            if in_avalanche:
                # End avalanche
                avalanches.append(current)
                in_avalanche = False
    
    # Handle avalanche at end of recording
    if in_avalanche:
        avalanches.append(current)
    
    return avalanches


# =============================================================================
# BRANCHING RATIO CALCULATION
# =============================================================================

def branching_ratio_direct(avalanches, min_ancestors=1):
    """
    Calculate branching ratio directly from avalanches.
    
    σ = <descendants> / <ancestors>
    
    At criticality: σ ≈ 1.0
    
    Parameters
    ----------
    avalanches : list of dict
        Detected avalanches
    min_ancestors : int
        Minimum ancestors to include in calculation
        
    Returns
    -------
    sigma : float
        Branching ratio
    sigma_std : float
        Standard deviation
    """
    ratios = []
    
    for av in avalanches:
        profile = av['profile']
        if len(profile) < 2:
            continue
            
        # Calculate ratio for each step
        for i in range(len(profile) - 1):
            ancestors = profile[i]
            descendants = profile[i + 1]
            
            if ancestors >= min_ancestors:
                ratios.append(descendants / ancestors)
    
    if len(ratios) == 0:
        return np.nan, np.nan
        
    return np.mean(ratios), np.std(ratios)


def branching_ratio_MR(activity, max_delay=50):
    """
    Multiple Regression (MR) estimator for branching ratio.
    
    Accounts for subsampling effects (Wilting & Priesemann 2018).
    More accurate for EEG where we sample only a fraction of neurons.
    
    Parameters
    ----------
    activity : ndarray
        Total activity per time bin
    max_delay : int
        Maximum delay for regression
        
    Returns
    -------
    sigma : float
        Estimated branching ratio
    """
    n = len(activity)
    
    # Calculate regression slopes for different delays
    delays = np.arange(1, min(max_delay, n // 10) + 1)
    slopes = []
    
    for k in delays:
        x = activity[:-k]
        y = activity[k:]
        
        # Linear regression
        if len(x) > 10 and np.std(x) > 0:
            slope, _, _, _, _ = stats.linregress(x, y)
            slopes.append(slope)
    
    if len(slopes) < 3:
        return np.nan
    
    slopes = np.array(slopes)
    
    # Fit exponential: r_k = m^k
    # log(r_k) = k * log(m)
    try:
        valid = slopes > 0
        if np.sum(valid) < 3:
            return np.nan
            
        log_slopes = np.log(slopes[valid])
        delays_valid = delays[:len(slopes)][valid]
        
        def exp_func(k, m):
            return np.log(m) * k
        
        popt, _ = curve_fit(exp_func, delays_valid, log_slopes, p0=[0.9])
        sigma = popt[0]
        
    except (RuntimeError, ValueError):
        # Fallback to simple estimate
        sigma = slopes[0] if len(slopes) > 0 else np.nan
    
    return sigma


# =============================================================================
# POWER LAW FITTING
# =============================================================================

def fit_power_law(data, xmin=None, xmax=None):
    """
    Fit power law distribution using MLE.
    
    P(x) ~ x^(-α)
    
    Parameters
    ----------
    data : array-like
        Sample data (e.g., avalanche sizes)
    xmin : float, optional
        Minimum value for fitting
    xmax : float, optional
        Maximum value for fitting
        
    Returns
    -------
    alpha : float
        Power law exponent
    xmin : float
        Lower cutoff
    ks_stat : float
        Kolmogorov-Smirnov statistic (goodness of fit)
    """
    data = np.array(data)
    data = data[data > 0]  # Remove zeros
    
    if len(data) < 10:
        return np.nan, np.nan, np.nan
    
    # Auto-detect xmin if not provided
    if xmin is None:
        xmin = np.min(data)
    
    # Filter data
    data_fit = data[data >= xmin]
    if xmax is not None:
        data_fit = data_fit[data_fit <= xmax]
    
    if len(data_fit) < 5:
        return np.nan, xmin, np.nan
    
    # MLE estimate for discrete power law
    # α = 1 + n * [Σ ln(x_i / (xmin - 0.5))]^(-1)
    n = len(data_fit)
    alpha = 1 + n / np.sum(np.log(data_fit / (xmin - 0.5)))
    
    # KS statistic
    # Compare empirical CDF with theoretical power law CDF
    data_sorted = np.sort(data_fit)
    empirical_cdf = np.arange(1, n + 1) / n
    
    # Theoretical CDF: 1 - (x/xmin)^(1-α)
    theoretical_cdf = 1 - (data_sorted / xmin) ** (1 - alpha)
    theoretical_cdf = np.clip(theoretical_cdf, 0, 1)
    
    ks_stat = np.max(np.abs(empirical_cdf - theoretical_cdf))
    
    return alpha, xmin, ks_stat


def compare_distributions(data, xmin=None):
    """
    Compare power law fit with alternative distributions.
    
    Parameters
    ----------
    data : array-like
        Sample data
    xmin : float, optional
        Minimum value for fitting
        
    Returns
    -------
    results : dict
        Comparison results with log-likelihood ratios
    """
    data = np.array(data)
    data = data[data > 0]
    
    if xmin is None:
        xmin = np.min(data)
    
    data_fit = data[data >= xmin]
    n = len(data_fit)
    
    if n < 10:
        return {'power_law_supported': False, 'message': 'Insufficient data'}
    
    # Fit power law
    alpha, _, _ = fit_power_law(data_fit, xmin=xmin)
    
    # Log-likelihood for power law
    ll_pl = -n * np.log(xmin) + (1 - alpha) * np.sum(np.log(data_fit / xmin))
    
    # Fit exponential: P(x) ~ exp(-λx)
    lambda_exp = 1 / np.mean(data_fit)
    ll_exp = n * np.log(lambda_exp) - lambda_exp * np.sum(data_fit)
    
    # Log-likelihood ratio
    llr = ll_pl - ll_exp
    
    # Vuong's test for nested models
    # Positive LLR favors power law
    
    return {
        'alpha': alpha,
        'lambda_exp': lambda_exp,
        'log_likelihood_ratio': llr,
        'power_law_supported': llr > 0,
        'n_samples': n
    }


# =============================================================================
# KAPPA INDEX
# =============================================================================

def kappa_index(avalanches, theoretical_tau=1.5):
    """
    Calculate κ index for criticality assessment.
    
    κ = 1 indicates critical state
    κ < 1 indicates subcritical
    κ > 1 indicates supercritical
    
    Based on Shew et al. 2009
    
    Parameters
    ----------
    avalanches : list of dict
        Detected avalanches
    theoretical_tau : float
        Theoretical power law exponent at criticality (default 1.5)
        
    Returns
    -------
    kappa : float
        Kappa index
    """
    sizes = np.array([av['size'] for av in avalanches])
    sizes = sizes[sizes > 0]
    
    if len(sizes) < 10:
        return np.nan
    
    # Empirical CDF
    sizes_sorted = np.sort(sizes)
    n = len(sizes_sorted)
    empirical_cdf = np.arange(1, n + 1) / n
    
    # Theoretical CDF for critical power law
    smin = np.min(sizes)
    smax = np.max(sizes)
    theoretical_cdf = 1 - (sizes_sorted / smin) ** (1 - theoretical_tau)
    theoretical_cdf = np.clip(theoretical_cdf, 0, 1)
    
    # Kappa = 1 + deviation
    deviation = np.mean(empirical_cdf - theoretical_cdf)
    kappa = 1 + deviation
    
    return kappa


# =============================================================================
# MAIN ANALYSIS FUNCTION
# =============================================================================

def analyze_criticality(data, sfreq, bin_width_ms=4, threshold=2.5):
    """
    Complete criticality analysis on EEG data.
    
    Parameters
    ----------
    data : ndarray, shape (n_channels, n_times)
        EEG data matrix
    sfreq : float
        Sampling frequency in Hz
    bin_width_ms : float
        Time bin width in milliseconds
    threshold : float
        Event detection threshold in SD
        
    Returns
    -------
    results : dict
        Complete analysis results
    """
    print(f"Analyzing {data.shape[0]} channels, {data.shape[1]} samples...")
    
    # Convert bin width to samples
    bin_width_samples = int(bin_width_ms * sfreq / 1000)
    
    # Step 1: Detect events
    events = detect_events(data, threshold=threshold)
    n_events = np.sum(events)
    print(f"  Detected {n_events} events")
    
    # Step 2: Bin events
    binned = bin_events(events, bin_width_samples)
    print(f"  Binned into {binned.shape[1]} time bins")
    
    # Step 3: Detect avalanches
    avalanches = detect_avalanches(binned)
    print(f"  Found {len(avalanches)} avalanches")
    
    if len(avalanches) < 10:
        warnings.warn("Too few avalanches for reliable analysis")
        return {'error': 'Insufficient avalanches', 'n_avalanches': len(avalanches)}
    
    # Step 4: Calculate branching ratio
    sigma_direct, sigma_std = branching_ratio_direct(avalanches)
    
    total_activity = np.sum(binned, axis=0)
    sigma_MR = branching_ratio_MR(total_activity)
    
    # Step 5: Fit power laws
    sizes = [av['size'] for av in avalanches]
    durations = [av['duration'] for av in avalanches]
    
    tau, tau_xmin, tau_ks = fit_power_law(sizes)
    alpha, alpha_xmin, alpha_ks = fit_power_law(durations)
    
    # Step 6: Calculate kappa
    kappa = kappa_index(avalanches)
    
    # Step 7: Distribution comparison
    dist_comparison = compare_distributions(sizes)
    
    # Compile results
    results = {
        'n_channels': data.shape[0],
        'n_samples': data.shape[1],
        'duration_sec': data.shape[1] / sfreq,
        'bin_width_ms': bin_width_ms,
        'threshold_sd': threshold,
        
        'n_events': n_events,
        'n_avalanches': len(avalanches),
        'mean_size': np.mean(sizes),
        'mean_duration': np.mean(durations),
        
        'branching_ratio_direct': sigma_direct,
        'branching_ratio_direct_std': sigma_std,
        'branching_ratio_MR': sigma_MR,
        
        'tau': tau,  # Size distribution exponent
        'tau_xmin': tau_xmin,
        'tau_ks': tau_ks,
        
        'alpha': alpha,  # Duration distribution exponent
        'alpha_xmin': alpha_xmin,
        'alpha_ks': alpha_ks,
        
        'kappa': kappa,
        
        'power_law_supported': dist_comparison['power_law_supported'],
        'log_likelihood_ratio': dist_comparison['log_likelihood_ratio'],
        
        'avalanches': avalanches,  # Full data for further analysis
    }
    
    # Criticality assessment
    if sigma_direct is not None and not np.isnan(sigma_direct):
        if 0.95 <= sigma_direct <= 1.05:
            results['state'] = 'critical'
        elif sigma_direct < 0.95:
            results['state'] = 'subcritical'
        else:
            results['state'] = 'supercritical'
    
    return results


def print_summary(results):
    """Print formatted summary of criticality analysis."""
    
    print("\n" + "="*60)
    print("NEURAL CRITICALITY ANALYSIS SUMMARY")
    print("="*60)
    
    print(f"\n📊 Data: {results['n_channels']} channels, {results['duration_sec']:.1f} seconds")
    print(f"⚙️  Parameters: bin={results['bin_width_ms']}ms, threshold={results['threshold_sd']}SD")
    
    print(f"\n📈 Avalanches: {results['n_avalanches']} detected")
    print(f"   Mean size: {results['mean_size']:.2f}")
    print(f"   Mean duration: {results['mean_duration']:.2f} bins")
    
    print(f"\n🎯 BRANCHING RATIO (σ):")
    print(f"   Direct estimate: {results['branching_ratio_direct']:.3f} ± {results['branching_ratio_direct_std']:.3f}")
    print(f"   MR estimate:     {results['branching_ratio_MR']:.3f}")
    
    print(f"\n📐 POWER LAW EXPONENTS:")
    print(f"   τ (size):     {results['tau']:.2f} (critical: 1.5)")
    print(f"   α (duration): {results['alpha']:.2f} (critical: 2.0)")
    
    print(f"\n📏 KAPPA INDEX: {results['kappa']:.3f} (critical: 1.0)")
    
    if 'state' in results:
        state_emoji = {'critical': '✅', 'subcritical': '⬇️', 'supercritical': '⬆️'}
        print(f"\n🧠 STATE: {state_emoji[results['state']]} {results['state'].upper()}")
    
    print("\n" + "="*60)


# =============================================================================
# DEMO / TEST
# =============================================================================

if __name__ == "__main__":
    
    print("Generating synthetic data for testing...")
    
    # Generate synthetic critical data
    # Using branching process simulation
    
    np.random.seed(42)
    
    n_channels = 32
    n_samples = 100000  # ~100 seconds at 1000 Hz
    sfreq = 1000
    
    # Simulate near-critical activity
    sigma_true = 0.98  # Slightly subcritical
    
    # Simple branching process
    data = np.zeros((n_channels, n_samples))
    
    for ch in range(n_channels):
        activity = 0
        for t in range(n_samples):
            # Background noise
            noise = np.random.randn() * 0.5
            
            # Branching propagation
            if np.random.rand() < 0.01:  # Spontaneous activation
                activity = 1
            else:
                activity = np.random.poisson(sigma_true * activity)
            
            data[ch, t] = activity + noise
    
    # Run analysis
    results = analyze_criticality(
        data, 
        sfreq=sfreq, 
        bin_width_ms=4, 
        threshold=2.0
    )
    
    print_summary(results)
    
    print("\n✅ Pipeline test complete!")
    print("Ready for real EEG data analysis.")
