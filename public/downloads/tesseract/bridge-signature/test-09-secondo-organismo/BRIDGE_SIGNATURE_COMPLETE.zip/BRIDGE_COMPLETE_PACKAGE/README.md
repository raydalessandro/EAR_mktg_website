# Bridge Signature Theory - Complete Package

## Summary

This package contains the validation of a theoretical prediction derived from the EAR (Entity-Attribute-Relation) ontological framework:

> **Prediction:** Modulatory neurons (dopamine, serotonin, tyramine/octopamine) should exhibit a "bridge signature" in connectome topology: high degree, high betweenness, low clustering.

## Results

### C. elegans (VALIDATED ✓)
- **p = 0.00003** - Highly significant
- **3.24x over-representation** of modulators among bridge nodes
- All three metric directions confirmed

### Drosophila (INCONCLUSIVE ⚠️)
- Test incomplete due to computational limits
- Partial results suggest different architecture
- Requires further investigation

## Files

### C. elegans (Complete)
- `NeuronConnect.xls` - Connectome data (Varshney et al.)
- `elife-95402-supp2-v1.xlsx` - Official neurotransmitter classification (eLife 2024)
- `bridge_signature_definitive.py` - Analysis script
- `RESULTS.md` - Detailed results

### Drosophila (Partial)
- `flywire_neurons.tsv` - Neuron annotations with neurotransmitter predictions
- `FLYWIRE_PARTIAL_RESULTS.md` - Partial analysis results
- Connection data (812MB) available from: https://zenodo.org/records/10676866

### Status Report
- `BRIDGE_SIGNATURE_STATUS.md` - Complete status overview

## Quick Start (C. elegans)
```bash
pip install pandas networkx numpy scipy xlrd openpyxl
python bridge_signature_definitive.py
```

## Citations
- C. elegans connectome: Varshney et al., PLOS Comp Bio 2011
- Neurotransmitter atlas: Hobert et al., eLife 2024 (doi: 10.7554/eLife.95402)
- FlyWire: Dorkenwald et al., Nature 2024

## Contact
For collaboration on completing Drosophila analysis or testing on additional connectomes.

## Update: Regional Analysis (Drosophila)

New finding: The bridge signature is **context-dependent**.

- **Central Complex**: All directions correct, p = 0.011 ✓
- Other regions: Signature not present

See `DROSOPHILA_REGIONAL_RESULTS.md` for details.

### Refined Theory

> "Modulators are bridges **in integration regions**, not everywhere."

This is more precise and biologically meaningful.
