# FlyWire Drosophila - Risultati Parziali

## Dataset
- **Fonte:** FlyWire Connectome (codex.flywire.ai)
- **Paper:** Dorkenwald et al., Nature 2024
- **Neuroni:** ~139,000
- **Connessioni:** ~16.8 milioni
- **File:** flywire_neurons.tsv (32MB), flywire_connections.feather (812MB)

## Classificazione Neurotrasmettitori

| Tipo | Neurotrasmettitore | Neuroni | % |
|------|-------------------|---------|---|
| Eccitatori (E) | Acetilcolina | 86,188 | 61.9% |
| Eccitatori (E) | Glutammato | 24,875 | 17.9% |
| Inibitori (I) | GABA | 19,170 | 13.8% |
| **Modulatori (M)** | **Dopamina** | **5,909** | **4.2%** |
| **Modulatori (M)** | **Serotonina** | **2,282** | **1.6%** |
| **Modulatori (M)** | **Octopamina** | **216** | **0.2%** |

**Totale Modulatori: 8,407 (6.0%)**

## Risultati Parziali (Soglia ≥20 sinapsi)

Test eseguito su subset con soglia alta per ridurre complessità computazionale.

### Metriche Osservate

| Tipo | N | Grado | Clustering |
|------|---|-------|------------|
| Eccitatori | ~85,000 | ~25 | ~0.15 |
| **MODULATORI** | ~6,000 | **~15** | **~0.065** |
| Inibitori | ~15,000 | ~22 | ~0.12 |

### Delta Modulatori vs Eccitatori
- **Grado: -39%** (modulatori hanno MENO connessioni forti)
- **Clustering: -57%** (modulatori hanno clustering MOLTO più basso) ✓

### Sovra-rappresentazione nei Ponti
- **0.21x** (sotto-rappresentati, non sovra-rappresentati)

## Interpretazione Preliminare

**RISULTATO INATTESO:** In Drosophila, i modulatori NON mostrano la stessa firma di C. elegans.

### Possibili Spiegazioni

1. **Effetto soglia sinaptica**
   - I modulatori in Drosophila hanno connessioni più deboli in media
   - Soglia ≥20 sinapsi potrebbe tagliare preferenzialmente le loro connessioni
   - Test con soglia ≥5 non completato (timeout)

2. **Differenza architettonica**
   - C. elegans: 281 neuroni, sistema compatto
   - Drosophila: 140,000 neuroni, architettura modulare diversa
   - I modulatori potrebbero operare DENTRO moduli, non TRA moduli

3. **Classificazione diversa**
   - In C. elegans: classificazione manuale verificata
   - In FlyWire: classificazione automatica ML (top_nt prediction)

## Status: INCOMPLETO

Il test completo richiede:
1. Calcolo betweenness centrality (troppo lento su 140k nodi)
2. Test con soglie sinapsi multiple
3. Possibile analisi su sottografi specifici (es. mushroom body)

## File Disponibili
- `flywire_neurons.tsv` - Annotazioni neuroni con neurotrasmettitori
- `flywire_connections.feather` - Matrice connessioni (812MB)
