# Bridge Signature Package

## Contenuto

- `BRIDGE_SIGNATURE_PAPER.md` - Paper principale
- `test_real_networks.py` - Test su reti reali (Karate, Florentine, Les Mis)
- `signature_verification.py` - Verifica della firma sul Tesseract 72
- `predictions_analysis.py` - Analisi delle predizioni e scoperta della firma
- `novel_predictions.py` - Test iniziali delle predizioni
- `KILLER_FINDING.md` - Documentazione della scoperta

## Come Usare

```bash
pip install networkx numpy
python test_real_networks.py
```

## La Firma

Un nodo è un "ponte" se:
- grado > media
- betweenness > media  
- clustering < media

## Risultati

| Rete | Broker noti | Identificati |
|------|-------------|--------------|
| Karate Club | Leader 0, 33 | 100% |
| Florentine | Medici | 100% |
| Les Misérables | Valjean et al. | 100% |
