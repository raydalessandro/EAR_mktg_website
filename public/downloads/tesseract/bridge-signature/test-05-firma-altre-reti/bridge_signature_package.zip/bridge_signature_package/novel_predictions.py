"""
PREDIZIONI NOVEL

Da questa posizione (Tesseract validato), cosa predice EAR
che possiamo andare a MISURARE e che NON è già noto?

Criteri:
1. Deve derivare dalla struttura EAR
2. Non deve essere input usato per costruire EAR
3. Deve essere misurabile empiricamente
4. Il risultato non deve essere già noto
"""

print("=" * 70)
print("PREDIZIONI NOVEL DA EAR")
print("=" * 70)

print("""
POSIZIONE ATTUALE:

Sappiamo:
- 72 nodi, 444 archi
- A=2 (⇄) ha grado 13, altri 12
- Asimmetria 1/36 = 12 archi extra
- Pattern robusto e derivabile

Cosa SEGUE da questo che non abbiamo ancora testato?
""")

print("\n" + "=" * 70)
print("PREDIZIONE 1: RAPPORTO K_crit / ASIMMETRIA")
print("=" * 70)

print("""
Dal NANO KERNEL:
- K_crit = 0.35 ± 0.05 (soglia critica)
- Asimmetria Tesseract = 12/432 = 1/36 ≈ 0.028

Rapporto: 0.35 / 0.028 = 12.5 ≈ 12

PREDIZIONE:
K_crit / asimmetria ≈ numero di archi extra = D × A = 12

Questo NON era un input. È una conseguenza.

COME TESTARE:
In qualsiasi sistema che mostra transizione di fase:
- Misura K_crit
- Misura asimmetria strutturale
- Il rapporto dovrebbe essere ≈ 12 (o multiplo di 3)

Se vero in sistemi diversi → non è coincidenza.
""")

print("\n" + "=" * 70)
print("PREDIZIONE 2: CLUSTERING PER ATTRIBUTO")
print("=" * 70)

print("""
Osservato: clustering coefficient totale = 0.4456

PREDIZIONE:
Il clustering coefficient dei nodi A=2 sarà MAGGIORE
di quello dei nodi A=1 e A=3.

Perché? Perché ⇄ crea più triangoli (è più connettivo).

NON L'ABBIAMO ANCORA MISURATO.
""")

# Calcoliamo
import json
from collections import defaultdict

with open('/home/claude/GRAFO_MATRIX_72_EXPANDED.json', 'r') as f:
    graph = json.load(f)

# Costruisci grafo
edges = set()
for edge in graph['edges']:
    key = tuple(sorted([edge['source'], edge['target']]))
    edges.add(key)

neighbors = defaultdict(set)
for e in edges:
    neighbors[e[0]].add(e[1])
    neighbors[e[1]].add(e[0])

def get_A(node):
    parts = node.replace('Σ_', '').split('_')
    return int(parts[1])

def clustering_coef(node):
    neigh = list(neighbors[node])
    if len(neigh) < 2:
        return 0
    triangles = 0
    possible = len(neigh) * (len(neigh) - 1) / 2
    for i in range(len(neigh)):
        for j in range(i+1, len(neigh)):
            if neigh[j] in neighbors[neigh[i]]:
                triangles += 1
    return triangles / possible if possible > 0 else 0

nodes = list(neighbors.keys())
cc_by_A = {1: [], 2: [], 3: []}
for n in nodes:
    A = get_A(n)
    cc_by_A[A].append(clustering_coef(n))

print("\nRISULTATO:")
import numpy as np
for A in [1, 2, 3]:
    print(f"  A={A}: clustering = {np.mean(cc_by_A[A]):.4f}")

avg_1 = np.mean(cc_by_A[1])
avg_2 = np.mean(cc_by_A[2])
avg_3 = np.mean(cc_by_A[3])

if avg_2 > avg_1 and avg_2 > avg_3:
    print("\n✓ PREDIZIONE CONFERMATA: A=2 ha clustering maggiore!")
else:
    print("\n✗ Predizione non confermata")

print("\n" + "=" * 70)
print("PREDIZIONE 3: BETWEENNESS CENTRALITY")
print("=" * 70)

print("""
PREDIZIONE:
I nodi A=2 (⇄) avranno MAGGIORE betweenness centrality.
Perché sono i "connettori" del grafo.

Se vero, conferma che ⇄ è strutturalmente centrale,
non solo localmente più connesso.
""")

# Calcoliamo betweenness (semplificata)
from collections import deque

def bfs_paths(start, end):
    """Conta percorsi minimi da start a end"""
    if start == end:
        return 0, 0
    visited = {start: 0}
    queue = deque([(start, 0)])
    paths_count = defaultdict(int)
    paths_count[start] = 1
    
    while queue:
        node, dist = queue.popleft()
        for neighbor in neighbors[node]:
            if neighbor not in visited:
                visited[neighbor] = dist + 1
                paths_count[neighbor] = paths_count[node]
                queue.append((neighbor, dist + 1))
            elif visited[neighbor] == dist + 1:
                paths_count[neighbor] += paths_count[node]
    
    return visited.get(end, -1), paths_count.get(end, 0)

# Betweenness semplificata: quante volte un nodo è su percorso minimo
# (calcolo approssimato per velocità)
print("\nCalcolo betweenness (campione)...")

import random
random.seed(42)
sample_pairs = random.sample([(a,b) for a in nodes for b in nodes if a < b], 500)

betweenness = defaultdict(float)
for start, end in sample_pairs:
    # BFS da start
    visited = {start: 0}
    parents = defaultdict(list)
    queue = deque([start])
    
    while queue:
        node = queue.popleft()
        for neighbor in neighbors[node]:
            if neighbor not in visited:
                visited[neighbor] = visited[node] + 1
                parents[neighbor].append(node)
                queue.append(neighbor)
            elif visited[neighbor] == visited[node] + 1:
                parents[neighbor].append(node)
    
    if end not in visited:
        continue
    
    # Backtrack per contare contributi
    dependency = defaultdict(float)
    ordered = sorted(visited.keys(), key=lambda x: -visited[x])
    
    for node in ordered:
        if node == end:
            dependency[node] = 1
        for parent in parents[node]:
            dependency[parent] += dependency[node] / len(parents[node])
        if node != start and node != end:
            betweenness[node] += dependency[node]

betweenness_by_A = {1: [], 2: [], 3: []}
for n in nodes:
    A = get_A(n)
    betweenness_by_A[A].append(betweenness[n])

print("\nRISULTATO:")
for A in [1, 2, 3]:
    print(f"  A={A}: betweenness medio = {np.mean(betweenness_by_A[A]):.2f}")

avg_1 = np.mean(betweenness_by_A[1])
avg_2 = np.mean(betweenness_by_A[2])
avg_3 = np.mean(betweenness_by_A[3])

if avg_2 > avg_1 and avg_2 > avg_3:
    print("\n✓ PREDIZIONE CONFERMATA: A=2 ha betweenness maggiore!")
    print(f"  Rapporto A=2/A=1: {avg_2/avg_1:.2f}x")
    print(f"  Rapporto A=2/A=3: {avg_2/avg_3:.2f}x")
else:
    print("\n✗ Predizione non confermata")

print("\n" + "=" * 70)
print("PREDIZIONE 4: ROBUSTEZZA A RIMOZIONE NODI")
print("=" * 70)

print("""
PREDIZIONE:
Rimuovere nodi A=2 danneggerà la connettività del grafo
PIÙ di rimuovere nodi A=1 o A=3.

Perché A=2 è strutturalmente centrale.
""")

def is_connected(edge_set, node_set):
    """Verifica se il grafo è connesso"""
    if not node_set:
        return True
    start = next(iter(node_set))
    visited = {start}
    queue = deque([start])
    while queue:
        node = queue.popleft()
        for e in edge_set:
            if e[0] == node and e[1] in node_set and e[1] not in visited:
                visited.add(e[1])
                queue.append(e[1])
            elif e[1] == node and e[0] in node_set and e[0] not in visited:
                visited.add(e[0])
                queue.append(e[0])
    return len(visited) == len(node_set)

def average_path_length(edge_set, node_set):
    """Calcola lunghezza media dei percorsi"""
    if len(node_set) < 2:
        return 0
    
    neigh = defaultdict(set)
    for e in edge_set:
        if e[0] in node_set and e[1] in node_set:
            neigh[e[0]].add(e[1])
            neigh[e[1]].add(e[0])
    
    total = 0
    count = 0
    sample = random.sample(list(node_set), min(20, len(node_set)))
    
    for start in sample:
        visited = {start: 0}
        queue = deque([start])
        while queue:
            node = queue.popleft()
            for neighbor in neigh[node]:
                if neighbor not in visited:
                    visited[neighbor] = visited[node] + 1
                    queue.append(neighbor)
        for n, d in visited.items():
            if d > 0:
                total += d
                count += 1
    
    return total / count if count > 0 else float('inf')

# Test rimozione
print("\nTest rimozione 4 nodi per attributo:")

nodes_by_A = {1: [], 2: [], 3: []}
for n in nodes:
    nodes_by_A[get_A(n)].append(n)

random.seed(42)
for A in [1, 2, 3]:
    to_remove = set(random.sample(nodes_by_A[A], 4))
    remaining_nodes = set(nodes) - to_remove
    remaining_edges = {e for e in edges if e[0] not in to_remove and e[1] not in to_remove}
    
    connected = is_connected(remaining_edges, remaining_nodes)
    avg_path = average_path_length(remaining_edges, remaining_nodes)
    
    print(f"  Rimuovo 4 nodi A={A}: connesso={connected}, path_medio={avg_path:.2f}")

print("""
INTERPRETAZIONE:
Se rimuovere A=2 causa più danni (path più lungo o disconnessione),
conferma che ⇄ è strutturalmente critico.
""")

print("\n" + "=" * 70)
print("PREDIZIONE 5: SPECTRAL GAP")
print("=" * 70)

print("""
PREDIZIONE AVANZATA:

Il sottografo indotto dai nodi A=2 avrà uno spectral gap
DIVERSO dai sottografi A=1 e A=3.

Lo spectral gap misura quanto è "connesso" il grafo.
Se A=2 è più connettivo, il suo spectral gap dovrebbe essere maggiore.

Questo richiede calcolo della matrice Laplaciana.
""")

# Calcolo spectral gap per sottografi
def laplacian_spectral_gap(node_subset, edge_set):
    """Calcola spectral gap del sottografo indotto"""
    nodes_list = sorted(node_subset)
    n = len(nodes_list)
    if n < 2:
        return 0
    
    node_idx = {node: i for i, node in enumerate(nodes_list)}
    
    # Costruisci matrice di adiacenza
    adj = np.zeros((n, n))
    for e in edge_set:
        if e[0] in node_subset and e[1] in node_subset:
            i, j = node_idx[e[0]], node_idx[e[1]]
            adj[i, j] = 1
            adj[j, i] = 1
    
    # Matrice Laplaciana: L = D - A
    degree = np.sum(adj, axis=1)
    laplacian = np.diag(degree) - adj
    
    # Autovalori
    eigenvalues = np.linalg.eigvalsh(laplacian)
    eigenvalues = np.sort(eigenvalues)
    
    # Spectral gap = secondo autovalore più piccolo (primo è sempre 0)
    return eigenvalues[1] if len(eigenvalues) > 1 else 0

print("\nCalcolo spectral gap per sottografi:")
for A in [1, 2, 3]:
    node_set = set(nodes_by_A[A])
    gap = laplacian_spectral_gap(node_set, edges)
    print(f"  A={A}: spectral gap = {gap:.4f}")

