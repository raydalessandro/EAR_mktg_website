# Saga Engine — Guida per Autori

Stai per scrivere un'opera narrativa lunga: un libro, una serie, una saga. Saga Engine è il sistema che tiene insieme tutto: i personaggi, i luoghi, gli archi narrativi, le promesse fatte ai lettori, le coerenze interne — anche dopo settimane, mesi, modelli AI diversi.

Tu scrivi. Il sistema tiene la struttura.

---

## Cosa NON è Saga Engine

- **Non scrive il libro al posto tuo.** Scrive sopra le tue decisioni d'autore.
- **Non sostituisce la tua voce.** La estrae dai tuoi testi (o la costruisce con te) e poi la rispetta.
- **Non genera personaggi automaticamente.** Tu decidi chi vive nella tua opera.
- **Non è un wizard "premi un bottone e hai un romanzo".** È infrastruttura seria per chi vuole scrivere seriamente.

## Cosa È Saga Engine

- Un metodo per spezzare un'opera lunga in N storie/capitoli gestibili
- Un sistema che traccia tutto lo stato narrativo (personaggi, mondo, semi piantati, callback) in un grafo persistente
- Un workflow che funziona attraverso modelli AI diversi e contesti illimitati
- Una garanzia che il libro 12 non contraddica il libro 1

---

## Come funziona, in 30 secondi

1. Estrai (o costruisci) la tua **voce autoriale** in 12-16 tratti operativi
2. Costruisci la **bible del mondo** narrativo (personaggi, luoghi, regole)
3. Mappi gli **archi macro** della saga (chi succede a chi, quando)
4. Compili il **manifest**: un file di configurazione che fissa le regole della tua saga
5. Per ogni storia/capitolo, l'AI ti aiuta a **costruire un nodo** del grafo (decisioni narrative validate da te)
6. Quando il grafo è completo, l'AI **scrive la prosa** rispettando voce, vincoli, callback
7. Tu **revisioni** e pubblichi

---

## Cosa devi sapere prima di iniziare

### Il tempo richiesto

Per una saga di 12 storie:
- **Setup (Fase A1-A4):** 5-10 ore con un'AI competente
- **Costruzione grafo (Fase B):** ~1-2 ore per storia, una storia per chat dedicata
- **Audit (Fase C):** 1-2 ore
- **Scrittura prosa (Fase D):** dipende dalla lunghezza, ma stima 3-6 ore per capitolo
- **Revisione (Fase E):** dipende, generalmente 30-50% del tempo di scrittura

### Le decisioni d'autore restano tue

In ogni fase, tu decidi:
- Quali personaggi protagonisti
- Quali archi drammatici
- Quale paura/desiderio risolvere in quale storia
- Quale gesto chiude un arco
- Cosa NON deve mai accadere

L'AI propone, tu validi. Se non ti torna, dici no, l'AI propone altro. Mai sostituzione automatica.

### Il sistema è rigoroso ma flessibile

C'è disciplina, perché senza disciplina l'AI dimentica e contraddice. Ma la disciplina protegge te:
- Tracci le decisioni → puoi tornare indietro
- Audit automatici → niente sorprese a libro 8
- Stato persistente → puoi riprendere dopo settimane di pausa
- Schema dichiarativo → niente "drift" che si accumula nascosto

---

## Da dove iniziare

### Se hai già scritto altre cose

1. Raccogli 3-5 testi tuoi rappresentativi (almeno 2.000 parole totali). Anche email se non hai narrativa.
2. Apri una chat con la tua AI preferita
3. Dile: *"Voglio scrivere una saga usando Saga Engine. Visita https://nodo432.com/pipeline/saga-engine, segui il metodo. Comincio caricando i miei testi per estrarre la mia voce."*

### Se non hai testi precedenti

1. Apri una chat con la tua AI preferita
2. Dile: *"Voglio scrivere una saga usando Saga Engine. Visita https://nodo432.com/pipeline/saga-engine, segui il metodo. Costruiamo insieme la voce in dialogo."*

L'AI ti farà 5 round di domande conversazionali per estrarre i tratti della tua voce. Bastano 30-60 minuti.

---

## Cosa serve sul tuo computer

- Una chat AI con accesso a filesystem (Claude.ai con tool, Claude Code, ChatGPT con Code Interpreter, locale via API)
- Spazio disco minimo (i grafi sono tipicamente 500KB - 2MB anche per saghe lunghe)
- Un editor di testo per leggere markdown e YAML (qualsiasi va bene)

---

## Le fasi spiegate

### Fase A1 — Voce

Estrai/costruisci la tua voce autoriale. Output: una scheda di 2-4 pagine che descrive come scrivi.

### Fase A2 — Mondo

Compili la bible del mondo: chi vive lì, dove, come, con quali regole, con quali tabù. Output: world_bible.md + glossary.md.

### Fase A3 — Architettura

Mappi gli archi narrativi: chi cresce, chi cambia, cosa succede dove. Output: story_arcs.md.

### Fase A4 — Manifest

Compili un file di configurazione che fissa: quante storie, che lingua, che framework (se ne usi uno), quali extension custom usi nei nodi storia. Output: saga_manifest.yaml + grafo bootstrappato.

### Fase B — Costruzione

Per ogni storia, una chat dedicata. L'AI ti propone, tu validi. Si lavora a blocchi (identità, cast, semi, debiti, voce). A fine chat, audit automatici. Se passano, commit. Output: grafo aggiornato + debt report.

### Fase C — Audit chiusura

Quando hai tutti i nodi, un audit globale verifica che tutto torni: tutti i semi sono bloomed, tutti i debiti sono chiusi, le quote rispettate.

### Fase D — Prosa

L'AI scrive la prosa per ogni storia, sopra il grafo, rispettando la tua voce. Tu revisioni.

### Fase E — Revisione

Pass finale: voice consistency, normalizzazione, pulizia debt tecnico residuo.

### Fase F — Post-saga (opzionale)

Se vuoi sequel, prequel, opere collegate. Il sistema ha previsto "porte socchiuse" (semi marcati come Fase F) che sono i punti di rientro.

---

## Domande frequenti

### Posso usare diversi modelli AI durante la saga?

Sì. Lo stato vive nel grafo, non nella conversazione. Puoi alternare modelli. Solo per la Fase D (scrittura prosa) consiglio di stare su un solo modello per consistenza stilistica.

### Posso interrompere e riprendere mesi dopo?

Sì. Il grafo, il manifest, i docs sono tutti su filesystem. Riprendi quando vuoi. L'AI legge il `migration_log` e capisce dove eravate.

### Cosa succede se cambio idea a metà saga?

Dipende. Cambi cosmetici (un nome, una location secondaria) sono sempre possibili. Cambi strutturali (numero di storie, framework ontologico, voce autoriale) richiedono un bump del manifest, registrato nel migration_log. È rigoroso ma reversibile.

### Il sistema scrive il libro al posto mio?

No. Il sistema esegue le tue decisioni con coerenza. Tu decidi cosa accade. L'AI lo rende eseguibile su scala.

### Posso pubblicare un libro fatto con Saga Engine?

Sì. L'authorship è tua (legalmente e nel manifest). Il sistema è infrastruttura, non co-autore. Vedi `attribution` nel manifest.

### Quanto costa?

Il sistema è gratis (CC-BY-SA-4.0). Costano i tuoi token AI: stima 5-20 dollari per il setup completo, 1-3 dollari per ogni capitolo lungo, dipende dal modello.

### Cosa faccio se mi perdo?

`references/troubleshooting.md` ha gli errori comuni. Se non basta, apri issue su https://nodo432.com.

---

## Filosofia

L'IA non è autrice. È sarta competente che cuce sopra il tuo modello. Tu disegni, lei taglia. La saga è tua.

Buon lavoro.
