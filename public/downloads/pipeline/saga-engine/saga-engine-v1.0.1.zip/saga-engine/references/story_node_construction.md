# Story Node Construction — Fase B

Protocollo per costruire un nodo storia del grafo. Una storia per chat dedicata.

---

## Pre-requisiti

Prima di iniziare a costruire S_NN, verifica:

- [ ] Il manifest è compilato e il grafo bootstrappato (Fase A4 completa)
- [ ] La voice_card è disponibile (Fase A1)
- [ ] La world_bible è disponibile (Fase A2)
- [ ] story_arcs.md descrive l'arco di S_NN (Fase A3)
- [ ] Le storie precedenti S_(NN-1), S_(NN-2) hanno nodi committati nel grafo
- [ ] L'ultimo debt_report è disponibile

Se manca anche un solo elemento, NON procedere. Risolvi prima.

---

## Workflow per ogni storia

### Step 1 — Lettura preparatoria

Leggi in ordine:

1. `story_arcs.md` per l'arco S_NN
2. Ultimo `debt_tracking_s<NN-1>.md` per capire cosa aspetta S_NN (seeds da pickup, bloom target, debts da chiudere)
3. `manifest/saga_manifest.yaml` per vincoli globali e extension dichiarate
4. `graph/story_graph_v<X>.json` per stato attuale (seeds critici, quote_tracker, struttura nodi recenti)
5. `voice_card.md` per la voce
6. `references/anti_patterns.md` per ricordare cosa evitare

### Step 2 — Fotografia pre-S_NN all'utente

Presenta all'utente una foto strutturata pre-storia:

```markdown
## Pre-storia S_NN: <titolo arco>

**Seeds da toccare obbligatoriamente:**
- seed_X (status maturing → bloom target S_NN)
- seed_Y (pickup atteso)

**Debts targettati su S_NN:**
- debt_Z aperto in S_(NN-2), atteso closure qui

**Constraints attivi rilevanti:**
- constraint_A
- constraint_B

**Quota tracker stato:**
- tracker_X: 2/4 usati
- tracker_Y: 1/2 usati

**Discrepanze tra ARCHI e grafo (se trovate):**
- ...
```

Chiedi all'utente: "Confermi questo quadro o vediamo qualcosa diversamente?"

### Step 3 — Briefing preventivo

Domande in batch sulle scelte d'autore irriducibili che la storia richiede.

Esempi tipici:
- Chi sostituisce X come catalizzatore della scena pivot?
- Quale gesto chiude l'arco di Y?
- Dove avviene la threshold moment (luogo specifico)?
- Quale frase chiave (se prevista)?
- Stagione/transizione stagionale?

Il briefing è batch: poni 3-7 domande in un colpo, l'utente risponde quando vuole, l'agente non si interrompe più per la storia.

### Step 4 — Ragionamento a blocchi

Procedi a blocchi narrativi, uno alla volta, con validazione utente prima del successivo. **NON mostrare JSON pieno a blocchi intermedi.** Usa structured summary in prosa + tabelle/liste.

Blocchi tipici (adattali al caso):

1. **Identità storia + luoghi**: id, titolo, posizione strutturale, stagione, location_primary + secondary
2. **Cast**: characters_in_scene + offscreen/background
3. **Tracking narrativo**: seeds_planted/picked_up/bloomed/maturing + update seeds esistenti
4. **Debts**: opened, closed, callbacks_made
5. **Visual e voce**: visual_anchors, key_phrase, voice_notes_essential, structural_notes
6. **Quote tracker + entity updates + migration_log**
7. **Campi narrativi storia**: premise, problem, threshold_moment, resolution_mode, palette_emotiva, callback_summary

Per ogni blocco:
- Proponi
- L'utente conferma o corregge
- Vai al blocco successivo

### Step 5 — Commit

Quando tutti i blocchi sono validati:

1. Esegui `scripts/build_story_node.py` con il dizionario costruito
2. Esegui `scripts/audit_0_canonical_fields.py` (gate)
3. Esegui `scripts/audit_1_integrity.py` (gate)
4. Esegui `scripts/audit_2_schema.py` (gate)
5. Esegui `scripts/audit_3_navigability.py` (gate)
6. Esegui `scripts/audit_4_drift.py` (diagnostico)

Se uno dei 4 gate fallisce, NON commit. Mostra l'errore all'utente, chiedi come procedere.

### Step 6 — Output finale

Produci 3 artefatti in `audits/` e `graph/`:

1. `graph/story_graph_v<X+1>.json` — grafo aggiornato
2. `graph/s<NN>_node.json` — nodo standalone con metadati
3. `audits/debt_tracking_s<NN>.md` — mini-report debt

---

## Schema canonico nodo storia

Ogni nodo DEVE contenere:

### Campi core obbligatori (31 campi)

Vedi `assets/templates/saga_graph_template_v1_0.json` blocco `stories._schema.core_fields`.

### Campi extension dichiarati nel manifest

Tutti i campi dichiarati in `manifest.extensions.story_node` devono essere presenti, anche se a `null`. La presenza/assenza non deve mai trasportare informazione semantica.

### Convenzioni operative

- Snake_case per tutti gli ID
- Tag MAIUSCOLI nei voice_notes/structural_notes (es. `ADDRESS_AL_LETTORE_IN_CHIUSURA`)
- Tag strutturati tra parentesi quadre dentro stringhe lunghe (es. `[MECHANICS]`, `[SIGILLO]`)
- Nessun campo null per i core obbligatori (eccetto quelli marcati nullable nello schema)
- Per extension non applicabili a una storia: usa `null` (string) o `[]` (array), MAI omettere il campo

---

## Gestione debito tecnico

Durante la saga è normale che emergano drift, decisioni da rinviare, convenzioni nuove. Regola:

- **Scarto piccolo** (1-2 nodi con 1-2 campi diversi): tollera, registra come `deferred_decision` nel migration_log, uniforma alla chiusura saga
- **Scarto medio** (3+ nodi o 3+ campi): segnala all'utente, proponi se uniformare subito o rinviare
- **Massa critica raggiunta**: se hai info sufficiente per decidere la forma canonica definitiva, uniforma SUBITO (retrofill dei nodi disallineati)

I `deferred_decisions` vanno SEMPRE registrati nel `migration_log[].deferred_decisions` della storia in cui emergono, con nota di quando verranno risolte.

---

## Cose da NON fare

- Non scrivere prosa per la storia in questa fase. Solo costruzione del nodo grafo.
- Non saltare i gate di audit.
- Non inventare campi extension non dichiarati nel manifest.
- Non chiudere troppo i finali (no morali, no corsivi esplicativi) se il manifest dichiara `target.reading_layers > 1`.
- Non far pronunciare ai personaggi cose che violino i tabù della world_bible.
- Non inserire callback non registrati esplicitamente.
- Non bypassare la fotografia pre-storia step 2.
