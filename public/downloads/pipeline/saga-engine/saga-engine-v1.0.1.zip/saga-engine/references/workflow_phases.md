# Workflow Phases — saga-engine

Dettaglio di ogni fase del workflow saga-engine. Leggi quella che ti serve quando l'utente è in quella fase.

---

## Fase A1 — Voice Extraction

**Obiettivo:** estrarre o costruire la voce autoriale operativa che guiderà tutta la prosa della saga.

**Output:** `docs/voice_card.md` compilato.

### Caso 1: l'autore ha testi già scritti

Chiedi all'utente di caricare 3-5 testi rappresentativi (almeno 2.000 parole totali) della sua voce — possono essere racconti, articoli, post, anche email se non ha scritto narrativa. Più materiale = estrazione più precisa.

Leggi tutti i testi. Estrai 12-16 tratti operativi della voce. Per ogni tratto:
- **Nome del tratto** (es. "Periodo breve secco")
- **Manifestazione**: come si vede nel testo
- **Esempio dal corpus dell'utente**: 2-3 frasi reali
- **Trigger**: in quali contesti emerge

Mostra l'estrazione all'utente, raccogli feedback, raffina. La voice card finale è un documento di 2-4 pagine che funziona da bussola operativa.

### Caso 2: l'autore non ha testi (costruzione collaborativa)

Dialogo guidato in più round:

**Round 1 — Affinità.** Quali autori ami leggere? Quali frasi ti hanno colpito di recente? Cosa ti annoia in chi scrive male?

**Round 2 — Tono.** Sei più asciutto o lirico? Preferisci frasi brevi o periodi articolati? Aggettivi tanti o pochi? Metafore frequenti o rare?

**Round 3 — Lessico.** Quali parole eviti? Quali ti suonano "tue"? Hai un lessico tecnico/dialettale/regionale?

**Round 4 — Punteggiatura e ritmo.** Trattini lunghi sì/no? Punto e virgola? Periodi spezzati con il punto? Parlato dei personaggi staccato o integrato?

**Round 5 — Tabù.** Cosa NON faresti mai? (es. moralina esplicita, descrizioni fisiche dettagliate, riassunti tra una scena e l'altra)

Sintetizza in 12-16 tratti come nel Caso 1.

### Best practices

- La voice card NON contiene contenuti narrativi specifici della saga (no nomi personaggi, no luoghi). Solo tratti universali della voce.
- Includi sempre 2-3 esempi pratici per tratto (frasi inventate o estratte) per orientare il modello in scrittura.
- Includi una sezione "registri ammessi" (es. lirico+asciutto+ironico) e una "registri vietati" (es. didattico, sentimentale, melodrammatico).

---

## Fase A2 — World Building

**Obiettivo:** costruire la bible del mondo narrativo. È il terreno su cui ogni storia poggia.

**Output:** `docs/world_bible.md` + `docs/glossary.md`

### Struttura della world bible

Vedi `assets/templates/world_bible_template.md` per il template. Sezioni minime:

1. **Identità del mondo** — quando, dove, in che genere
2. **Geografia** — fisica, simbolica, mappe se utili
3. **Personaggi** — protagonisti, secondari, gruppi, antagonisti, voce di ognuno
4. **Tempo e stagioni** — calendario narrativo, stagioni, fasi se applicabile
5. **Sistema dei vincoli** — cosa è possibile e cosa no nel mondo (magia, tecnologia, regole sociali)
6. **Mito di fondazione** — se rilevante, l'origine del mondo
7. **Tabù e linee rosse** — cosa NON deve mai accadere
8. **Pattern silenti** — meta-pattern che attraversano la saga senza essere mai nominati

### Glossario

Lista snake_case di tutti i nomi propri (luoghi, personaggi, oggetti, concetti) con definizione asciutta. Funziona da fonte di verità per agenti che leggono il grafo.

### Domande a freddo all'utente

Prima di scrivere la bible, fai 5-10 domande preventive:
- Chi è il protagonista (singolo, gruppo, alternato)?
- Quanto è grande il mondo (un villaggio, un pianeta, un universo)?
- Che genere è (realistico, fantastico, sci-fi, ibrido)?
- Quali sono le 3 cose che NON devono mai succedere in questo mondo?
- C'è un meta-pattern silente (un'idea che attraversa la saga senza essere nominata)?
- C'è un framework ontologico nascosto (es. archetipi, struttura simbolica)?

---

## Fase A3 — Saga Architecture

**Obiettivo:** mappa macro degli archi narrativi della saga.

**Output:** `docs/story_arcs.md`

### Cosa contiene

Per ogni storia/capitolo della saga (S1...SN):
- **Titolo provvisorio**
- **Premessa** (3-5 righe): cosa succede in questa storia
- **Problema**: il conflitto narrativo
- **Posizione**: apertura/centro/chiusura blocco, attribute dominante, ecc.
- **Personaggi in scena**
- **Connessioni con altre storie**: semi piantati qui che bloomano altrove, callback ad altre storie
- **Vincoli toccati**: quali constraint globali questa storia attiva

### Tetto e disciplina

- Numero totale storie deciso a priori (es. 12, 20, 50). Se si scopre dopo che ne servono di più, è bump del manifest.
- Ogni storia ha posizione strutturale dichiarata (es. "apertura blocco A", "centro saga", "chiusura").
- Le connessioni inter-storia sono mappate qui. Saranno tradotte in seeds e callbacks nel grafo.

### Rapporto con il grafo

`story_arcs.md` è la **vista umana** della saga. Il **grafo** è la vista macchina. Sono fonti di verità separate ma allineate. Quando l'agente costruisce un nodo storia (Fase B), legge sia ARCHI che il grafo.

---

## Fase A4 — Manifest Initialization

**Obiettivo:** compilare il `saga_manifest.yaml` e bootstrappare il grafo.

**Output:** `manifest/saga_manifest.yaml` + `graph/story_graph_v0_1_0.json`

### Step

1. Copia `assets/templates/saga_manifest_template.yaml` in `manifest/saga_manifest.yaml`
2. Compila tutti i campi del manifest con dialogo all'utente (vedi commenti nel template)
3. Scelta cruciale: **quali extension dichiarare** per character, location, object, story_node, entities_collections
4. Esegui `scripts/bootstrap_saga.py` che legge il manifest e produce il grafo iniziale popolato

### Disciplina

Una volta che il manifest è compilato e il grafo bootstrappato, **NON puoi più aggiungere extension a runtime**. Devi:
1. Editare il manifest aggiungendo l'extension nel namespace giusto
2. Bumpare `manifest_version` (es. 1.0 → 1.1)
3. Eseguire `scripts/bump_manifest.py` che retrofila il grafo (aggiunge il campo nuovo a tutti gli story node con valore null/empty)
4. Registrare il bump nel `migration_log` del grafo

---

## Fase B — Story-by-Story Construction

**Obiettivo:** costruire i nodi storia uno alla volta, in chat dedicata, con audit pre-commit.

**Output:** grafo aggiornato per ogni storia + debt_report

Vedi `references/story_node_construction.md` per il protocollo completo.

---

## Fase C — Audit Completo

**Obiettivo:** audit globale di chiusura saga. Tutti i seeds devono essere bloomed o closed. Tutti i debt devono essere chiusi. Tutte le quote rispettate.

**Output:** `audits/audit_report_final.md`

### Esegui

```bash
python scripts/run_all_audits.py --final
```

Il flag `--final` attiva controlli aggiuntivi:
- Nessun seed in status `seminato` o `maturing` (eccetto seeds intenzionalmente lasciati per Fase F, marcati come tali)
- Nessun debt aperto non risolto
- Tutti gli archi narrativi dichiarati in story_arcs.md hanno corrispondenza nel grafo
- Tutte le extension dichiarate sono utilizzate almeno una volta

---

## Fase D — Prose Writing

**Obiettivo:** scrivere la prosa effettiva sopra il grafo.

**Output:** manuscript completi (uno per storia, in markdown o docx)

### Approccio

Per ogni storia, l'agente:
1. Carica voice_card.md, world_bible.md, glossary.md
2. Carica il nodo storia dal grafo
3. Scrive la prosa rispettando: voce autoriale, vincoli del grafo, callbacks dichiarati, palette emotiva, threshold moment, resolution mode, key phrase
4. NON aggiunge eventi che non sono nel grafo
5. NON omette eventi che sono nel grafo
6. Sottopone la prosa all'utente per validazione

### Disciplina

La prosa è esecuzione. Le decisioni sostanziali sono già prese (sono nel grafo). Se durante la scrittura emerge la necessità di una decisione narrativa nuova, FERMA la prosa, torna al grafo, fai validare la decisione, aggiorna grafo, riprendi prosa.

---

## Fase E — Revision

**Obiettivo:** revisione e normalizzazione finale.

**Output:** manuscript publishable

### Tasks tipici

- Normalizzare tutto il debito tecnico residuo (deferred decisions del migration_log)
- Allineare manuscript con eventuali aggiornamenti dei docs di progetto
- Pass di voice consistency: leggere tutti i manuscript di seguito e identificare drift di voce
- Pass di anti-pattern: identificare tic AI ricorrenti e correggerli

---

## Fase F — Post-Saga (opzionale)

**Obiettivo:** estensioni post-saga (sequel, prequel, opere collegate).

Non è automatica. Si attiva solo se l'autore decide di tornarci. I seeds Fase F (lasciati intenzionalmente in `seminato` con suffisso `_fase_f`) sono i punti di rientro.

Se attivata, si crea un nuovo `saga_manifest` per Fase F (saga separata) che eredita parti del mondo dalla saga principale.
