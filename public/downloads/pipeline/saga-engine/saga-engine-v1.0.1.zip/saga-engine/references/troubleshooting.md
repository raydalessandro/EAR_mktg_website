# Troubleshooting

Errori comuni durante l'uso saga-engine e come risolverli.

---

## Errori di setup

### "Filesystem non disponibile"

**Sintomo:** L'agente non può creare la directory della saga.

**Causa:** Stai usando un'interfaccia chat senza filesystem (es. Claude.ai chat senza tool, ChatGPT senza Code Interpreter).

**Fix:** Usa un ambiente con filesystem persistente:
- Claude Code (consigliato per uso continuativo)
- Claude.ai con tool filesystem abilitato
- ChatGPT con Code Interpreter / Advanced Data Analysis
- Locale via API + script Python

Senza filesystem la skill non funziona — lo stato narrativo deve persistere su disco.

### "Manifest YAML non parsa"

**Sintomo:** `bootstrap_saga.py` fallisce con errore YAML parsing.

**Causa:** Errori comuni:
- Indentazione mista tab/spazi
- Stringhe con caratteri speciali non quotate
- Liste mal formattate

**Fix:** Validazione preliminare con `python -c "import yaml; yaml.safe_load(open('saga_manifest.yaml'))"`. Se fallisce, l'errore mostra la riga problematica.

### "Schema validation failed: extension X not declared"

**Sintomo:** Audit_2 fallisce dicendo che un campo nel grafo non è dichiarato.

**Causa:** Un nodo storia ha un campo extension che non è in `extensions_declared` del manifest.

**Fix:** Due opzioni:
1. **Se il campo è genuinamente necessario per la saga:** edita il manifest aggiungendolo nel namespace giusto (es. `extensions.story_node`), bump manifest_version, esegui `bump_manifest.py` per retrofill.
2. **Se il campo è stato aggiunto per errore:** rimuovilo dal nodo storia. Non doveva esserci.

---

## Errori di workflow

### "Audit fallisce ma l'utente vuole proseguire"

**Sintomo:** Audit_3 segnala saldo debt > 0 a chiusura saga, ma l'utente dice "ignora, è chiusura accettabile".

**Fix:** NON committare con audit rosso senza tracciamento esplicito. Procedura corretta:

1. Mostra l'errore all'utente
2. Discutete la causa
3. Se l'utente conferma di voler accettare, registra come `deferred_decision` nel migration_log con:
   - Causa
   - Motivazione utente
   - Quando dovrà essere risolto (Fase E? mai?)
4. Solo allora procedi
5. L'audit globale finale leggerà il migration_log e saprà che il drift è intenzionale

Il principio: drift accettato esplicitamente è ok. Drift bypassato silenziosamente è bug.

### "Sono a S5 e mi accorgo che il manifest è sbagliato"

**Sintomo:** A storia S5 emerge che un'extension dichiarata in A4 non funziona, o ne manca una essenziale.

**Fix:**

**Caso A — Aggiungere nuova extension:** OK, è il flusso normale. Bump manifest_version, retrofill, prosegui.

**Caso B — Rimuovere extension dichiarata:** Problematico. Le storie precedenti la usano. Tre opzioni:
1. **Lasciala dichiarata anche se non più usata.** Non costa nulla.
2. **Rimuovila e accetta drift di schema.** Audit segnala. Va tracciato come deferred.
3. **Bump MAJOR del template (v1.0 → v2.0).** Riscrittura schema. Solo se davvero necessario.

Default: opzione 1.

**Caso C — Modificare il significato di un'extension dichiarata:** Vietato. Equivale a un breaking change. Se servono cambiamenti, dichiara una NUOVA extension con nome diverso e migra i contenuti.

---

## Errori di costruzione storia

### "Non trovo seed_X nel grafo"

**Sintomo:** Stai costruendo S5, vuoi fare pickup di seed_X, ma non lo trovi.

**Cause possibili:**
1. Il seed è nel grafo con nome diverso (es. typo)
2. Il seed non è mai stato piantato (errore in storie precedenti)
3. Lo stai cercando nel posto sbagliato (es. cerchi in `seeds.s01.X` ma è in `seeds.X` con `origin_story: s01`)

**Fix:** Esegui ricerca fuzzy nel grafo:

```python
import json
graph = json.load(open('story_graph_vX.json'))
for sid, seed in graph['seeds'].items():
    if 'X' in sid or 'X' in seed.get('description', ''):
        print(sid, seed.get('origin_story'))
```

Se davvero non esiste, decisione: pianificalo retroattivamente in S1-S4 (raro, costoso) o dichiaralo come seed nuovo piantato in S5.

### "Personaggio appare in S5 ma non è nel grafo entities"

**Sintomo:** Costruendo S5 menzioni un personaggio (es. "Vecchio del Bosco") che non esiste in `entities.characters`.

**Fix:** Aggiungilo al grafo PRIMA di referenziarlo nel nodo storia. Step:

1. Discuti con l'utente: chi è questo personaggio? È protagonista? Secondario? Cammeo?
2. Aggiorna `world_bible.md` se è un personaggio rilevante
3. Aggiungi a `entities.characters.<id>` con tutti i campi core obbligatori
4. Solo allora referenzialo in `characters_in_scene` di S5

NON inventare personaggi inline nei nodi storia. Tutti i personaggi vivono in entities.

### "Voce dell'utente non riesce a uscire dalla pagina"

**Sintomo:** Scrivi prosa in Fase D, l'utente dice "non sembra mia voce".

**Fix:**

1. Rileggi `voice_card.md` con attenzione
2. Identifica i 3 tratti più caratteristici (quelli più rari nelle voci AI standard)
3. Aumenta deliberatamente la presenza di quei tratti nella prosa
4. Mostra una sezione corretta all'utente, raccogli feedback

Se persiste, possibile che la voice card sia troppo generica. Estrai voce con più materiale dell'autore o approfondisci il dialogo collaborativo.

---

## Errori di sistema

### "Grafo cresce troppo, chat fatica a caricarlo"

**Sintomo:** Il grafo è diventato grande (>200KB), agenti faticano a leggerlo per intero.

**Fix:** Strategia split:

1. **Mantieni il grafo unico canonico** sul filesystem. Mai dividerlo realmente.
2. **Per ogni chat di costruzione storia**, l'agente legge solo le sezioni pertinenti:
   - Tutto `entities` (rimane sempre necessario)
   - `seeds` con status `seminato` o `maturing` o targettati su S_NN
   - `callbacks` registrati nelle 3 storie precedenti
   - Solo i 2-3 nodi storia precedenti per riferimento di pattern
3. Funzione helper in `scripts/load_graph_partial.py` che fa questo subset.

### "Modelli diversi producono risultati diversi sulla stessa storia"

**Sintomo:** L'utente passa da Claude a GPT a Gemini, ottiene prose stilisticamente diverse.

**Fix:** È atteso, fino a un punto. La voice card minimizza la divergenza ma non la annulla. Se è critica:

1. **Resta su un modello per la fase D.** La prosa di tutte le storie scritta da Claude. Quella di GPT in altre fasi (estrazione voce, audit, debugging).
2. **Pass di voice consistency in Fase E.** Rileggi tutto, identifica drift, normalizza.
3. **Aumenta la specificità della voice card** se i tratti sono troppo generici.

### "Dopo bump manifest, audit fallisce su storie precedenti"

**Sintomo:** Hai aggiunto extension `moon_phase`, eseguito `bump_manifest.py` con retrofill, ma audit_2 segnala drift su S1-S4.

**Cause:**
1. Il retrofill non è stato fatto per tutte le storie (bug nello script)
2. Il valore di retrofill non è quello atteso dallo schema (es. `null` quando lo schema vuole `[]`)
3. Lo schema dello story_node ha una validazione specifica che il null non passa

**Fix:**

1. Esegui audit_2 in modalità verbose per vedere quale storia fallisce
2. Apri il nodo specifico nel grafo, verifica il valore di `moon_phase`
3. Se è assente, fix manuale: aggiungi `"moon_phase": null`
4. Se è null ma lo schema vuole array, aggiorna lo schema o cambia retrofill in `[]`
5. Re-esegui audit

---

## Quando chiedere aiuto

Se nessuno dei fix funziona:

1. **Controlla la versione del template.** Versione corrente dichiarata in `SKILL.md`. Se la tua è vecchia, scarica l'ultima da nodo432.com.
2. **Apri issue su nodo432.** Hub: https://nodo432.com — la sezione issue/feedback è pubblica.
3. **Dump grafo + manifest + ultimo audit_report** per condivisione minima riproducibile.
