# Anti-Patterns — saga-engine

Cose che l'agente NON deve fare. Sono raccolte qui perché derivano da errori reali commessi durante la prima saga (Isola dei Tre Venti) e validate empiricamente.

---

## Anti-pattern strutturali

### 1. Iniziare a scrivere prosa prima del manifest

**Sintomo:** L'utente dice "dai, scriviamo il primo capitolo" e l'agente comincia.

**Perché è sbagliato:** Senza manifest non c'è schema, senza schema non c'è coerenza inter-storia, senza coerenza il libro 50 perde i fili del libro 1. La prosa scritta senza grafo a monte va riscritta dopo.

**Cosa fare invece:** Spiega in 2 righe perché serve il manifest. Procedi alla Fase A4 prima di scrivere prosa.

---

### 2. Inventare campi non dichiarati

**Sintomo:** Mentre costruisci S5, ti viene voglia di tracciare un fenomeno nuovo (es. "fasi lunari"). Aggiungi un campo `moon_phase` direttamente al nodo storia.

**Perché è sbagliato:** Il manifest dichiara quali extension sono ammesse. Aggiungere campi inline produce drift. Quando arrivi a S12 hai 30 storie con 7 campi diversi che nessun audit può validare.

**Cosa fare invece:** Fermati. Proponi all'utente di bumpare il manifest aggiungendo `moon_phase` tra le extension del story_node. Esegui `bump_manifest.py`. Retrofila tutti i nodi precedenti con `moon_phase: null`. Solo allora popola il campo per S5.

---

### 3. Bypassare gli audit

**Sintomo:** Audit_2 fallisce con drift su S5. L'agente dice "lo risolverò poi" e committa lo stesso.

**Perché è sbagliato:** Il drift accumulato è tossico. Una storia disallineata produce 2 storie disallineate, poi 4. La saga finisce con 28 deferred decisions (caso reale Isola).

**Cosa fare invece:** Non commit. Mostra l'errore all'utente. Discutete la causa. Risolvi (modifica nodo, bump manifest, retrofill) o chiedi all'utente esplicitamente "vuoi accettare il drift come deferred?". Se sì, REGISTRA come deferred nel migration_log con nota di quando va risolto. Mai bypass silenzioso.

---

### 4. Confondere ruoli

**Sintomo:** L'agente dice "ho scritto il libro" o "secondo me la paura dovrebbe essere X" o "ti propongo questo bel finale".

**Perché è sbagliato:** L'IA non è autrice. È esecutore competente sopra decisioni d'autore. Se l'IA si comporta come autore, l'utente perde il controllo del proprio lavoro creativo.

**Cosa fare invece:** Usa formulazioni come "propongo X (motivazione: Y)", "il grafo suggerisce Z", "questa scelta è tua". Mai possessivi sul lavoro. Mai "il MIO sistema", "la MIA proposta", "ho scritto IL libro".

---

## Anti-pattern conversazionali

### 5. Sicofanteria

**Sintomo:** "Ottima domanda!", "Perfetto!", "Idea fantastica!", "Hai colto un punto cruciale!"

**Perché è sbagliato:** Nuoce all'utente serio. Erode la fiducia. Suggerisce che l'agente non distingua tra idee buone e cattive.

**Cosa fare invece:** Asciuttezza. "Ok", "procedo", "registrato". Quando l'utente dice qualcosa di buono, vai avanti. Quando dice qualcosa di problematico, dillo direttamente.

---

### 6. Eccesso di domande

**Sintomo:** L'agente fa 30 domande in una chat. L'utente esce esausto.

**Perché è sbagliato:** Il budget di attenzione dell'utente è limitato. Domande inutili lo bruciano per quelle vere.

**Cosa fare invece:** Tre tipologie di interazione (briefing preventivo, validazione di proposta, irriducibile d'autore). Vedi `author_interaction_guidelines.md`. La maggior parte delle decisioni le prende l'agente da solo, registrando nel migration_log.

---

### 7. Recupero contesto via utente

**Sintomo:** "Scusa, in quale storia avevamo deciso che X?"

**Perché è sbagliato:** L'utente non è la memoria del sistema. Il grafo è la memoria del sistema. Chiedere all'utente cose che sono nel grafo è incompetenza.

**Cosa fare invece:** Interroga il grafo. Se non trovi, dichiaralo: "Non trovo X nel grafo, può essere che la decisione vada presa adesso." Solo allora coinvolgi l'utente.

---

### 8. Sostituzione dell'utente

**Sintomo:** L'agente decide cose narrative sostanziali senza chiedere.

**Perché è sbagliato:** L'utente perde il controllo del proprio libro.

**Cosa fare invece:** Per ogni scelta narrativa sostanziale (chi muore, chi si innamora, chi cambia, quale gesto chiude un arco), proponi e chiedi conferma. Mai decidere unilateralmente senza tracciare nel migration_log.

---

## Anti-pattern di scrittura

Questi valgono in Fase D (prose writing) ma vanno tenuti presenti sempre.

### 9. Tic AI ricorrenti

**Sintomo:** Periodi obbligatoriamente di lunghezza uniforme. Metafore concatenate. Aggettivi tripli. Numeri specifici inventati ("ventitré farfalle"). Conflitti interni elevati ad ogni scena. Mai banalità o crudezza.

**Perché è sbagliato:** L'AI generativa ha pattern stilistici identificabili. Se la prosa li mostra tutti, suona "scritta da AI" anche all'orecchio non specialista.

**Cosa fare invece:** Vedi `assets/templates/voice_card_template.md` sezione anti-pattern. Variazione di registro, paragrafi asciutti obbligatori, banalità deliberate, pattern-breaking strutturali.

---

### 10. Inseguire la voce dell'utente con esempi suoi

**Sintomo:** L'utente carica 3 testi, l'agente estrae 5 frasi celebri, e poi le riusa identiche nella prosa nuova.

**Perché è sbagliato:** Plagiarismo da sé stesso. L'utente non vuole leggere le sue stesse frasi nei libri nuovi.

**Cosa fare invece:** La voice card estrae **tratti** (es. "periodi brevi", "verbi riflessivi", "frasi nominali in chiusura"), non frasi. La prosa applica i tratti a contenuti nuovi.

---

### 11. Riassumere quando l'utente vuole il testo

**Sintomo:** L'utente dice "scrivi il capitolo 3", l'agente dice "ecco un riassunto del capitolo 3".

**Perché è sbagliato:** L'utente ha chiesto il capitolo, non il riassunto.

**Cosa fare invece:** Scrivi il capitolo. Se è troppo lungo per una chat, scrivi la prima sezione e segnala che continui. Mai sostituire prosa con riassunto a meno che l'utente lo chieda esplicitamente.

---

### 12. Chiusura troppo netta

**Sintomo:** Ogni capitolo chiude con una frase ad effetto, una "morale", un riassunto del senso.

**Perché è sbagliato:** Toglie spazio al lettore. La voice card di molti autori vieta esplicitamente questo.

**Cosa fare invece:** Rispetta il `resolution_mode` del nodo storia. Se il manifest dichiara `target.reading_layers > 1`, evita morali esplicite. Sigilla con un'immagine, non con una frase didascalica.

---

## Anti-pattern di sistema

### 13. Modificare schema a saga in corso

**Sintomo:** L'agente cambia uno dei campi core dello schema durante la saga (es. rinomina `seeds_planted` in `planted_seeds`).

**Perché è sbagliato:** Tutti i nodi precedenti diventano invalidi. Audit fallisce su 20 storie contemporaneamente.

**Cosa fare invece:** Lo schema è IMMUTABILE durante una saga. Se serve un cambio strutturale, è bump MAJOR del template (es. v1.0 → v2.0) e migrazione esplicita. Non si fa a runtime.

---

### 14. Override dei vincoli senza tracciamento

**Sintomo:** L'utente dice "ok facciamo X anche se viola constraint Y", l'agente esegue senza registrare.

**Perché è sbagliato:** L'audit globale finale segnalerà violazione e nessuno saprà perché.

**Cosa fare invece:** Registra l'override esplicitamente nel migration_log con motivazione dell'utente. L'audit poi conoscerà l'eccezione.

---

### 15. Saltare il bootstrap del filesystem

**Sintomo:** L'agente comincia a costruire S1 senza creare prima la directory della saga.

**Perché è sbagliato:** I file finiscono sparsi, le storie successive non sanno dove cercare.

**Cosa fare invece:** Step 1 sempre: crea la struttura directory dichiarata in SKILL.md. Solo dopo procedi.
