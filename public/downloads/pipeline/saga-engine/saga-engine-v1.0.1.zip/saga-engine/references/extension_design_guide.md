# Extension Design Guide

Come dichiarare extension nel saga_manifest. Le extension sono il vocabolario specifico della saga, dichiarate una volta e poi rispettate da tutti gli audit.

---

## Principio

Lo schema del grafo separa due livelli:

- **Core fields**: universali a qualsiasi saga seriale. Forniti dal template, non modificabili.
- **Extension fields**: specifici della saga. Dichiarati nel manifest, validati dagli audit.

Esempio. Un personaggio ha sempre i core fields:

```
species, type, age_band, role_saga, narrative_function, voice_notes, state_by_story
```

E può avere extension dichiarate:

```
# Per Isola dei Tre Venti:
extensions.character: ["attribute_ear", "fear_arc"]

# Per Memorie del Simbionte (ipotetico):
extensions.character: ["historical_era", "host_relationship", "memory_layer"]

# Per una saga sci-fi:
extensions.character: ["faction_allegiance", "tech_level", "psi_capability"]
```

---

## Quando dichiarare extension

### A4 — fase di inizializzazione manifest

Il momento principale è la Fase A4. Mentre compili il manifest, dichiari **tutte** le extension che la saga prevedibilmente userà.

Domande da porre all'utente:

1. **Per i character**: quali attributi aggiuntivi voglio tracciare per ogni personaggio? (es. tratti di personalità, archetipo, arco drammatico, framework ontologico)
2. **Per le location**: quali metadati aggiuntivi servono? (es. quadrante geografico simbolico, periodo storico, livello di pericolo)
3. **Per gli object**: quali tipi di metadati sugli oggetti? (es. vincolo di descrizione, storia di origine, status simbolico)
4. **Per gli story node**: quali attributi narrativi attraverseranno tutta la saga? (es. fase stagionale, attributo dominante, meta-pattern, palette emotiva specifica)
5. **Quali collezioni di entità extra** servono oltre characters/locations/objects? (es. per Isola: winds, visual_signatures)

### B — durante la saga (rare, ma legittime)

Capita di scoprire a metà saga che serve una nuova extension. È legittimo. Si fa così:

1. Edita il manifest aggiungendo l'extension nel namespace giusto
2. Bump `manifest_version` (es. 1.0 → 1.1)
3. Esegui `scripts/bump_manifest.py` che retrofila il grafo (aggiunge il campo a tutti gli story node esistenti con valore null/empty)
4. Registra il bump nel migration_log

**Perché il retrofill obbligatorio:** lo schema dice "tutti i nodi devono avere la stessa forma". Se un campo c'è in 5 nodi e non in altri 20, l'audit non sa se è dimenticanza o intenzione. Il retrofill a null elimina l'ambiguità.

### Quello che NON si fa mai

- Aggiungere campi a runtime senza dichiararli nel manifest
- Rimuovere extension dichiarate (se serve, è bump MAJOR del template, una migrazione completa)
- Modificare il significato di una extension dichiarata (es. cambiare il tipo da string ad array)

---

## Best practices nella nomenclatura

- **Snake_case sempre.** `attribute_ear`, non `attributeEar` o `attribute-ear`.
- **Nomi descrittivi.** `fear_arc` è meglio di `fa`. `historical_era_of_host` è meglio di `era`.
- **Prefisso del namespace logico.** Se hai più extension correlate, usa prefisso comune. Es: `wind_active`, `wind_transition`, `wind_notes` (tutti afferenti ai venti di Isola).
- **Mai conflitti con core.** Se un nome è già un core field, scegli un altro. Lo schema rifiuta override.

---

## Pattern comuni

### Pattern 1: Arco drammatico per personaggio

Saghe character-driven con archi drammatici espliciti.

```yaml
extensions:
  character: ["dramatic_arc"]
```

Dove `dramatic_arc` è oggetto con sotto-campi:
- `arc_id`
- `first_emergence_planned`
- `resolution_story`
- `resolution_mode`
- `bloomed_in_story`

Esempi: arco di trasformazione, arco di redenzione, arco di paura (Isola), arco di desiderio.

### Pattern 2: Attributo dominante per storia

Saghe con struttura tematica (ogni capitolo "appartiene" a un attributo).

```yaml
extensions:
  story_node: ["attribute_dominant"]
```

Valori ammessi sono saga-specifici: per Isola "delta/intreccio/mulinello", per altra saga "passione/dovere/conflitto", ecc.

### Pattern 3: Fenomeno ambientale ricorrente

Saghe con un fenomeno che attraversa tutto (vento, marea, fasi lunari, eventi cosmici).

```yaml
extensions:
  story_node: ["weather_active", "weather_transition", "weather_notes"]
```

### Pattern 4: Meta-pattern silente

Saghe con un meta-pattern presente in immagini ma mai nominato esplicitamente.

```yaml
extensions:
  story_node: ["meta_pattern_active", "meta_pattern_notes"]

active_constraints_global:
  - "meta_pattern_never_named_in_text"
```

L'agente sa di doverlo presidiare nelle immagini ma mai citarlo nel testo della prosa.

### Pattern 5: Firma visiva

Saghe con firme visive ricorrenti (immagini-segnale).

```yaml
extensions:
  entities_collections: ["visual_signatures"]
  story_node: ["visual_signature_X_active"]
```

Dove `visual_signatures` è una collezione di entità (come characters) con i suoi item.

### Pattern 6: Quadrante simbolico

Saghe con geografia simbolica (mandala, scacchiera, mappa concettuale).

```yaml
extensions:
  location: ["quadrant"]
```

Valori sono enum dichiarati: per Isola "fuoco_est/acqua_ovest/aria_nord/terra_sud", per altra saga "nord/sud/centro" o "core/periphery/exile".

---

## Quando NON aggiungere extension

L'extension ha un costo: ogni storia futura deve compilarla, ogni audit la deve validare, ogni retrofill la tocca. Aggiungi extension solo se:

1. **Verrà usata in più di 3 storie.** Se è una decoration una-tantum, fa parte del campo `note` o `structural_notes`, non merita extension.
2. **Ha valore semantico stabile.** Se cambia significato a metà saga, è meglio rifletterci di più prima di dichiararla.
3. **Sarà cercata in audit o query future.** Se è solo "memoria" inerte, non serve.

In dubbio, NON dichiarare. Si può sempre bumpare il manifest dopo. Il contrario costa di più.

---

## Esempi di extension che NON dovrebbero esistere

- `note_speciale_per_questa_storia` — è un campo libero, mettilo in `structural_notes` come tag.
- `humour_level` — soggettivo e inutile per audit.
- `numero_di_dialoghi` — calcolabile a runtime dalla prosa, non serve tracciarlo.
- `popolarità_attesa` — non è una proprietà della storia, è una previsione.

---

## Esempio: dichiarazione extension Isola dei Tre Venti

```yaml
extensions:
  character:
    - attribute_ear        # delta/intreccio/mulinello (framework EAR)
    - fear_arc            # arco drammatico paura

  location:
    - quadrant            # quadrante mandala (fuoco_est, acqua_ovest, aria_nord, terra_sud)

  object:
    - bloom_story         # storia in cui l'oggetto bloomed
    - description_constraint # vincolo di descrizione (es. "mai_descritto_dopo_s09")

  story_node:
    - cycle               # blocco A/B/C/D
    - attribute_dominant  # delta/intreccio/mulinello
    - wind_active         # vento attivo nella storia
    - wind_transition     # transizione di vento
    - wind_notes          # note sul vento
    - pattern_a_active    # status pattern A (none/pre_eco/seminato/attivo/bloomed)
    - pattern_a_notes     # note pattern A
    - when_water_trembles # firma visiva attiva
    - fear_touched        # paura toccata in questa storia

  entities_collections:
    - winds               # i tre venti come entità persistenti
    - visual_signatures   # firme visive ricorrenti
```

Questa è la dichiarazione completa per Isola. 9 extension story_node, 2 character, 1 location, 2 object, 2 entities_collections. Disciplinato e sufficiente per 12 storie.
