#!/usr/bin/env python3
"""
audit_0_canonical_fields.py — saga-engine v1.0

GATE OBBLIGATORIO pre-commit.

Verifica che ogni story_node abbia tutti i campi core obbligatori
e tutti i campi extension dichiarati nel manifest.

Uso:
    python audit_0_canonical_fields.py --graph path/to/graph.json

Output:
    PASS / FAIL per ogni story node.
    Exit code 0 se tutti PASS, 1 altrimenti.
"""

import argparse
import json
import sys


# Core fields obbligatori per story_node (replicato dallo schema v1.0)
STORY_NODE_REQUIRED_CORE = [
    'id',
    'title_provvisorio',
    'premise',
    'problem',
    'threshold_moment',
    'resolution_mode',
    'palette_emotiva',
    'location_primary',
    'characters_in_scene',
    'seeds_planted',
    'callback_summary',
    'active_constraints_touched',
]

# Tutti i core fields ammessi (presente o null/empty se nullable)
STORY_NODE_ALL_CORE = STORY_NODE_REQUIRED_CORE + [
    'block_position',
    'season',
    'season_passage',
    'locations_secondary',
    'night_scene',
    'night_scene_notes',
    'characters_offscreen_or_background',
    'seeds_picked_up',
    'seeds_maturing_here',
    'seeds_bloomed_here',
    'callbacks_made',
    'debts_opened',
    'debts_closed',
    'voice_notes_essential',
    'visual_anchors',
    'key_phrase_indicative',
    'key_phrase_notes',
    'key_phrase_attributed_to',
    'structural_notes',
]


def audit_story(story_id, story, declared_extensions):
    """
    Audit di un singolo story_node.
    Returns: list di errori (vuota se pass).
    """
    errors = []

    # 1. Campi core obbligatori presenti e non vuoti/null
    for field in STORY_NODE_REQUIRED_CORE:
        if field not in story:
            errors.append(f"missing required core field: {field}")
            continue
        val = story[field]
        if val is None:
            errors.append(f"required core field is null: {field}")
        elif isinstance(val, str) and not val.strip():
            errors.append(f"required core field is empty string: {field}")
        elif isinstance(val, list) and field == 'characters_in_scene' and len(val) == 0:
            errors.append(f"characters_in_scene cannot be empty")

    # 2. Campi extension dichiarati: presenti (anche se null)
    for ext_field in declared_extensions:
        if ext_field not in story:
            errors.append(f"declared extension field missing: {ext_field}")

    # 3. Nessun campo non dichiarato
    allowed = set(STORY_NODE_ALL_CORE) | set(declared_extensions)
    for field in story.keys():
        if field not in allowed:
            errors.append(f"undeclared field present: {field} (must be in extensions_declared.story_node)")

    return errors


def main():
    parser = argparse.ArgumentParser(description='Audit canonical fields for story nodes')
    parser.add_argument('--graph', required=True, help='Path to story graph JSON')
    parser.add_argument('--story', help='Audit only specific story_id (e.g. s05)')
    args = parser.parse_args()

    with open(args.graph, encoding='utf-8') as f:
        graph = json.load(f)

    declared_extensions = graph.get('extensions_declared', {}).get('story_node', [])
    stories = graph.get('stories', {})

    if args.story:
        if args.story not in stories:
            print(f"ERROR: story {args.story} not found in graph", file=sys.stderr)
            sys.exit(1)
        stories_to_check = {args.story: stories[args.story]}
    else:
        stories_to_check = stories

    if not stories_to_check:
        print("WARNING: no stories to audit (graph empty)")
        sys.exit(0)

    print(f"Auditing {len(stories_to_check)} story node(s)...")
    print(f"Declared story_node extensions: {declared_extensions}")
    print()

    failed = []
    for story_id in sorted(stories_to_check.keys()):
        story = stories_to_check[story_id]
        errors = audit_story(story_id, story, declared_extensions)
        if errors:
            failed.append((story_id, errors))
            print(f"  ✗ {story_id} FAIL")
            for err in errors:
                print(f"      {err}")
        else:
            print(f"  ✓ {story_id} PASS")

    print()
    if failed:
        print(f"AUDIT FAILED: {len(failed)} story node(s) with errors")
        sys.exit(1)
    else:
        print(f"AUDIT PASS: all {len(stories_to_check)} story node(s) conforming")
        sys.exit(0)


if __name__ == '__main__':
    main()
