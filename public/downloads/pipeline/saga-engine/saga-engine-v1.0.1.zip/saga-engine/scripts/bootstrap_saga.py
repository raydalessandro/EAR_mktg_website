#!/usr/bin/env python3
"""
bootstrap_saga.py — saga-engine v1.0

Inizializza una saga nuova: legge il saga_manifest.yaml compilato,
e produce il grafo iniziale popolato.

Uso:
    python bootstrap_saga.py \
        --manifest path/to/saga_manifest.yaml \
        --template path/to/saga_graph_template_v1_0.json \
        --output path/to/story_graph_v0_1_0.json

Comportamento:
    1. Carica manifest YAML
    2. Carica template JSON
    3. Copia i valori del manifest in saga_manifest_snapshot del grafo
    4. Popola extensions_declared con i namespace dichiarati nel manifest
    5. Popola active_constraints_global dal manifest
    6. Inizializza quote_tracker leggendo quote_trackers_declared
    7. Aggiunge migration_log entry di bootstrap
    8. Rimuove _template_info dal grafo
    9. Scrive il grafo nuovo
"""

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML required. Install with: pip install pyyaml", file=sys.stderr)
    sys.exit(1)


def load_manifest(path):
    with open(path, encoding='utf-8') as f:
        return yaml.safe_load(f)


def load_template(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def validate_manifest(manifest):
    """Validazione minima del manifest prima del bootstrap."""
    required = ['saga_id', 'title', 'author', 'language', 'manifest_version']
    missing = [k for k in required if not manifest.get(k)]
    if missing:
        raise ValueError(f"Manifest missing required fields: {missing}")

    if not manifest.get('structure', {}).get('total_stories'):
        raise ValueError("Manifest missing structure.total_stories")

    saga_id = manifest['saga_id']
    if not all(c.isalnum() or c == '_' for c in saga_id) or not saga_id.islower():
        raise ValueError(f"saga_id must be lowercase snake_case, got: {saga_id}")


def clean_meta_fields(obj):
    """Rimuove ricorsivamente _comment, _schema, _template_info, _note dal grafo."""
    if isinstance(obj, dict):
        keys_to_remove = [k for k in obj.keys() if k.startswith('_')]
        for k in keys_to_remove:
            del obj[k]
        for v in obj.values():
            clean_meta_fields(v)
    elif isinstance(obj, list):
        for item in obj:
            clean_meta_fields(item)


def bootstrap(manifest, template):
    """Produce il grafo iniziale popolato dal manifest."""
    graph = json.loads(json.dumps(template))  # deep copy

    # Rimuovi tutti i metadata _* dal template (commenti, schema info, ecc)
    clean_meta_fields(graph)

    # Timestamp
    now = datetime.now(timezone.utc).isoformat()
    today = now.split('T')[0]

    graph['last_updated'] = today

    # Saga manifest snapshot
    graph['saga_manifest_snapshot'] = {
        'saga_id': manifest['saga_id'],
        'title': manifest['title'],
        'author': manifest['author'],
        'language': manifest['language'],
        'manifest_version': manifest['manifest_version'],
        'ontological_framework_name': manifest.get('ontological_framework', {}).get('name'),
        'ontological_framework_visibility': manifest.get('ontological_framework', {}).get('visibility', 'hidden'),
    }

    # Extensions declared
    extensions = manifest.get('extensions', {})
    graph['extensions_declared'] = {
        'character': extensions.get('character', []) or [],
        'location': extensions.get('location', []) or [],
        'object': extensions.get('object', []) or [],
        'story_node': extensions.get('story_node', []) or [],
        'entities_collections': extensions.get('entities_collections', []) or [],
    }

    # Pulisci entities.* dei _schema (sono solo nel template)
    for key in ['characters', 'locations', 'objects']:
        if key in graph.get('entities', {}):
            graph['entities'][key] = {}

    # Inizializza collezioni entities extension
    for ext_collection in graph['extensions_declared']['entities_collections']:
        graph['entities'][ext_collection] = {}

    # Pulisci seeds, callbacks, stories dai _schema
    graph['seeds'] = {}
    graph['callbacks'] = {}
    graph['stories'] = {}

    # Active constraints global
    graph['active_constraints_global'] = manifest.get('active_constraints_global', []) or []

    # Quote tracker init
    quote_trackers_declared = manifest.get('quote_trackers_declared', []) or []
    graph['quote_tracker'] = {}
    for qt in quote_trackers_declared:
        tracker_id = qt['tracker_id']
        graph['quote_tracker'][tracker_id] = {
            'description': qt.get('description', ''),
            'max_per_saga': qt.get('max_per_saga'),
            'max_per_story': qt.get('max_per_story'),
            'count_actual': 0,
            'occurrences': [],
        }

    # Migration log: prima entry
    graph['migration_log'] = [{
        'phase': 'A4_manifest_initialization',
        'scope': 'graph_bootstrap_from_template',
        'changes': [
            f"Grafo inizializzato da template v{template.get('schema_version', '1.0')}",
            f"Manifest snapshot: saga_id={manifest['saga_id']}, manifest_version={manifest['manifest_version']}",
            f"Extensions dichiarate: {sum(len(v) for v in graph['extensions_declared'].values())} totali",
            f"Quote trackers inizializzati: {len(quote_trackers_declared)}",
            f"Active constraints globali: {len(graph['active_constraints_global'])}",
        ],
        'version_before': None,
        'version_after': '0.1.0',
        'deferred_decisions': [],
        'timestamp': now,
    }]

    return graph


def main():
    parser = argparse.ArgumentParser(description='Bootstrap saga graph from manifest')
    parser.add_argument('--manifest', required=True, help='Path to saga_manifest.yaml')
    parser.add_argument('--template', required=True, help='Path to saga_graph_template_v1_0.json')
    parser.add_argument('--output', required=True, help='Path to output graph JSON')
    args = parser.parse_args()

    print(f"Loading manifest: {args.manifest}")
    manifest = load_manifest(args.manifest)

    print(f"Loading template: {args.template}")
    template = load_template(args.template)

    print("Validating manifest...")
    validate_manifest(manifest)
    print(f"  ✓ Saga: {manifest['saga_id']} - {manifest['title']}")
    print(f"  ✓ Author: {manifest['author']}")
    print(f"  ✓ Language: {manifest['language']}")
    print(f"  ✓ Total stories: {manifest['structure']['total_stories']}")

    print("Bootstrapping graph...")
    graph = bootstrap(manifest, template)

    print(f"Writing graph: {args.output}")
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(graph, f, indent=2, ensure_ascii=False)

    print()
    print("✓ Bootstrap complete.")
    print(f"  Graph version: 0.1.0")
    print(f"  Extensions declared: {sum(len(v) for v in graph['extensions_declared'].values())}")
    print(f"  Active constraints: {len(graph['active_constraints_global'])}")
    print(f"  Quote trackers: {len(graph['quote_tracker'])}")


if __name__ == '__main__':
    main()
