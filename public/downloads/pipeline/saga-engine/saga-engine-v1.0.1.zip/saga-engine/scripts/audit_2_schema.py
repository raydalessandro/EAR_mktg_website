#!/usr/bin/env python3
"""
audit_2_schema.py — saga-engine v1.0

GATE OBBLIGATORIO pre-commit.

Valida il grafo contro saga_graph_schema_v1_0.json (JSON Schema draft-07).
Verifica anche le regole semantiche extra che JSON Schema non può esprimere
(extension dichiarate, ecc).

Uso:
    python audit_2_schema.py --graph path/to/graph.json --schema path/to/schema.json
"""

import argparse
import json
import sys

try:
    import jsonschema
except ImportError:
    print("ERROR: jsonschema required. Install with: pip install jsonschema", file=sys.stderr)
    sys.exit(1)


# Core fields universali (replicato per controllo)
CHARACTER_CORE = {'species', 'type', 'age_band', 'birth', 'role_saga',
                  'narrative_function', 'voice_notes', 'state_by_story',
                  'alias', 'physical_description'}

LOCATION_CORE = {'type', 'role_saga', 'features', 'inhabitant',
                 'first_appearance_story', 'geographical_notes'}

OBJECT_CORE = {'category', 'type', 'owner', 'introduced_in_story',
               'description_constraint', 'appears_in_stories_planned',
               'bloom_story', 'materiale', 'note'}

STORY_CORE = {
    'id', 'title_provvisorio', 'block_position', 'season', 'season_passage',
    'premise', 'problem', 'threshold_moment', 'resolution_mode',
    'palette_emotiva', 'location_primary', 'locations_secondary',
    'night_scene', 'night_scene_notes', 'characters_in_scene',
    'characters_offscreen_or_background', 'seeds_planted', 'seeds_picked_up',
    'seeds_maturing_here', 'seeds_bloomed_here', 'callbacks_made',
    'debts_opened', 'debts_closed', 'voice_notes_essential',
    'visual_anchors', 'key_phrase_indicative', 'key_phrase_notes',
    'key_phrase_attributed_to', 'structural_notes', 'callback_summary',
    'active_constraints_touched',
}


def validate_extensions(graph):
    """Verifica che ogni entity/story usi solo extension dichiarate."""
    errors = []
    declared = graph.get('extensions_declared', {})

    # Characters
    for cid, ch in graph.get('entities', {}).get('characters', {}).items():
        if not isinstance(ch, dict):
            continue
        if cid.startswith('_'):  # skip _schema, _comment
            continue
        for field in ch.keys():
            if field.startswith('_'):
                continue
            if field not in CHARACTER_CORE and field not in declared.get('character', []):
                errors.append(f"character '{cid}': undeclared extension field '{field}'")

    # Locations
    for lid, loc in graph.get('entities', {}).get('locations', {}).items():
        if not isinstance(loc, dict):
            continue
        if lid.startswith('_'):
            continue
        for field in loc.keys():
            if field.startswith('_'):
                continue
            if field not in LOCATION_CORE and field not in declared.get('location', []):
                errors.append(f"location '{lid}': undeclared extension field '{field}'")

    # Objects
    for oid, obj in graph.get('entities', {}).get('objects', {}).items():
        if not isinstance(obj, dict):
            continue
        if oid.startswith('_'):
            continue
        for field in obj.keys():
            if field.startswith('_'):
                continue
            if field not in OBJECT_CORE and field not in declared.get('object', []):
                errors.append(f"object '{oid}': undeclared extension field '{field}'")

    # Stories
    for sid, story in graph.get('stories', {}).items():
        if not isinstance(story, dict):
            continue
        if sid.startswith('_'):
            continue
        for field in story.keys():
            if field.startswith('_'):
                continue
            if field not in STORY_CORE and field not in declared.get('story_node', []):
                errors.append(f"story '{sid}': undeclared extension field '{field}'")

    # Entities collections
    standard = {'characters', 'locations', 'objects'}
    declared_collections = set(declared.get('entities_collections', []))
    for coll in graph.get('entities', {}).keys():
        if coll.startswith('_'):
            continue
        if coll not in standard and coll not in declared_collections:
            errors.append(f"entities collection '{coll}' not declared in extensions_declared.entities_collections")

    return errors


def main():
    parser = argparse.ArgumentParser(description='Audit schema validity')
    parser.add_argument('--graph', required=True)
    parser.add_argument('--schema', required=True)
    args = parser.parse_args()

    with open(args.graph, encoding='utf-8') as f:
        graph = json.load(f)
    with open(args.schema, encoding='utf-8') as f:
        schema = json.load(f)

    print("Step 1: JSON Schema validation...")
    validator = jsonschema.Draft7Validator(schema)
    schema_errors = sorted(validator.iter_errors(graph), key=lambda e: e.path)

    if schema_errors:
        print(f"  ✗ FAIL ({len(schema_errors)} schema errors)")
        for err in schema_errors[:20]:
            path = '.'.join(str(p) for p in err.path) or '(root)'
            print(f"      [{path}] {err.message}")
        if len(schema_errors) > 20:
            print(f"      ... and {len(schema_errors) - 20} more")
    else:
        print("  ✓ PASS (JSON Schema valid)")

    print()
    print("Step 2: Extension declaration validation...")
    ext_errors = validate_extensions(graph)
    if ext_errors:
        print(f"  ✗ FAIL ({len(ext_errors)} extension errors)")
        for err in ext_errors:
            print(f"      {err}")
    else:
        print("  ✓ PASS (all extensions declared)")

    print()
    if schema_errors or ext_errors:
        print("AUDIT FAILED")
        sys.exit(1)
    else:
        print("AUDIT PASS")
        sys.exit(0)


if __name__ == '__main__':
    main()
