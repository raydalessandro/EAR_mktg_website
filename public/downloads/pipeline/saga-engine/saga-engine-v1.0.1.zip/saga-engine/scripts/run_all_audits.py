#!/usr/bin/env python3
"""
run_all_audits.py — saga-engine v1.0

Esegue audit suite completa in ordine corretto.
- audit_0 (canonical fields)
- audit_1 (integrity)
- audit_2 (schema)
- audit_3 (navigability)
- audit_4 (drift, diagnostico)

Uso:
    python run_all_audits.py --graph path/to/graph.json --schema path/to/schema.json
    python run_all_audits.py --graph X --schema Y --final     # controlli aggiuntivi chiusura saga
"""

import argparse
import subprocess
import sys
from pathlib import Path


def run_audit(script_name, args):
    script_path = Path(__file__).parent / script_name
    cmd = ['python3', str(script_path)] + args
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode, result.stdout, result.stderr


def main():
    parser = argparse.ArgumentParser(description='Run all audits in order')
    parser.add_argument('--graph', required=True)
    parser.add_argument('--schema', required=True)
    parser.add_argument('--final', action='store_true', help='Final saga audit (extra checks)')
    args = parser.parse_args()

    print("=" * 70)
    print("SAGA-ENGINE AUDIT SUITE")
    print("=" * 70)

    failed_gates = []

    audits = [
        ('audit_0_canonical_fields.py', ['--graph', args.graph], True),
        ('audit_1_integrity.py', ['--graph', args.graph], True),
        ('audit_2_schema.py', ['--graph', args.graph, '--schema', args.schema], True),
        ('audit_3_navigability.py', ['--graph', args.graph], True),
        ('audit_4_drift.py', ['--graph', args.graph], False),
    ]

    for script, audit_args, is_gate in audits:
        print()
        print("-" * 70)
        print(f"RUNNING: {script}")
        print("-" * 70)
        code, stdout, stderr = run_audit(script, audit_args)
        print(stdout)
        if stderr:
            print("STDERR:", stderr, file=sys.stderr)
        if code != 0 and is_gate:
            failed_gates.append(script)

    print()
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    if failed_gates:
        print(f"✗ {len(failed_gates)} GATE(S) FAILED:")
        for g in failed_gates:
            print(f"    {g}")
        print()
        print("DO NOT COMMIT. Resolve errors first.")
        sys.exit(1)
    else:
        print("✓ ALL GATES PASSED")
        if args.final:
            print()
            print("Final saga audit complete. Saga ready for Fase D (prose writing).")
        sys.exit(0)


if __name__ == '__main__':
    main()
