#!/usr/bin/env python3
"""
audit_3_navigability.py — saga-engine v1.0

GATE OBBLIGATORIO pre-commit.

Verifica navigabilità e consistenza interna:
- Seeds bloomed devono apparire in seeds_bloomed_here di qualche storia
- Seeds maturing devono apparire in seeds_maturing_here
- Quote tracker deve essere coerente con stato dichiarato nelle storie
- Debt tracking deve quadrare (saldo coerente)

Uso:
    python audit_3_navigability.py --graph path/to/graph.json
"""

import argparse
import json
import sys


def audit_seed_lifecycle(graph):
    """Verifica che lo status dei seed sia coerente con le storie."""
    errors = []
    seeds = graph.get('seeds', {})
    stories = graph.get('stories', {})

    # Per ogni seed, verifica coerenza
    for seed_id, seed in seeds.items():
        status = seed.get('status')

        # bloomed: deve apparire in seeds_bloomed_here di qualche storia
        if status == 'bloomed':
            bloomed_in = seed.get('bloomed_in_story')
            if not bloomed_in:
                errors.append(f"seed '{seed_id}' status=bloomed ma bloomed_in_story mancante")
                continue
            if bloomed_in not in stories:
                errors.append(f"seed '{seed_id}' bloomed_in_story='{bloomed_in}' ma storia non esiste")
                continue
            story = stories[bloomed_in]
            bloomed_here = [extract_id(s) for s in story.get('seeds_bloomed_here', []) or []]
            if seed_id not in bloomed_here:
                errors.append(f"seed '{seed_id}' bloomed in {bloomed_in} ma non listato in seeds_bloomed_here")

        # maturing: deve apparire in maturing_in_stories
        if status == 'maturing':
            maturing_stories = seed.get('maturing_in_stories', []) or []
            if not maturing_stories:
                errors.append(f"seed '{seed_id}' status=maturing ma maturing_in_stories vuoto")

    return errors


def audit_quote_tracker(graph):
    """Verifica coerenza quote tracker (qt declared == count counted)."""
    errors = []
    qt = graph.get('quote_tracker', {})

    for tracker_id, tracker in qt.items():
        if not isinstance(tracker, dict):
            continue
        max_per_saga = tracker.get('max_per_saga')
        count_actual = tracker.get('count_actual', 0)

        if max_per_saga is not None and count_actual > max_per_saga:
            errors.append(f"quote_tracker '{tracker_id}': count_actual={count_actual} excede max_per_saga={max_per_saga}")

    return errors


def audit_debt_balance(graph):
    """Verifica saldo debt: aperti - chiusi = aperti residui."""
    errors = []
    stories = graph.get('stories', {})

    total_opened = 0
    total_closed = 0
    for story_id in sorted(stories.keys()):
        story = stories[story_id]
        opened = len(story.get('debts_opened', []) or [])
        closed = len(story.get('debts_closed', []) or [])
        total_opened += opened
        total_closed += closed

    saldo = total_opened - total_closed
    print(f"  Debt balance: opened={total_opened}, closed={total_closed}, saldo={saldo}")

    # Se siamo a chiusura saga (ultima storia presente è quella attesa), saldo dovrebbe essere 0
    # Per ora solo info diagnostica, non bloccante
    return errors


def extract_id(item):
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        return item.get('id') or item.get('seed_id')
    return None


def main():
    parser = argparse.ArgumentParser(description='Audit navigability')
    parser.add_argument('--graph', required=True)
    args = parser.parse_args()

    with open(args.graph, encoding='utf-8') as f:
        graph = json.load(f)

    all_errors = []

    print("Step 1: Seed lifecycle...")
    errors = audit_seed_lifecycle(graph)
    if errors:
        print(f"  ✗ FAIL ({len(errors)})")
        for e in errors:
            print(f"      {e}")
        all_errors.extend(errors)
    else:
        print("  ✓ PASS")

    print("Step 2: Quote tracker consistency...")
    errors = audit_quote_tracker(graph)
    if errors:
        print(f"  ✗ FAIL ({len(errors)})")
        for e in errors:
            print(f"      {e}")
        all_errors.extend(errors)
    else:
        print("  ✓ PASS")

    print("Step 3: Debt balance...")
    errors = audit_debt_balance(graph)
    if errors:
        print(f"  ✗ FAIL ({len(errors)})")
        for e in errors:
            print(f"      {e}")
        all_errors.extend(errors)
    else:
        print("  ✓ PASS (info diagnostico, non bloccante)")

    print()
    if all_errors:
        print(f"AUDIT FAILED ({len(all_errors)} errors)")
        sys.exit(1)
    else:
        print("AUDIT PASS")
        sys.exit(0)


if __name__ == '__main__':
    main()
