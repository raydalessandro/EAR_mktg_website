#!/usr/bin/env python3
"""
audit_1_integrity.py — saga-engine v1.0

GATE OBBLIGATORIO pre-commit.

Verifica integrità referenziale: tutti gli ID citati (seeds, locations,
characters, callbacks, objects) devono esistere come entità.

Uso:
    python audit_1_integrity.py --graph path/to/graph.json

Output: report con PASS/FAIL per ogni controllo.
Exit code 0 se PASS, 1 se FAIL.
"""

import argparse
import json
import sys


def collect_existing_ids(graph):
    """Raccoglie tutti gli ID esistenti nel grafo."""
    ids = {
        'characters': set(graph.get('entities', {}).get('characters', {}).keys()),
        'locations': set(graph.get('entities', {}).get('locations', {}).keys()),
        'objects': set(graph.get('entities', {}).get('objects', {}).keys()),
        'seeds': set(graph.get('seeds', {}).keys()),
        'callbacks': set(graph.get('callbacks', {}).keys()),
        'stories': set(graph.get('stories', {}).keys()),
    }
    # Anche collezioni extension
    extensions_collections = graph.get('extensions_declared', {}).get('entities_collections', [])
    for coll in extensions_collections:
        ids[coll] = set(graph.get('entities', {}).get(coll, {}).keys())
    return ids


def extract_id(item):
    """Estrae l'ID da un item che può essere stringa o dict con campo id."""
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        return item.get('id') or item.get('seed_id') or item.get('callback_id')
    return None


def audit_story_references(story_id, story, existing_ids):
    """Verifica che tutti gli ID referenziati nella storia esistano."""
    errors = []

    # location_primary
    loc_primary = story.get('location_primary')
    if isinstance(loc_primary, dict):
        loc_id = loc_primary.get('id')
        if loc_id and loc_id not in existing_ids['locations']:
            errors.append(f"location_primary.id '{loc_id}' not in entities.locations")

    # locations_secondary
    for loc in story.get('locations_secondary', []) or []:
        loc_id = extract_id(loc)
        if loc_id and loc_id not in existing_ids['locations']:
            errors.append(f"locations_secondary id '{loc_id}' not in entities.locations")

    # characters_in_scene + offscreen
    for ch in (story.get('characters_in_scene', []) or []) + (story.get('characters_offscreen_or_background', []) or []):
        ch_id = extract_id(ch)
        if ch_id and ch_id not in existing_ids['characters']:
            errors.append(f"character id '{ch_id}' not in entities.characters")

    # seeds (planted, picked_up, maturing_here, bloomed_here)
    for seed_field in ['seeds_planted', 'seeds_picked_up', 'seeds_maturing_here', 'seeds_bloomed_here']:
        for s in story.get(seed_field, []) or []:
            seed_id = extract_id(s)
            if seed_id and seed_id not in existing_ids['seeds']:
                errors.append(f"{seed_field}: seed '{seed_id}' not in seeds registry")

    # callbacks_made
    for cb in story.get('callbacks_made', []) or []:
        cb_id = extract_id(cb)
        if cb_id and cb_id not in existing_ids['callbacks']:
            errors.append(f"callbacks_made: callback '{cb_id}' not in callbacks registry")

    return errors


def audit_seed_references(seed_id, seed, existing_ids):
    """Verifica che gli ID nei seed esistano."""
    errors = []

    # origin_story deve essere uno story_id
    origin = seed.get('origin_story')
    if origin and origin not in existing_ids['stories']:
        errors.append(f"seed '{seed_id}': origin_story '{origin}' not in stories")

    # bloom_target_stories
    for target in seed.get('bloom_target_stories', []) or []:
        if target not in existing_ids['stories']:
            errors.append(f"seed '{seed_id}': bloom_target '{target}' not in stories")

    # bloomed_in_story (se presente)
    bloomed_in = seed.get('bloomed_in_story')
    if bloomed_in and bloomed_in not in existing_ids['stories']:
        errors.append(f"seed '{seed_id}': bloomed_in_story '{bloomed_in}' not in stories")

    return errors


def audit_callback_references(cb_id, callback, existing_ids):
    """Verifica che gli ID nei callback esistano."""
    errors = []

    from_story = callback.get('from_story')
    if from_story and from_story not in existing_ids['stories']:
        errors.append(f"callback '{cb_id}': from_story '{from_story}' not in stories")

    registered_in = callback.get('registered_in_story')
    if registered_in and registered_in not in existing_ids['stories']:
        errors.append(f"callback '{cb_id}': registered_in_story '{registered_in}' not in stories")

    return errors


def main():
    parser = argparse.ArgumentParser(description='Audit referential integrity')
    parser.add_argument('--graph', required=True, help='Path to story graph JSON')
    args = parser.parse_args()

    with open(args.graph, encoding='utf-8') as f:
        graph = json.load(f)

    existing_ids = collect_existing_ids(graph)
    print(f"Existing IDs:")
    for k, v in existing_ids.items():
        print(f"  {k}: {len(v)}")
    print()

    all_errors = []

    # Audit stories
    print("Auditing story references...")
    for story_id in sorted(graph.get('stories', {}).keys()):
        story = graph['stories'][story_id]
        errors = audit_story_references(story_id, story, existing_ids)
        if errors:
            all_errors.append((f'story:{story_id}', errors))

    # Audit seeds
    print("Auditing seed references...")
    for seed_id in sorted(graph.get('seeds', {}).keys()):
        seed = graph['seeds'][seed_id]
        errors = audit_seed_references(seed_id, seed, existing_ids)
        if errors:
            all_errors.append((f'seed:{seed_id}', errors))

    # Audit callbacks
    print("Auditing callback references...")
    for cb_id in sorted(graph.get('callbacks', {}).keys()):
        cb = graph['callbacks'][cb_id]
        errors = audit_callback_references(cb_id, cb, existing_ids)
        if errors:
            all_errors.append((f'callback:{cb_id}', errors))

    print()
    if all_errors:
        print(f"AUDIT FAILED: {len(all_errors)} entities with broken references")
        for entity, errors in all_errors:
            print(f"  ✗ {entity}")
            for err in errors:
                print(f"      {err}")
        sys.exit(1)
    else:
        print(f"AUDIT PASS: all references intact")
        sys.exit(0)


if __name__ == '__main__':
    main()
