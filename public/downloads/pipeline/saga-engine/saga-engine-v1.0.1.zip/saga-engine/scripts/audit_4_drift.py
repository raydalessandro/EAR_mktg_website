#!/usr/bin/env python3
"""
audit_4_drift.py — saga-engine v1.0

DIAGNOSTICO (non bloccante).

Confronta i nodi storia tra loro per identificare drift di forma:
campi presenti in alcune storie ma non in altre, tipi inconsistenti
per lo stesso campo, ecc.

Uso:
    python audit_4_drift.py --graph path/to/graph.json
"""

import argparse
import json
import sys
from collections import Counter


def audit_field_presence_drift(graph):
    """Identifica campi che sono presenti solo in alcune storie."""
    drift = []
    stories = graph.get('stories', {})
    if not stories:
        return drift

    # Conta presenza di ogni campo
    field_count = Counter()
    total = len(stories)
    for sid, story in stories.items():
        if sid.startswith('_'):
            continue
        for field in story.keys():
            if field.startswith('_'):
                continue
            field_count[field] += 1

    # Drift = campo presente in N < total e N > 0
    for field, count in field_count.items():
        if 0 < count < total:
            drift.append({
                'field': field,
                'present_in': count,
                'total': total,
                'percentage': round(count / total * 100, 1),
            })

    return drift


def audit_type_consistency(graph):
    """Identifica campi con tipi inconsistenti tra storie."""
    issues = []
    stories = graph.get('stories', {})

    field_types = {}  # field -> set of types
    for sid, story in stories.items():
        if sid.startswith('_'):
            continue
        for field, val in story.items():
            if field.startswith('_'):
                continue
            t = type(val).__name__
            if val is None:
                t = 'NoneType'
            field_types.setdefault(field, set()).add(t)

    for field, types in field_types.items():
        # Considera 'NoneType' compatibile con altri tipi (campo nullable)
        non_null_types = types - {'NoneType'}
        if len(non_null_types) > 1:
            issues.append({
                'field': field,
                'types_seen': sorted(types),
            })

    return issues


def main():
    parser = argparse.ArgumentParser(description='Audit drift between stories')
    parser.add_argument('--graph', required=True)
    args = parser.parse_args()

    with open(args.graph, encoding='utf-8') as f:
        graph = json.load(f)

    print("DRIFT DIAGNOSTIC (non-blocking)")
    print()

    print("Step 1: Field presence drift...")
    drift = audit_field_presence_drift(graph)
    if drift:
        print(f"  ⚠ {len(drift)} fields with presence drift:")
        for d in sorted(drift, key=lambda x: x['percentage']):
            print(f"      {d['field']}: present in {d['present_in']}/{d['total']} ({d['percentage']}%)")
    else:
        print("  ✓ No field presence drift")

    print()
    print("Step 2: Type consistency...")
    type_issues = audit_type_consistency(graph)
    if type_issues:
        print(f"  ⚠ {len(type_issues)} fields with type inconsistency:")
        for issue in type_issues:
            print(f"      {issue['field']}: types_seen={issue['types_seen']}")
    else:
        print("  ✓ All types consistent")

    print()
    total_warnings = len(drift) + len(type_issues)
    print(f"DIAGNOSTIC COMPLETE: {total_warnings} drift warnings (non-blocking)")
    sys.exit(0)


if __name__ == '__main__':
    main()
