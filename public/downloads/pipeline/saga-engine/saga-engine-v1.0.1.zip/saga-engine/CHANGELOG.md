# Changelog

## v1.0.1 (2026-04-25)

**Tipo**: PATCH — solo aggiornamenti documentazione, nessun cambiamento al metodo o agli script.

### Modificato

- `SKILL.md`: aggiunta riga **Download canonico** con URL completo del pacchetto sul sito (`https://nodo432.com/downloads/pipeline/saga-engine/saga-engine-v1.0.1.zip`).
- `README.md`: aggiunta riga **Download** con stesso URL.
- `USAGE.md`: lo step "Scarica lo zip" cita ora esplicitamente l'URL del download invece di rimandare solo al campo `download.file` del frontmatter.
- `VERSION`: 1.0.0 → 1.0.1.

### Razionale

Le saghe avviate con v1.0.0 restano valide. Lo schema, lo SKILL, le fasi di workflow, gli audit, i template non sono cambiati. v1.0.1 esiste solo per allineare le menzioni interne all'URL canonico effettivo sul sito (separazione `/downloads/...` per asset binari vs `/pipeline/...` per la pagina manifesto).

## v1.0.0 (2026-04-25)

Prima release pubblica.

- Sistema completo per scrittura di saghe narrative seriali
- Workflow A1→F (voice extraction → revisione)
- 7 script di audit Python
- 6 reference markdown
- Template grafo + schema JSON
- Reference implementation: L'Isola dei Tre Venti
- Validato su Claude (Sonnet 4.5, Opus 4.5), GPT-5, Gemini 2.5
- Licenza CC-BY-SA-4.0
