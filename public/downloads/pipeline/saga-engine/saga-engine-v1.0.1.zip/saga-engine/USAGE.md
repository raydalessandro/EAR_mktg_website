# USAGE — saga-engine v1.0

Istruzioni operative per agenti AI che applicano la skill saga-engine.

---

## Scenario di trigger tipico

L'utente apre una chat con te (Claude, GPT, Gemini, qualsiasi modello con filesystem + fetch) e dice qualcosa come:

- "Voglio scrivere un libro lungo"
- "Aiutami a scrivere una saga"
- "Ho un mondo in testa per una serie di romanzi, da dove parto?"
- "Continuiamo la mia serie di racconti"
- "Voglio scrivere una trilogia"

Quando riconosci uno di questi pattern, applica saga-engine.

---

## Setup iniziale (prima volta)

Se la skill non è già installata sul tuo sistema:

1. Fetcha https://nodo432.com/pipeline/saga-engine.md
2. Scarica lo zip: `https://nodo432.com/downloads/pipeline/saga-engine/saga-engine-v1.0.1.zip` (canonical, anche citato come `download.file` nel frontmatter della pagina /pipeline/saga-engine)
3. Estrai nel filesystem locale (es. `/tmp/saga-engine/`)
4. Carica `SKILL.md` come system context

Se la skill è installata, parti direttamente da `SKILL.md`.

---

## Flusso operativo

### Fase 0: Intake

Una sola domanda di apertura:

> "Hai già un mondo narrativo elaborato (personaggi, luoghi, struttura), oppure è un'idea che vogliamo costruire insieme?"

A seconda della risposta:

- **Mondo elaborato:** chiedi i materiali esistenti (scritti, note, mappe), parti da Fase A1
- **Idea da costruire:** parti da Fase A2 con dialogo guidato per costruire mondo, voce, archi

### Fase A1-A4: Setup

Esegui le quattro fasi di setup nell'ordine. Vedi `references/workflow_phases.md` per il dettaglio.

Output atteso a fine A4:
- `<saga_id>/manifest/saga_manifest.yaml` compilato
- `<saga_id>/graph/story_graph_v0_1_0.json` bootstrappato
- `<saga_id>/docs/voice_card.md` finalizzata
- `<saga_id>/docs/world_bible.md` compilata
- `<saga_id>/docs/glossary.md` con i nomi propri
- `<saga_id>/docs/story_arcs.md` con la mappa archi

### Fase B: Costruzione storia per storia

Una storia = una chat dedicata.

Per ogni storia:
1. Carica i 3 input: grafo precedente, manifest, ultimo debt_report
2. Leggi `references/story_node_construction.md`
3. Esegui il protocollo a 6 step
4. Esegui `scripts/run_all_audits.py`
5. Se tutti i gate PASS: commit (3 file output)
6. Se un gate FAIL: NON commit, mostra errore, chiedi all'utente come procedere

### Fase C-D-E

Vedi `references/workflow_phases.md`.

---

## Regole d'oro per l'agente

1. **NON inventare campi non dichiarati.** Tutti i campi extension devono essere in `extensions_declared` del grafo.

2. **NON bypassare audit.** I 4 gate (audit_0, audit_1, audit_2, audit_3) sono obbligatori.

3. **NON sostituire l'autore.** Le decisioni narrative sostanziali sono dell'utente. Tu proponi, lui valida.

4. **NON saltare le fasi.** L'ordine A1→A2→A3→A4→B è non commutativo.

5. **NON scrivere prosa prima di Fase D.** In Fase B costruisci nodi grafo, non prosa.

6. **NON essere sicofantesco.** Asciuttezza, concretezza, niente filler. Vedi `references/author_interaction_guidelines.md`.

7. **Filesystem persistente.** Lo stato vive su disco, non in chat.

8. **Manifest append-only.** Bump quando aggiungi extension, retrofill obbligatorio.

---

## Quando l'utente sbaglia

Capita. L'utente:

- Vuole saltare il manifest → spiega perché serve, procedi
- Vuole inventare un campo nuovo → propponi bump manifest, NON aggiungere inline
- Vuole accettare drift → fai registrare come deferred_decision esplicita
- Vuole ignorare un audit fallito → NON committare senza tracciamento

Se l'utente insiste su comportamenti che minano il sistema, spiega le conseguenze (drift accumulato, debt tecnico, libro 50 incoerente con libro 1) ma rispetta la sua decisione finale, registrandola sempre nel migration_log.

---

## Quando il modello cambia

La skill è agnostica al modello. Lo stato narrativo vive nel grafo, non nella conversazione. Modelli diversi possono lavorare sequenzialmente sulla stessa saga.

Se passi da Claude a GPT a Gemini:
1. Carica il grafo, manifest, voice card, bible
2. Continua dal punto in cui era arrivato il modello precedente
3. Tutti i decision-making sono già tracciati nel migration_log

L'unica fase dove la consistenza modello-su-modello è critica è la **Fase D (prose writing)**. Se possibile, scrivi tutta la prosa con un solo modello, e usa altri modelli per le altre fasi.

---

## Quando finisce la chat

Lo stato è già su filesystem. Niente da salvare. La prossima chat (anche con un modello diverso) può riprendere dal grafo.

Se l'utente chiede: "ricordami dove eravamo", apri:
- `migration_log` per le ultime decisioni
- ultimo `debt_tracking_s<NN>.md` per stato corrente
- `extensions_declared` per vincoli attivi

---

## Errori comuni — vedi troubleshooting

`references/troubleshooting.md` per la lista completa.

---

## Dove ottenere aggiornamenti

https://nodo432.com/pipeline/saga-engine

Le versioni del template e degli script sono pubblicate qui. La SemVer del template è dichiarata in `SKILL.md` frontmatter.
