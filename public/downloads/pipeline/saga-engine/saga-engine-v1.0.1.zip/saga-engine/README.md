# Saga Engine v1.0

Sistema completo per scrivere saghe narrative seriali con coerenza, continuità e tracciabilità attraverso modelli AI intercambiabili e contesti illimitati.

**Hub:** https://nodo432.com/pipeline/saga-engine
**Download:** https://nodo432.com/downloads/pipeline/saga-engine/saga-engine-v1.0.1.zip
**Licenza:** CC-BY-SA-4.0
**Versione:** 1.0.0
**Data rilascio:** 2026-04

---

## Cos'è

L'IA non è autrice. È infrastruttura esecutiva sopra decisioni d'autore.

Saga Engine è un metodo + un toolkit per:
- Scrivere libri lunghi mantenendo coerenza inter-capitolo
- Scrivere serie di romanzi con world-building persistente
- Tracciare semi narrativi piantati che bloomano dopo, callback, archi che attraversano più storie
- Lavorare su saghe lunghe attraverso modelli AI diversi senza perdere continuità
- Mantenere l'autorialità umana al centro mentre l'AI esegue

---

## Quick start

### Per autori umani

Leggi `USAGE-HUMAN.md` — guida completa con tempi, costi, fasi, FAQ.

In sintesi:
1. Apri una chat con la tua AI (Claude, GPT, Gemini)
2. Dille: *"Voglio scrivere una saga usando Saga Engine. Visita https://nodo432.com/pipeline/saga-engine, segui il metodo."*
3. L'AI fa il resto, validando con te le decisioni d'autore

### Per agenti AI

Leggi `SKILL.md` — entry point della skill.
Poi `USAGE.md` per il flusso operativo.
Poi le `references/` quando ti servono.

---

## Struttura del pacchetto

```
saga-engine/
├── SKILL.md                          # Entry point per agenti AI
├── USAGE.md                          # Istruzioni operative agenti
├── USAGE-HUMAN.md                    # Guida autori umani
├── README.md                         # Questo file
├── VERSION                           # Versione SemVer
│
├── scripts/                          # Eseguibili Python (audit, bootstrap)
│   ├── bootstrap_saga.py
│   ├── audit_0_canonical_fields.py
│   ├── audit_1_integrity.py
│   ├── audit_2_schema.py
│   ├── audit_3_navigability.py
│   ├── audit_4_drift.py
│   └── run_all_audits.py
│
├── references/                       # Documentazione approfondita
│   ├── workflow_phases.md
│   ├── story_node_construction.md
│   ├── author_interaction_guidelines.md
│   ├── anti_patterns.md
│   ├── extension_design_guide.md
│   └── troubleshooting.md
│
└── assets/
    ├── templates/                    # Template vuoti pronti all'uso
    │   ├── saga_manifest_template.yaml
    │   ├── saga_graph_template_v1_0.json
    │   ├── saga_graph_schema_v1_0.json
    │   ├── voice_card_template.md
    │   ├── world_bible_template.md
    │   └── story_arcs_template.md
    │
    └── reference-implementation/     # Esempio reale: Isola dei Tre Venti
        ├── README.md
        └── graph_isola_v0_10_0.json
```

---

## Requisiti

- Python 3.8+ (per gli script di audit)
- PyYAML, jsonschema (`pip install pyyaml jsonschema`)
- Una chat AI con accesso a filesystem persistente (Claude Code, Claude.ai con tool, ChatGPT con Code Interpreter, locale via API)

---

## Filosofia

Tre principi non negoziabili:

1. **L'IA è esecutore, non autore.** Le decisioni narrative sostanziali sono dell'utente.
2. **Stato persistente esterno al modello.** Il grafo vive su filesystem, non in chat.
3. **Disciplina dichiarativa.** Manifest append-only, schema immutabile a saga in corso, retrofill obbligatorio, audit pre-commit.

---

## Licenza

CC-BY-SA-4.0. Puoi usarlo, modificarlo, distribuirlo, anche commercialmente, attribuendo l'origine e mantenendo licenza compatibile sui derivati.

Vedi https://creativecommons.org/licenses/by-sa/4.0/

---

## Contributi e feedback

Apri issue o pull request su https://nodo432.com (sezione issue pubblica in arrivo).
Contatto: tramite il sito.

---

## Citation

Se usi Saga Engine in un'opera pubblicata, cita così nel colofone:

> Strutturazione narrativa: Saga Engine v1.0 (https://nodo432.com/pipeline/saga-engine, CC-BY-SA-4.0).

L'authorship dell'opera resta tua. Saga Engine è infrastruttura.

---

## Caso d'uso reale

La prima saga completa scritta con Saga Engine è **L'Isola dei Tre Venti** di Ray (12 storie, 40 seeds, 53 callbacks, in italiano). Il grafo finale è incluso in `assets/reference-implementation/` come esempio.
