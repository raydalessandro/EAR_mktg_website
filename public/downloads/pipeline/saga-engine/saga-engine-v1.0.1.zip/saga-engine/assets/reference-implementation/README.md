# Reference Implementation: L'Isola dei Tre Venti

> ⚠️ **QUESTO È UN ESEMPIO REALE, NON UN DEFAULT.**
> 
> Questa directory contiene un caso d'uso reale del saga-engine:
> la saga "L'Isola dei Tre Venti" di Ray (12 storie, 40 seeds, 53 callbacks).
> 
> **NON ereditare contenuti da qui per saghe diverse.**
> Usa template vuoti da `../../assets/templates/` e dialoga con l'utente
> per costruire la voce e il mondo specifici della sua saga.

---

## Perché esiste

L'esempio reale serve a:

1. **Validare empiricamente** che il template saga-engine funzioni su una saga completa
2. **Mostrare come si compila** un manifest, un grafo, una voice card
3. **Documentare patterns** che potrebbero ricorrere in altre saghe (con vocabolario diverso)
4. **Dare materiale di riferimento** per debugging

---

## Cosa contiene

- `manifest_isola.yaml` — il manifest reale di Isola
- `graph_isola_v0_10_0.json` — il grafo finale dopo le 12 storie (sintetizzato per riferimento)
- `voice_card_ray.md` — esempio di voice card estratta da corpus
- `world_bible_isola.md` — esempio di world bible compilata
- `story_arcs_isola.md` — esempio di mappa archi 12 storie

---

## Caratteristiche di Isola che NON sono da generalizzare

- **Numero esatto di storie:** 12 (struttura A/B/C/D × 3). Per altre saghe, qualsiasi numero.
- **Framework EAR:** specifico di Isola. Altre saghe potrebbero non avere alcun framework.
- **3 fratelli protagonisti:** specifico. Altre saghe possono avere 1 protagonista, gruppi corali, alternanza POV.
- **Target bambini 4-6 + 7-10 doppio strato:** specifico. Altre saghe avranno target diversi.
- **Vento + stagioni come dimensione ambientale:** specifico. Altre saghe useranno fenomeni diversi (o nessuno).
- **Pattern A "Le cose rotte arrivano lo stesso":** meta-pattern specifico. Altre saghe avranno pattern diversi (o nessuno).

---

## Caratteristiche che SÌ generalizzano

- La forma del workflow (A1 → A2 → A3 → A4 → B → C → D → E)
- La separazione core/extension
- Il principio del manifest dichiarativo + retrofill
- Il pattern di costruzione storia per storia in chat dedicate
- L'audit suite obbligatoria pre-commit
- La separazione tra "decisioni d'autore" (utente) e "esecuzione coerente" (agente)

---

## Per maggiori dettagli sul progetto Isola

Il progetto è documentato pubblicamente su https://nodo432.com (sezione Arte / Scrittura, in costruzione).
