# Voice Card — Template

> Compila questa scheda per estrarre la voce autoriale operativa.
> La voice card guida tutta la prosa della saga in Fase D.
> Lascia commenti `<!-- ... -->` come guida; rimuovili nel file finale.

---

## Identità

**Autore:**
**Saga:**
**Data estrazione:**
**Modalità di estrazione:** <!-- "from_corpus" se hai testi precedenti, "collaborative" se costruita in dialogo -->

---

## Tratti voce (12-16)

<!-- Per ogni tratto: Nome, Manifestazione, Esempio, Trigger -->

### Tratto 1: <!-- es. "Periodo breve secco" -->

**Manifestazione:** <!-- come si vede nel testo -->
**Esempio:** <!-- 2-3 frasi reali del corpus o costruite -->
**Trigger:** <!-- in quali contesti emerge -->

### Tratto 2:

**Manifestazione:**
**Esempio:**
**Trigger:**

<!-- Continua fino a 12-16 tratti. Tipi comuni: -->
<!-- - Lunghezza periodo (breve/medio/lungo) -->
<!-- - Punteggiatura distintiva (trattini, punto e virgola, parentesi) -->
<!-- - Lessico (registri, regionalismi, termini tecnici) -->
<!-- - Ritmo (cadenza, pause, accelerazioni) -->
<!-- - Metafore (frequenti/rare, ambito) -->
<!-- - Apostrofi al lettore -->
<!-- - Voce dei dialoghi -->
<!-- - Aggettivazione (densa/scarsa, posizione) -->
<!-- - Tempo verbale dominante -->
<!-- - Onomatopee, suoni, colpi sonori -->
<!-- - Chiusure di paragrafo (sigillo, immagine, frase nuda) -->
<!-- - Indirizzi temporali (datazione precisa/vaga) -->

---

## Registri ammessi

<!-- es. asciutto, lirico, ironico, pedagogico-implicito -->

## Registri vietati

<!-- es. sentimentale, didascalico, melodrammatico, sitcom, sicofantesco -->

---

## Anti-pattern (cose da non fare mai)

<!-- Cose che il sistema NON deve mai produrre nella tua voce -->

- <!-- es. "Numeri specifici inventati (ventitré farfalle, sette nuvole)" -->
- <!-- es. "Aggettivi tripli concatenati" -->
- <!-- es. "Riassunti tra le scene" -->
- <!-- es. "Chiusure didascaliche" -->
- <!-- es. "Metafore estese su più frasi" -->

---

## Direzione di chiusura

**Sigillo paragrafo:** <!-- come chiudi tipicamente: con immagine, frase nominale, gesto -->
**Sigillo capitolo:** <!-- come chiudi un capitolo: piano vs aperto, con voce vs senza -->
**Sigillo libro:** <!-- come chiudi un'opera intera (se applicabile) -->

---

## Note libere

<!-- Annotazioni che non rientrano nei tratti ma sono importanti -->
