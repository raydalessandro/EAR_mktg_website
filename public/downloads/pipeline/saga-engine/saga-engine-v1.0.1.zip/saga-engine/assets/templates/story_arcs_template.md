# Story Arcs — Template

> Mappa macro degli archi narrativi della saga.
> Definito in Fase A3, prima della costruzione dei nodi storia.

---

## Architettura saga

**Numero totale storie:**
**Struttura macro:** <!-- es. blocchi A/B/C/D di 3 storie ognuno -->
**Punti chiave:**
- Apertura saga: S1 — <titolo>
- Pivot 1: S<n> — <titolo>
- Pivot 2: S<n> — <titolo>
- Chiusura saga: S<n> — <titolo>

---

## Archi drammatici principali

### Arco 1: <!-- es. paura di Noah → bloom S10 -->

**Personaggio:**
**Tipo:** <!-- paura, desiderio, trasformazione, redenzione, ecc. -->
**First emergence:** S<n>
**Maturing:** S<n>, S<n>, ...
**Bloom (resolution):** S<n>
**Resolution mode:** <!-- come si risolve narrativamente -->

### Arco 2:

**Personaggio:**
**Tipo:**
**First emergence:**
**Maturing:**
**Bloom:**
**Resolution mode:**

<!-- ... continua per ogni arco principale ... -->

---

## Storie (S1 → SN)

### S01 — <!-- titolo provvisorio -->

**Posizione:** <!-- es. apertura saga / centro blocco A / chiusura blocco A -->
**Premessa:** <!-- 3-5 righe, cosa succede -->
**Problema narrativo:**
**Personaggi in scena:**
**Location primary:**
**Connessioni inter-storia:**
- Semi piantati: <!-- elementi che bloomeranno in S<n> -->
- Callback ricevuti: <!-- elementi richiamati da S<n> precedenti -->
- Debts opened/closed:

**Vincoli toccati:** <!-- quali constraint globali si attivano -->

### S02 — <titolo>

<!-- stessa struttura -->

<!-- ... continua per tutte le storie ... -->

---

## Pattern strutturali

<!-- Pattern che attraversano la saga in modo non-lineare -->

### Pattern A: <!-- es. "Le cose rotte arrivano lo stesso" -->

**Stories di pre-eco:**
**Stories di semina:**
**Stories di attivazione:**
**Stories di bloom:**
**Constraint globale:** <!-- es. "mai_nominato_nel_testo" -->

### Pattern B:

<!-- ... -->

---

## Cornici di apertura/chiusura

<!-- Es. cornice S1↔SN al Forno: stesso luogo, stessa scena strutturale -->

---

## Note libere

<!-- Decisioni d'autore non strutturate ma importanti -->
