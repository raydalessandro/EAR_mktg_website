# World Bible — Template

> La bible del mondo narrativo. Fonte di verità su cui ogni storia poggia.
> Compila tutte le sezioni applicabili. Lascia vuote le non pertinenti.

---

## 1. Identità del mondo

**Genere:** <!-- realistico, fantastico, sci-fi, ibrido, metaforico -->
**Tempo:** <!-- contemporaneo, storico, futuro, atemporale, fluido -->
**Spazio:** <!-- un villaggio, una città, un pianeta, un universo, un'isola -->
**Tono dominante:** <!-- avventuroso, contemplativo, drammatico, comico, ibrido -->
**Target:** <!-- bambini 4-6, young adult, adulti generalisti, lettori letterari -->

---

## 2. Geografia

**Mappa fisica:** <!-- struttura geografica, dimensioni, climi -->
**Mappa simbolica:** <!-- geografia frattale o mandala se applicabile (es. Isola: 4 quadranti, 3 cinture) -->
**Confini:** <!-- cosa c'è oltre il mondo, è raggiungibile -->
**Centri:** <!-- luoghi-chiave, gerarchia simbolica -->

---

## 3. Personaggi

### Protagonisti

<!-- Per ogni protagonista: nome, ruolo, tratto distintivo, voce, paura/desiderio -->

### Secondari ricorrenti

<!-- Personaggi che compaiono in più storie con funzione narrativa stabile -->

### Gruppi

<!-- Gruppi sociali ricorrenti come entità narrative (es. coltivatori, pastori, mercanti) -->

### Antagonisti / forze opposte

<!-- Se la saga ha antagonisti diretti o solo "forze del mondo" -->

### Voci (parlato per ogni personaggio chiave)

<!-- Come parla ognuno: lessico, registro, tic linguistici -->

---

## 4. Tempo e stagioni

**Calendario:** <!-- es. anno solare, anno lunare, ciclo astrale, atemporale -->
**Stagioni:** <!-- nomi e proprietà delle stagioni se rilevanti -->
**Ritmo della saga:** <!-- 12 storie = 1 anno? un ciclo di tempo non lineare? -->

---

## 5. Sistema dei vincoli

**Cosa è possibile in questo mondo:** <!-- magia, tecnologia, fenomeni speciali -->
**Cosa NON è possibile:** <!-- limiti chiari, leggi del mondo -->
**Regole sociali:** <!-- gerarchie, norme, divieti -->

---

## 6. Mito di fondazione (se rilevante)

<!-- Origine del mondo. Versione canonica. Cosa il narratore può dire e cosa no. -->

---

## 7. Tabù e linee rosse

<!-- Cosa NON deve mai accadere o essere nominato. -->

- <!-- es. "Notte non personificata" -->
- <!-- es. "Nessun framework ontologico nominato esplicitamente" -->
- <!-- es. "Personaggio X non pronuncia mai i nomi propri Y/Z" -->

---

## 8. Pattern silenti

<!-- Meta-pattern che attraversano la saga senza essere mai nominati. -->
<!-- Vivono in immagini, gesti, ricorrenze, mai in dichiarazioni. -->

---

## 9. Fenomeni ricorrenti

<!-- Fenomeni che attraversano più storie come elementi atmosferici/strutturali -->
<!-- es. "I tre venti", "le maree", "il ritorno della cometa" -->

---

## 10. Note sulla narrazione

**Tipo di narratore:** <!-- onnisciente, in prima, ibrido, narratore-iniziato -->
**Tempo della narrazione:** <!-- presente, passato, fluido -->
**Indirizzi al lettore:** <!-- sì/no, frequenza, registro -->
**Rivelazioni rinviate:** <!-- cose che il narratore sa ma non dice fino a... -->

---

## 11. Riferimenti e ispirazioni

<!-- Opere/autori di riferimento per tono, atmosfera, costruzione -->
