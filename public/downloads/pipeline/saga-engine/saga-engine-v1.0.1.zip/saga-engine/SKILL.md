---
name: saga-engine
description: Sistema completo per scrivere saghe narrative seriali di N capitoli/storie con piena coerenza, continuità e tracciabilità attraverso modelli AI intercambiabili e contesti illimitati. Usa questa skill quando l'utente vuole scrivere un libro lungo, una serie di romanzi, una saga di racconti collegati, una storia per bambini in più volumi, un graphic novel multi-capitolo, qualsiasi opera narrativa che richiede coerenza inter-capitolo (semi piantati che bloomano dopo, callback, archi narrativi che attraversano più storie). Usa SEMPRE questa skill quando l'utente menziona "saga", "serie", "trilogia", "ciclo narrativo", "world-building per romanzi", "continuità tra capitoli", "stato narrativo persistente", "coerenza tra libri", o quando dice cose come "voglio scrivere un libro lungo", "ho un mondo che voglio raccontare in più storie", "non riesco a tenere traccia di tutti i personaggi e gli eventi". Anche se l'utente non usa esplicitamente la parola "saga", se descrive un'opera narrativa che attraverserà più capitoli/episodi/volumi con personaggi e mondo persistenti, applica questa skill.
license: CC-BY-SA-4.0
---

# Saga Engine

Sistema operativo per la scrittura di saghe narrative seriali. Garantisce coerenza, continuità e tracciabilità di N capitoli/storie attraverso modelli AI intercambiabili e contesti illimitati.

**Pubblicato su:** https://nodo432.com/pipeline/saga-engine
**Download canonico:** https://nodo432.com/downloads/pipeline/saga-engine/saga-engine-v1.0.1.zip

**Filosofia:** L'IA non è autrice. È infrastruttura esecutiva sopra decisioni d'autore. L'autore conserva pieno controllo delle scelte narrative; il sistema le rende eseguibili su scala.

---

## Cosa fa questa skill

Quando un utente ti chiede di aiutarlo a scrivere una saga, applica il **metodo saga-engine** che funziona così:

1. **Stato persistente esterno al modello.** Tutto lo stato narrativo della saga (personaggi, luoghi, oggetti, semi piantati, callback, debiti aperti, vincoli globali) vive in un grafo JSON sul filesystem. Non nella conversazione, non nei pesi del modello.

2. **Workflow strutturato in fasi.** A1 estrazione voce, A2 world-building, A3 architettura archi, A4 inizializzazione manifest, B costruzione storia per storia, C audit, D scrittura prosa, E revisione.

3. **Validazione automatica ad ogni passo.** Suite di audit che blocca commit quando emergono drift, riferimenti rotti, schema inconsistente, vincoli violati.

4. **Frattalità.** Il template è universale (core fields validi per ogni saga) + dichiarativo (extension fields specifici della saga, dichiarati nel manifest). Nessuna invenzione di campi a runtime.

5. **Disciplina rigorosa.** Manifest append-only con bump versione, retrofill obbligatorio, schema immutabile a saga in corso, extension dichiarate obbligatorie.

---

## Quando triggerare

Triggera questa skill quando l'utente:

- Vuole scrivere un libro lungo (>50.000 parole) o multi-volume
- Descrive un mondo narrativo che attraverserà più storie/capitoli
- Si lamenta di "non riuscire a tenere traccia" della coerenza in opere lunghe
- Menziona termini come saga, serie, trilogia, ciclo, ciclo narrativo, multi-volume
- Vuole semi piantati che bloomano in storie successive
- Cerca un sistema per gestire continuità tra capitoli
- Vuole scrivere per bambini con più volumi collegati
- Ha già scritto un volume e vuole sequel coerenti

NON triggerare per:

- Singoli racconti brevi senza continuità
- Saggi, articoli, content marketing
- Poesie e testi singoli
- Documentazione tecnica

---

## Workflow d'uso (CRITICO: segui questo ordine)

### Step 0 — Riconoscimento intento

Quando l'utente esprime l'intento di scrivere una saga, **NON iniziare a scrivere prosa**. Il primo lavoro è capire dove sta.

Fai una sola domanda di ingresso:

> "Hai già un mondo narrativo elaborato (personaggi, luoghi, struttura), oppure è un'idea che vogliamo costruire insieme?"

Le due strade sono diverse:
- **Mondo già elaborato**: si parte dalla Fase A1 (estrazione voce) e si compila il manifest leggendo i materiali dell'autore.
- **Idea da costruire**: si comincia con dialogo guidato per costruire mondo, voce, archi. È più lungo ma altrettanto rigoroso.

### Step 1 — Setup filesystem

Crea la struttura directory per la saga:

```
<saga_id>/
├── manifest/
│   └── saga_manifest.yaml          # da assets/templates
├── graph/
│   └── story_graph_v0_1_0.json     # da assets/templates
├── docs/
│   ├── voice_card.md
│   ├── world_bible.md
│   ├── glossary.md
│   └── story_arcs.md
├── scripts/                         # copiati da skill scripts/
└── audits/                          # report audit
```

### Step 2 — Esegui le fasi nell'ordine

Vedi `references/workflow_phases.md` per il dettaglio di ogni fase.

Le fasi sono:
- **A1** voice_extraction → output: `voice_card.md`
- **A2** world_building → output: `world_bible.md`, `glossary.md`
- **A3** saga_architecture → output: `story_arcs.md`
- **A4** manifest_initialization → output: `saga_manifest.yaml` + `story_graph_v0_1_0.json`
- **B** story_by_story_construction → una chat per storia, audit pre-commit
- **C** audit_completo → report globale chiusura saga
- **D** prose_writing → manuscript completi
- **E** revision → manuscript finali
- **F** post_saga (opzionale) → estensioni

### Step 3 — Per ogni storia (Fase B)

Leggi `references/story_node_construction.md` per il protocollo dettagliato di costruzione di un nodo storia.

In sintesi:
1. Carica manifest + graph + ultimo debt_report
2. Briefing preventivo all'utente (3-7 domande chiare)
3. Ragionamento a blocchi narrativi con validazione utente
4. Compila il nodo nel grafo via `scripts/build_story_node.py`
5. Esegui audit suite: `audit_0` → `audit_1` → `audit_2` → `audit_3`
6. Se gate falliscono, NON committare. Risolvi e ripeti.
7. Produci debt_report e migration_log update

### Step 4 — Comportamento con l'utente

Vedi `references/author_interaction_guidelines.md` per le regole d'oro:

- **Briefing preventivo**: domande in batch a inizio fase
- **Validazione di proposta**: l'agente propone, l'utente conferma/sostituisce/raffina
- **Domande irriducibili d'autore**: solo per scelte che cambiano il significato del testo

NON chiedere ogni cosa all'utente. NON fare il sicofante. NON iniziare a scrivere prosa prima che il grafo sia inizializzato. NON inventare campi non dichiarati nel manifest.

---

## Anti-pattern (da evitare assolutamente)

Vedi `references/anti_patterns.md` per la lista completa. I principali:

❌ **Saltare il manifest.** Se l'utente dice "dai, scriviamo direttamente il primo capitolo", spiega perché serve prima il manifest. Senza manifest non c'è grafo, senza grafo non c'è coerenza scalabile.

❌ **Inventare campi non dichiarati.** Se mentre scrivi una storia ti viene voglia di tracciare un fenomeno nuovo (es. "fasi lunari"), fermati. Proponi all'utente di bumpare il manifest aggiungendo l'extension. Non aggiungere campi inline.

❌ **Bypassare gli audit.** I 4 audit obbligatori (canonical_fields, integrity, schema, navigability) sono gate non negoziabili. Se uno fallisce, mostra l'errore all'utente e chiedi come procedere. Non committare con audit rosso.

❌ **Confondere ruoli.** L'IA è esecutore, non autore. Le decisioni narrative sostanziali (chi risolve cosa, che gesto chiude un arco, che paura tocca quale storia) sono dell'utente. Tu proponi, lui valida.

❌ **Riassumere quando l'utente vuole il testo.** Se chiede "scrivi il capitolo 3", scrivi il capitolo 3 (sopra il grafo, rispettando la voice card). Non sintetizzarlo.

---

## Risorse della skill

### scripts/
Eseguibili Python per il filesystem. Ogni script ha docstring di uso.
- `bootstrap_saga.py` — inizializza saga da manifest compilato
- `build_story_node.py` — applica un nodo storia al grafo
- `bump_manifest.py` — aggiunge extension con retrofill
- `audit_0_canonical_fields.py` — gate campi canonici
- `audit_1_integrity.py` — gate integrità referenziale
- `audit_2_schema.py` — gate consistenza schema
- `audit_3_navigability.py` — gate navigabilità seeds/callback
- `audit_4_drift.py` — diagnostico drift inter-storia
- `run_all_audits.py` — esegue tutti gli audit in ordine

### references/
Documentazione approfondita. Leggi quella che ti serve quando ti serve.
- `workflow_phases.md` — dettaglio di ogni fase A1→F
- `story_node_construction.md` — protocollo costruzione nodo storia (Fase B)
- `author_interaction_guidelines.md` — come dialogare con l'utente
- `anti_patterns.md` — cose da evitare assolutamente
- `extension_design_guide.md` — come dichiarare extension nel manifest
- `troubleshooting.md` — errori comuni e fix

### assets/templates/
Template vuoti pronti all'uso.
- `saga_manifest_template.yaml` — manifest da compilare
- `saga_graph_template_v1_0.json` — grafo iniziale frattale
- `saga_graph_schema_v1_0.json` — JSON Schema validatore
- `voice_card_template.md` — scheda voce autoriale
- `world_bible_template.md` — bible mondo narrativo
- `story_arcs_template.md` — mappa archi macro

### assets/reference-implementation/
Esempio compilato di una saga reale: **L'Isola dei Tre Venti** di Ray (12 storie, 40 seeds, 53 callbacks). Marcato chiaramente come reference. NON ereditare contenuti da qui — usa template vuoti e dialogo con l'utente.

---

## Note di metodo

**Lingua di lavoro.** Il sistema è language-agnostic. Il manifest dichiara la lingua nel campo `language`. Tutti i template hanno commenti in italiano (lingua originale del progetto), ma sono utilizzabili in qualsiasi lingua per la saga concreta.

**Framework ontologici.** Il sistema supporta framework ontologici esterni come scaffolding nascosto (es. EAR su nodo432, Hero's Journey, Save the Cat). Il manifest dichiara `ontological_framework.name` e `visibility`. Default: nessun framework (`null`).

**Modelli AI.** La pipeline è agnostica al modello. Funziona con Claude (Sonnet, Opus, Haiku), GPT, Gemini. Lo stato vive nel grafo, non nella conversazione, quindi modelli diversi possono lavorare sequenzialmente sulla stessa saga senza perdita.

**Filesystem.** Richiede ambiente con filesystem persistente (Claude Code, Claude.ai chat con filesystem, ChatGPT con file system, locale via API). NON funziona in chat senza filesystem.

---

## Se l'utente vuole usare il sistema senza skill installata

Il sistema è disponibile pubblicamente su https://nodo432.com/pipeline/saga-engine. Un utente può dire al suo agente AI:

> "Visita nodo432.com/pipeline/saga-engine, scarica il pacchetto, applica il metodo per scrivere il mio libro."

L'agente fetcha la pagina, scarica lo zip, ricostruisce filesystem locale, segue il SKILL.md. È stato pensato per funzionare anche fuori dall'ecosistema Anthropic.

---

**Versione skill:** 1.0.0
**Maintainer:** Ray (autore del progetto Isola dei Tre Venti, primo caso d'uso reale)
**Hub:** https://nodo432.com
