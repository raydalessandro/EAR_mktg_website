# Bridge Signature - Definitive Verification Package

## Key Finding
**Modulatory neurons are 3.24x over-represented among bridge nodes (p = 0.00003)**

## Files
- `NeuronConnect.xls` - C. elegans connectome data
- `elife-95402-supp2-v1.xlsx` - Official neurotransmitter classification (eLife 2024)
- `bridge_signature_definitive.py` - Analysis script
- `RESULTS.md` - Detailed results

## Quick Start
```bash
pip install pandas networkx numpy scipy xlrd openpyxl
python bridge_signature_definitive.py
```

## Citation
- Connectome: Varshney et al., PLOS Comp Bio 2011
- Classification: Hobert et al., eLife 2024 (doi: 10.7554/eLife.95402)
