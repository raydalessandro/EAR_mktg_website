"""
TEST AVANZATI: Simulazione rimozione archi e analisi dinamica
"""

import json
from collections import defaultdict
import random

with open('/home/claude/GRAFO_MATRIX_72_EXPANDED.json', 'r') as f:
    graph = json.load(f)

unique_edges = {}
for edge in graph['edges']:
    key = tuple(sorted([edge['source'], edge['target']]))
    if key not in unique_edges:
        unique_edges[key] = edge

# Calcola gradi
def calc_degrees(edges_set):
    degree = defaultdict(int)
    for key in edges_set:
        degree[key[0]] += 1
        degree[key[1]] += 1
    return degree

degree = calc_degrees(unique_edges.keys())

# Trova archi tra nodi A=2
def get_A(node):
    return int(node.split('_')[2])

edges_A2_A2 = [k for k in unique_edges if get_A(k[0]) == 2 and get_A(k[1]) == 2]

print("=" * 70)
print("TEST 4: RIMOZIONE ARCHI E IMPATTO SULLA CONNETTIVITÀ")
print("=" * 70)

print(f"\nArchi tra nodi A=2 (⇄-⇄): {len(edges_A2_A2)}")

# Se rimuoviamo 12 archi A2-A2 a caso, cosa succede?
print("\nSIMULAZIONE: Rimuoviamo 12 archi A2-A2 casuali")

# Funzione per verificare connettività (BFS)
def is_connected(edges_set, nodes):
    if not edges_set:
        return False
    adj = defaultdict(set)
    for e in edges_set:
        adj[e[0]].add(e[1])
        adj[e[1]].add(e[0])
    
    start = list(nodes)[0]
    visited = {start}
    queue = [start]
    while queue:
        node = queue.pop(0)
        for neighbor in adj[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return len(visited) == len(nodes)

nodes = set()
for k in unique_edges:
    nodes.add(k[0])
    nodes.add(k[1])

print(f"\nGrafo originale: {len(unique_edges)} archi, connesso: {is_connected(unique_edges.keys(), nodes)}")

# Test 1: Rimuovi 12 archi A2-A2 casuali
random.seed(42)
to_remove = random.sample(edges_A2_A2, 12)
remaining = set(unique_edges.keys()) - set(to_remove)
new_degree = calc_degrees(remaining)
degrees = list(new_degree.values())

print(f"\nDopo rimozione 12 archi A2-A2 casuali:")
print(f"  Archi: {len(remaining)}")
print(f"  Connesso: {is_connected(remaining, nodes)}")
print(f"  Grado min: {min(degrees)}, max: {max(degrees)}")
print(f"  Grado medio: {sum(degrees)/len(degrees):.2f}")

# Verifica se ora tutti hanno grado 12
from collections import Counter
degree_dist = Counter(degrees)
print(f"  Distribuzione gradi: {dict(sorted(degree_dist.items()))}")

print("\n" + "=" * 70)
print("TEST 5: QUALI 12 ARCHI DAREBBERO CRISTALLO PERFETTO?")
print("=" * 70)

# Troviamo i 12 archi che, se rimossi, danno tutti grado 12
# Questi devono essere archi tra due nodi attualmente di grado 13

degree_13_nodes = [n for n, d in degree.items() if d == 13]
edges_between_13 = [k for k in unique_edges if k[0] in degree_13_nodes and k[1] in degree_13_nodes]

print(f"\nArchi tra nodi di grado 13: {len(edges_between_13)}")

# Per avere tutti grado 12, servono esattamente 12 archi tali che
# coprono tutti i 24 nodi di grado 13 esattamente una volta

# Verifica: ogni nodo grado 13 deve perdere esattamente 1 arco
# Quindi serve un "perfect matching" di 12 archi sui 24 nodi

print("\nCerchiamo un matching perfetto tra i 24 nodi di grado 13...")

# Costruisci sottografo dei nodi grado 13
subgraph_13 = defaultdict(set)
for e in edges_between_13:
    subgraph_13[e[0]].add(e[1])
    subgraph_13[e[1]].add(e[0])

# Greedy matching (non ottimale ma veloce)
matched = set()
matching = []
for n1 in degree_13_nodes:
    if n1 in matched:
        continue
    for n2 in subgraph_13[n1]:
        if n2 not in matched:
            matching.append((n1, n2))
            matched.add(n1)
            matched.add(n2)
            break

print(f"Matching trovato: {len(matching)} coppie")
print(f"Nodi coperti: {len(matched)}/24")

if len(matching) == 12:
    print("\n✓ ESISTE un matching perfetto di 12 archi!")
    print("\nI 12 archi che, se rimossi, danno cristallo perfetto:")
    for e in matching:
        print(f"  {e[0]} <-> {e[1]}")
    
    # Verifica
    remaining = set(unique_edges.keys()) - set(tuple(sorted(e)) for e in matching)
    new_degree = calc_degrees(remaining)
    degrees = list(new_degree.values())
    print(f"\nVerifica dopo rimozione:")
    print(f"  Archi: {len(remaining)}")
    print(f"  Distribuzione gradi: {dict(Counter(degrees))}")

print("\n" + "=" * 70)
print("TEST 6: PROPRIETÀ DINAMICHE")
print("=" * 70)

print("""
Domanda: Se togliamo i 12 archi, il sistema diventa "morto"?

Per verificarlo, dovremmo simulare:
1. Propagazione di segnali nel grafo
2. Tempo di convergenza a equilibrio
3. Capacità di "rispondere" a perturbazioni

Ipotesi: Il grafo con 444 archi ha proprietà dinamiche
         che il grafo con 432 archi NON ha.
         
Metriche da testare:
- Tempo di mixing (random walk)
- Robustezza a rimozione nodi
- Clustering coefficient
- Centralità dei nodi
""")

# Calcola clustering coefficient
def clustering_coeff(edges_set, node):
    neighbors = set()
    for e in edges_set:
        if e[0] == node:
            neighbors.add(e[1])
        elif e[1] == node:
            neighbors.add(e[0])
    
    if len(neighbors) < 2:
        return 0
    
    # Conta archi tra vicini
    edges_between = 0
    for n1 in neighbors:
        for n2 in neighbors:
            if n1 < n2 and (n1, n2) in edges_set:
                edges_between += 1
    
    possible = len(neighbors) * (len(neighbors) - 1) / 2
    return edges_between / possible if possible > 0 else 0

# Calcola per alcuni nodi
edges_set = set(unique_edges.keys())
sample_nodes = list(nodes)[:10]

print("\nClustering coefficient (campione):")
for node in sample_nodes[:5]:
    cc = clustering_coeff(edges_set, node)
    print(f"  {node}: {cc:.3f}")

# Media globale
total_cc = sum(clustering_coeff(edges_set, n) for n in nodes) / len(nodes)
print(f"\nClustering medio globale: {total_cc:.4f}")

# Confronta con grafo a 432 archi
remaining_432 = set(unique_edges.keys()) - set(tuple(sorted(e)) for e in matching)
total_cc_432 = sum(clustering_coeff(remaining_432, n) for n in nodes) / len(nodes)
print(f"Clustering medio (432 archi): {total_cc_432:.4f}")
print(f"Differenza: {(total_cc - total_cc_432)/total_cc_432 * 100:.2f}%")
