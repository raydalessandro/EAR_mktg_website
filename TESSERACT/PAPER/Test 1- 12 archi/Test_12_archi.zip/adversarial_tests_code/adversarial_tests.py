"""
ADVERSARIAL ANALYSIS: Cosa testeranno i ricercatori?

Mettiamoci nei panni di un reviewer scettico che vede il paper.
Cosa cercherà di demolire per primo?
"""

import json
import numpy as np
from collections import defaultdict
from itertools import combinations

# Carica il grafo
with open('/home/claude/GRAFO_MATRIX_72_EXPANDED.json', 'r') as f:
    graph = json.load(f)

nodes = graph['nodes']
edges = graph['edges']

# Estrai archi unici
unique_edges = {}
for edge in edges:
    key = tuple(sorted([edge['source'], edge['target']]))
    if key not in unique_edges:
        unique_edges[key] = edge

print("=" * 70)
print("ADVERSARIAL ANALYSIS: COSA TESTERANNO I RICERCATORI?")
print("=" * 70)

print("""
I ricercatori scettici si focalizzeranno su:

1. I 12 ARCHI "EXTRA" — Sono davvero speciali o arbitrari?
2. LA DERIVAZIONE KABBALISTICA — È necessaria o decorativa?
3. L'ASIMMETRIA 1/36 — Ha significato fisico o è numerologia?
4. LA RICORSIVITÀ — Funziona davvero a ogni scala?
5. L'ISOMORFISMO CROSS-DOMAIN — È verificabile o metaforico?
""")

print("\n" + "=" * 70)
print("TEST 1: IDENTIFICARE I 12 ARCHI EXTRA")
print("=" * 70)

# Se 432 = cristallo perfetto grado 12, quali sono i 12 in più?
# Devo trovare quali nodi hanno grado 13 vs grado 12

# Calcola gradi
degree = defaultdict(int)
for key in unique_edges:
    degree[key[0]] += 1
    degree[key[1]] += 1

degree_12 = [n for n, d in degree.items() if d == 12]
degree_13 = [n for n, d in degree.items() if d == 13]

print(f"\nNodi con grado 12: {len(degree_12)}")
print(f"Nodi con grado 13: {len(degree_13)}")
print(f"Totale: {len(degree_12) + len(degree_13)}")

# I 12 archi extra sono distribuiti tra i nodi di grado 13
# Se 24 nodi hanno grado 13, e 48 hanno grado 12:
# Totale gradi = 48*12 + 24*13 = 576 + 312 = 888 = 444*2 ✓

print(f"\nVerifica: 48×12 + 24×13 = {48*12} + {24*13} = {48*12 + 24*13}")
print(f"          = 888 = 444×2 ✓")

# Quali sono i nodi di grado 13?
print(f"\nI 24 NODI DI GRADO 13 (che hanno l'arco 'extra'):")
for i, node in enumerate(sorted(degree_13)[:24]):
    if i < 12:
        print(f"  {node}")
    elif i == 12:
        print("  ...")

# Pattern nei nodi di grado 13?
print("\n" + "=" * 70)
print("TEST 2: PATTERN NEI NODI DI GRADO 13")
print("=" * 70)

# Estrai coordinate
def parse_coord(node_id):
    """Estrae D, A, X, P dal nome del nodo"""
    parts = node_id.replace('Σ_', '').split('_')
    D = int(parts[0])
    A = int(parts[1])
    X = int(parts[2])
    P = parts[3]
    return {'D': D, 'A': A, 'X': X, 'P': P}

# Analizza distribuzione per coordinata
print("\nDistribuzione dei nodi di grado 13 per coordinata:")

for coord in ['D', 'A', 'X', 'P']:
    dist = defaultdict(int)
    for node in degree_13:
        val = parse_coord(node)[coord]
        dist[val] += 1
    print(f"\n  {coord}: {dict(sorted(dist.items()))}")
    
# Confronta con distribuzione attesa (uniforme)
print("\n  Atteso (uniforme): D={1:6,2:6,3:6,4:6}, A={1:8,2:8,3:8}, X={1:8,2:8,3:8}, P={+:12,-:12}")

print("\n" + "=" * 70)
print("TEST 3: I 12 ARCHI SONO DERIVABILI O ARBITRARI?")
print("=" * 70)

# Trova gli archi che "eccedono" il grado 12
# Questi sono gli archi che, se rimossi, darebbero grado uniforme 12

# Per ogni nodo di grado 13, trova quale arco è "quello in più"
print("\nDomanda critica: QUALI sono i 12 archi extra?")
print("Se li rimuoviamo, otteniamo un cristallo perfetto?")

# Costruisci il problema come ottimizzazione
# Dobbiamo rimuovere 12 archi tale che tutti i gradi diventino 12

# Prima verifica: quanti archi collegano due nodi di grado 13?
edges_13_13 = []
edges_13_12 = []
edges_12_12 = []

for key in unique_edges:
    d1 = degree[key[0]]
    d2 = degree[key[1]]
    if d1 == 13 and d2 == 13:
        edges_13_13.append(key)
    elif d1 == 13 or d2 == 13:
        edges_13_12.append(key)
    else:
        edges_12_12.append(key)

print(f"\nArchi tra nodi grado 13-13: {len(edges_13_13)}")
print(f"Archi tra nodi grado 13-12: {len(edges_13_12)}")
print(f"Archi tra nodi grado 12-12: {len(edges_12_12)}")
print(f"Totale: {len(edges_13_13) + len(edges_13_12) + len(edges_12_12)}")

# Se rimuovo un arco 13-13, abbasso entrambi i gradi
# Se rimuovo un arco 13-12, abbasso solo uno
# Per arrivare a tutti grado 12, devo:
# - Abbassare 24 nodi da 13 a 12 = rimuovere 24 "mezzi archi"
# - 12 archi 13-13 farebbero il lavoro (24/2 = 12) ✓

print(f"\nSe i {len(edges_13_13)} archi 13-13 fossero esattamente 12,")
print("rimuovendoli tutti avremmo grado uniforme 12.")
print(f"Attuale: {len(edges_13_13)} archi 13-13")

if len(edges_13_13) == 12:
    print("\n✓ ESATTAMENTE 12 ARCHI 13-13!")
    print("  Questi sono i 12 archi 'extra' che danno il respiro.")
    print("\n  Vediamoli:")
    for key in edges_13_13:
        print(f"    {key[0]} <-> {key[1]}")
