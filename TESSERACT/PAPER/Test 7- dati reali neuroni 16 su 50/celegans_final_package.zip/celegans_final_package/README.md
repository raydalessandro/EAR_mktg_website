# C. elegans Connectome - Bridge Signature Verification

## Summary
This package verifies the theoretical prediction that modulatory neurons 
(dopamine, serotonin, tyramine, octopamine) are structural bridges in the 
C. elegans nervous system.

## Key Result
**Modulatory neurons are 2.91x over-represented among bridge nodes (p = 0.0004)**

## Files
- `NeuronConnect.xls` - Raw connectome data (Varshney et al.)
- `analyze_bridge_signature.py` - Complete analysis script
- `C_ELEGANS_FINAL_RESULTS.md` - Detailed results

## Quick Start
```bash
pip install pandas networkx numpy scipy xlrd openpyxl
python analyze_bridge_signature.py
```

## Citation
- Connectome: Varshney et al., PLOS Comp Bio 2011
- Neurotransmitter classification: Hobert et al., eLife 2024
