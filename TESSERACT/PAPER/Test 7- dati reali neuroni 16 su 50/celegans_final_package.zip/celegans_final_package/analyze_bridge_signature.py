"""
BRIDGE SIGNATURE VERIFICATION ON C. ELEGANS CONNECTOME
=======================================================

This script verifies the theoretical prediction that modulatory neurons
(dopaminergic, serotonergic, tyraminergic, octopaminergic) have the
"bridge signature": high degree, high betweenness, low clustering.

Requirements: pip install pandas networkx numpy scipy xlrd openpyxl
"""

import pandas as pd
import networkx as nx
import numpy as np
from scipy import stats

# NEURON CLASSIFICATION
# Source: eLife 2024 "A neurotransmitter atlas of C. elegans"

MODULATORY = {
    # Dopaminergic (cat-2/TH positive)
    'ADEL', 'ADER', 'CEPDL', 'CEPDR', 'CEPVL', 'CEPVR', 'PDEL', 'PDER',
    # Serotonergic (tph-1/TPH positive)
    'ADFL', 'ADFR', 'NSML', 'NSMR', 'HSNL', 'HSNR', 'AIM', 'RIH',
    # Tyraminergic/Octopaminergic (tdc-1/TDC positive)
    'RIML', 'RIMR', 'RIC', 'UV1L', 'UV1R',
}

GABAERGIC = {
    # DD motor neurons
    'DD01', 'DD02', 'DD03', 'DD04', 'DD05', 'DD06',
    # VD motor neurons
    'VD01', 'VD02', 'VD03', 'VD04', 'VD05', 'VD06', 'VD07',
    'VD08', 'VD09', 'VD10', 'VD11', 'VD12', 'VD13',
    # RME neurons
    'RMED', 'RMEL', 'RMER', 'RMEV',
    # Others
    'AVL', 'DVB', 'RIS', 'AVKL', 'AVKR',
}


def load_connectome(filepath):
    """Load C. elegans connectome from Excel file"""
    df = pd.read_excel(filepath)
    df_neurons = df[df['Type'] != 'NMJ'].copy()
    
    G = nx.Graph()
    for _, row in df_neurons.iterrows():
        n1, n2 = row['Neuron 1'], row['Neuron 2']
        weight = row['Nbr']
        if G.has_edge(n1, n2):
            G[n1][n2]['weight'] += weight
        else:
            G.add_edge(n1, n2, weight=weight)
    
    return G


def classify_neurons(G):
    """Classify neurons by neurotransmitter type"""
    types = {}
    for node in G.nodes():
        if node in MODULATORY:
            types[node] = 'M'  # Modulatory
        elif node in GABAERGIC:
            types[node] = 'I'  # Inhibitory
        else:
            types[node] = 'E'  # Excitatory
    return types


def find_bridges(G, degrees, betweenness, clustering):
    """Find nodes with bridge signature"""
    avg_d = np.mean(list(degrees.values()))
    avg_b = np.mean(list(betweenness.values()))
    avg_c = np.mean(list(clustering.values()))
    
    bridges = [n for n in G.nodes() 
               if degrees[n] > avg_d 
               and betweenness[n] > avg_b 
               and clustering[n] < avg_c]
    
    return bridges


def main():
    print("=" * 70)
    print("BRIDGE SIGNATURE VERIFICATION - C. ELEGANS CONNECTOME")
    print("=" * 70)
    
    # Load data
    G = load_connectome('NeuronConnect.xls')
    print(f"\nConnectome: {G.number_of_nodes()} neurons, {G.number_of_edges()} connections")
    
    # Classify
    node_types = classify_neurons(G)
    counts = {'E': 0, 'M': 0, 'I': 0}
    for t in node_types.values():
        counts[t] += 1
    
    print(f"\nDistribution:")
    print(f"  Excitatory: {counts['E']} ({counts['E']/G.number_of_nodes()*100:.1f}%)")
    print(f"  Modulatory: {counts['M']} ({counts['M']/G.number_of_nodes()*100:.1f}%)")
    print(f"  Inhibitory: {counts['I']} ({counts['I']/G.number_of_nodes()*100:.1f}%)")
    
    # Compute metrics
    degrees = dict(G.degree())
    betweenness = nx.betweenness_centrality(G)
    clustering = nx.clustering(G)
    
    # Find bridges
    bridges = find_bridges(G, degrees, betweenness, clustering)
    print(f"\nBridge nodes: {len(bridges)} ({len(bridges)/G.number_of_nodes()*100:.1f}%)")
    
    # Over-representation
    mod_nodes = [n for n in G.nodes() if node_types[n] == 'M']
    other_nodes = [n for n in G.nodes() if node_types[n] != 'M']
    
    mod_bridges = len([n for n in bridges if node_types[n] == 'M'])
    other_bridges = len(bridges) - mod_bridges
    
    print(f"\n--- OVER-REPRESENTATION ---")
    print(f"Modulatory in graph: {len(mod_nodes)} ({len(mod_nodes)/G.number_of_nodes()*100:.1f}%)")
    print(f"Modulatory in bridges: {mod_bridges} ({mod_bridges/len(bridges)*100:.1f}%)")
    print(f"Over-representation: {(mod_bridges/len(bridges))/(len(mod_nodes)/G.number_of_nodes()):.2f}x")
    
    # Chi-square test
    contingency = [[mod_bridges, len(mod_nodes) - mod_bridges],
                   [other_bridges, len(other_nodes) - other_bridges]]
    chi2, p_chi, _, _ = stats.chi2_contingency(contingency)
    
    print(f"\n--- STATISTICAL TEST ---")
    print(f"Chi-square: χ² = {chi2:.3f}, p = {p_chi:.6f}")
    print(f"Significant (p<0.05)? {'YES ✓' if p_chi < 0.05 else 'NO'}")
    
    # Metrics comparison
    print(f"\n--- METRICS BY TYPE ---")
    for t, name in [('E', 'Excitatory'), ('M', 'Modulatory'), ('I', 'Inhibitory')]:
        nodes = [n for n in G.nodes() if node_types[n] == t]
        if nodes:
            avg_deg = np.mean([degrees[n] for n in nodes])
            avg_cl = np.mean([clustering[n] for n in nodes])
            print(f"{name}: degree={avg_deg:.2f}, clustering={avg_cl:.4f}")


if __name__ == "__main__":
    main()
