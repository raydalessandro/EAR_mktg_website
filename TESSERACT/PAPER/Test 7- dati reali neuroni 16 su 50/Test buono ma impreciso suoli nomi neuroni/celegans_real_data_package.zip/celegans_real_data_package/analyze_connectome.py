"""
ANALISI CONNETTOMA C. ELEGANS - DATI REALI
==========================================

Questo script analizza i dati reali del connettoma C. elegans
e verifica la predizione: i neuroni modulatori hanno firma ponte.

Requisiti: pip install pandas networkx numpy scipy xlrd openpyxl
"""

import pandas as pd
import networkx as nx
import numpy as np
from scipy import stats
from collections import defaultdict

def load_connectome(filepath):
    """Carica il connettoma da file Excel"""
    df = pd.read_excel(filepath)
    df_neurons = df[df['Type'] != 'NMJ'].copy()
    
    G = nx.Graph()
    for _, row in df_neurons.iterrows():
        n1, n2 = row['Neuron 1'], row['Neuron 2']
        weight = row['Nbr']
        if G.has_edge(n1, n2):
            G[n1][n2]['weight'] += weight
        else:
            G.add_edge(n1, n2, weight=weight)
    
    return G

def classify_neurons(G, modulatory_set):
    """Classifica neuroni come modulatori o altri"""
    node_types = {}
    for node in G.nodes():
        node_types[node] = 'M' if node in modulatory_set else 'E'
    return node_types

def compute_metrics(G):
    """Calcola grado, betweenness, clustering per ogni nodo"""
    return {
        'degree': dict(G.degree()),
        'betweenness': nx.betweenness_centrality(G),
        'clustering': nx.clustering(G)
    }

def find_bridges(G, metrics):
    """Trova nodi con firma ponte"""
    avg_d = np.mean(list(metrics['degree'].values()))
    avg_b = np.mean(list(metrics['betweenness'].values()))
    avg_c = np.mean(list(metrics['clustering'].values()))
    
    bridges = []
    for node in G.nodes():
        if (metrics['degree'][node] > avg_d and 
            metrics['betweenness'][node] > avg_b and 
            metrics['clustering'][node] < avg_c):
            bridges.append(node)
    
    return bridges, {'avg_degree': avg_d, 'avg_betweenness': avg_b, 'avg_clustering': avg_c}

def statistical_tests(G, metrics, node_types, bridges):
    """Esegue test statistici"""
    mod_nodes = [n for n in G.nodes() if node_types.get(n) == 'M']
    other_nodes = [n for n in G.nodes() if node_types.get(n) != 'M']
    
    results = {}
    
    # T-tests
    for metric_name in ['degree', 'betweenness', 'clustering']:
        mod_values = [metrics[metric_name][n] for n in mod_nodes]
        other_values = [metrics[metric_name][n] for n in other_nodes]
        t, p = stats.ttest_ind(mod_values, other_values)
        results[f'{metric_name}_ttest'] = {'t': t, 'p': p, 
                                            'mod_mean': np.mean(mod_values),
                                            'other_mean': np.mean(other_values)}
    
    # Chi-square for over-representation
    mod_in_bridges = len([n for n in bridges if node_types.get(n) == 'M'])
    mod_not_bridges = len([n for n in G.nodes() if n not in bridges and node_types.get(n) == 'M'])
    other_in_bridges = len([n for n in bridges if node_types.get(n) != 'M'])
    other_not_bridges = len([n for n in G.nodes() if n not in bridges and node_types.get(n) != 'M'])
    
    contingency = [[mod_in_bridges, mod_not_bridges], 
                   [other_in_bridges, other_not_bridges]]
    chi2, p_chi, dof, expected = stats.chi2_contingency(contingency)
    
    results['chi_square'] = {'chi2': chi2, 'p': p_chi, 
                             'mod_in_bridges': mod_in_bridges,
                             'total_mod': mod_in_bridges + mod_not_bridges,
                             'total_bridges': mod_in_bridges + other_in_bridges}
    
    return results

# Lista neuroni modulatori noti
MODULATORY_NEURONS = {
    # Dopaminergici
    'ADEL', 'ADER', 'CEPDL', 'CEPDR', 'CEPVL', 'CEPVR', 'PDEL', 'PDER',
    # Serotoninergici
    'ADFL', 'ADFR', 'NSML', 'NSMR', 'HSNL', 'HSNR',
    # Octopaminergici
    'RIC',
    # Tiramminergici
    'TBHL', 'TBHR', 'RIM', 'RIML', 'RIMR',
    # Altri modulatori
    'AIM', 'AIML', 'AIMR',
}

if __name__ == "__main__":
    print("=" * 70)
    print("ANALISI CONNETTOMA C. ELEGANS")
    print("=" * 70)
    
    # Carica dati
    G = load_connectome('NeuronConnect.xls')
    print(f"\nGrafo: {G.number_of_nodes()} neuroni, {G.number_of_edges()} connessioni")
    
    # Classifica neuroni
    node_types = classify_neurons(G, MODULATORY_NEURONS)
    n_mod = sum(1 for t in node_types.values() if t == 'M')
    print(f"Modulatori identificati: {n_mod}")
    
    # Calcola metriche
    metrics = compute_metrics(G)
    
    # Trova ponti
    bridges, avgs = find_bridges(G, metrics)
    print(f"Nodi ponte: {len(bridges)} ({len(bridges)/G.number_of_nodes()*100:.1f}%)")
    
    # Test statistici
    results = statistical_tests(G, metrics, node_types, bridges)
    
    # Report
    print("\n" + "=" * 70)
    print("RISULTATI")
    print("=" * 70)
    
    print("\nMetriche per tipo:")
    print(f"  Grado - Modulatori: {results['degree_ttest']['mod_mean']:.2f}, Altri: {results['degree_ttest']['other_mean']:.2f}")
    print(f"  Clustering - Modulatori: {results['clustering_ttest']['mod_mean']:.4f}, Altri: {results['clustering_ttest']['other_mean']:.4f}")
    
    print(f"\nSovra-rappresentazione:")
    chi = results['chi_square']
    print(f"  Modulatori nei ponti: {chi['mod_in_bridges']}/{chi['total_bridges']}")
    print(f"  Chi-quadro: p = {chi['p']:.6f}")
    print(f"  Significativo: {'SÌ' if chi['p'] < 0.05 else 'NO'}")
