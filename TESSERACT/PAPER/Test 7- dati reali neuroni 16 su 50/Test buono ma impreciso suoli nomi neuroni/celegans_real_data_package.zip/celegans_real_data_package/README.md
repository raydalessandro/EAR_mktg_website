# C. elegans Connectome Analysis

## Files
- `NeuronConnect.xls` - Raw connectome data (Varshney et al.)
- `analyze_connectome.py` - Main analysis script
- `C_ELEGANS_RESULTS.md` - Results summary

## Quick Start
```bash
pip install pandas networkx numpy scipy xlrd openpyxl
python analyze_connectome.py
```

## Key Result
Modulatory neurons are 2.73x over-represented among bridge nodes (p = 0.0009)
