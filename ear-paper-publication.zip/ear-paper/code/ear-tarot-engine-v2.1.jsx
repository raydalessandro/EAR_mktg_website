import React, { useState, useCallback, useMemo } from 'react';

// ═══════════════════════════════════════════════════════════════════════════
// EAR TAROT COMPUTATION ENGINE v2.1 - COMPLETE
// 78 Carte: 22 Arcani Maggiori + 56 Arcani Minori
// Framework EAR v3.0 - Ontologia Ermetica Computazionale
// Developed by Ray @ EAR LAB - Digital Solutions & AI Research
// ═══════════════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════════════
// SISTEMA DI OPPOSIZIONI ONTOLOGICHE
// ══════════════════════════════════════════════════════════════════════════

const OPPOSITIONS = {
  polar: [
    [15, 17], [18, 19], [16, 11], [13, 3], [12, 7], [9, 6], [15, 6]
  ],
  dynamic: [
    [1, 2], [4, 3], [8, 10], [14, 16]
  ],
  resonance: [
    [1, 17], [2, 18], [17, 19], [3, 6], [4, 8], [10, 21], [20, 21], [0, 21], [5, 11], [7, 19]
  ]
};

// ══════════════════════════════════════════════════════════════════════════
// 22 ARCANI MAGGIORI - Mappatura EAR completa
// ══════════════════════════════════════════════════════════════════════════

const ARCANI_MAGGIORI = {
  0: {
    name: 'Il Matto', type: 'soglia', earSymbol: '○→●',
    ear: { delta: 0.50, relation: 0.50, process: 0.99 },
    pole: 'neutral', element: 'aether', 
    keywords: ['potenziale', 'salto', 'follia sacra'],
    waite: 'Folly, mania, extravagance, intoxication, delirium'
  },
  1: {
    name: 'Il Mago', type: 'nodo', nodo: '∇₀', earSymbol: '∇₀',
    ear: { delta: 0.90, relation: 0.50, process: 0.90 },
    pole: '+', element: 'air',
    keywords: ['volontà', 'manifestazione', 'potere'],
    waite: 'Skill, diplomacy, subtlety, self-confidence, will'
  },
  2: {
    name: 'La Papessa', type: 'nodo', nodo: '◎', earSymbol: '◎',
    ear: { delta: 0.50, relation: 0.85, process: 0.70 },
    pole: '-', element: 'water',
    keywords: ['intuizione', 'mistero', 'ricettività'],
    waite: 'Secrets, mystery, the future unrevealed, silence'
  },
  3: {
    name: 'L\'Imperatrice', type: 'archetipo', earSymbol: '♀',
    ear: { delta: 0.45, relation: 0.95, process: 0.80 },
    pole: '+', element: 'earth',
    keywords: ['fertilità', 'abbondanza', 'creazione'],
    waite: 'Fruitfulness, action, initiative, length of days'
  },
  4: {
    name: 'L\'Imperatore', type: 'archetipo', earSymbol: '⟨⦿⟩',
    ear: { delta: 0.95, relation: 0.60, process: 0.55 },
    pole: '+', element: 'fire',
    keywords: ['autorità', 'struttura', 'ordine'],
    waite: 'Stability, power, protection, realization'
  },
  5: {
    name: 'Il Papa', type: 'archetipo', earSymbol: '⟡⫯⟡',
    ear: { delta: 0.60, relation: 0.85, process: 0.60 },
    pole: '+', element: 'earth',
    keywords: ['tradizione', 'insegnamento', 'ponte'],
    waite: 'Marriage, alliance, mercy, goodness, inspiration'
  },
  6: {
    name: 'Gli Amanti', type: 'archetipo', earSymbol: '≈⟷≈',
    ear: { delta: 0.45, relation: 0.98, process: 0.65 },
    pole: '+', element: 'air',
    keywords: ['scelta', 'unione', 'armonia'],
    waite: 'Attraction, love, beauty, trials overcome'
  },
  7: {
    name: 'Il Carro', type: 'archetipo', earSymbol: '🔥⟐🔥',
    ear: { delta: 0.75, relation: 0.55, process: 0.90 },
    pole: '+', element: 'water',
    keywords: ['trionfo', 'movimento', 'conquista'],
    waite: 'Succour, providence, war, triumph, vengeance'
  },
  8: {
    name: 'La Giustizia', type: 'nodo', nodo: '⦿', earSymbol: '⦿',
    ear: { delta: 0.95, relation: 0.65, process: 0.45 },
    pole: 'neutral', element: 'air',
    keywords: ['equilibrio', 'verità', 'karma'],
    waite: 'Equity, rightness, probity, executive'
  },
  9: {
    name: 'L\'Eremita', type: 'archetipo', earSymbol: '◉◎◉',
    ear: { delta: 0.85, relation: 0.35, process: 0.70 },
    pole: '-', element: 'earth',
    keywords: ['introspezione', 'solitudine', 'guida'],
    waite: 'Prudence, circumspection, treason, corruption'
  },
  10: {
    name: 'La Ruota', type: 'nodo', nodo: '⟐', earSymbol: '⟐',
    ear: { delta: 0.50, relation: 0.60, process: 0.98 },
    pole: 'neutral', element: 'fire',
    keywords: ['destino', 'ciclo', 'cambiamento'],
    waite: 'Destiny, fortune, success, elevation, luck'
  },
  11: {
    name: 'La Forza', type: 'nodo', nodo: '⟡', earSymbol: '⟡',
    ear: { delta: 0.60, relation: 0.80, process: 0.75 },
    pole: '+', element: 'fire',
    keywords: ['forza', 'pazienza', 'controllo'],
    waite: 'Power, energy, action, courage, magnanimity'
  },
  12: {
    name: 'L\'Appeso', type: 'soglia', earSymbol: '●↔○',
    ear: { delta: 0.30, relation: 0.80, process: 0.40 },
    pole: '-', element: 'water',
    keywords: ['sospensione', 'sacrificio', 'resa'],
    waite: 'Wisdom, circumspection, discernment, trials'
  },
  13: {
    name: 'La Morte', type: 'archetipo', earSymbol: '∅◯∅',
    ear: { delta: 0.90, relation: 0.25, process: 0.85 },
    pole: '-', element: 'water',
    keywords: ['trasformazione', 'fine', 'rinascita'],
    waite: 'End, mortality, destruction, transformation'
  },
  14: {
    name: 'La Temperanza', type: 'archetipo', earSymbol: '☯⚡☯',
    ear: { delta: 0.50, relation: 0.90, process: 0.75 },
    pole: 'neutral', element: 'water',
    keywords: ['equilibrio', 'pazienza', 'alchimia'],
    waite: 'Economy, moderation, frugality, management'
  },
  15: {
    name: 'Il Diavolo', type: 'nodo', nodo: '⟷', earSymbol: '⟷',
    ear: { delta: 0.85, relation: 0.40, process: 0.35 },
    pole: '-', element: 'earth',
    keywords: ['ombra', 'legame', 'materia'],
    waite: 'Ravage, violence, force, fatality, bondage'
  },
  16: {
    name: 'La Torre', type: 'archetipo', earSymbol: '⟨🔑|🔑⟩',
    ear: { delta: 0.98, relation: 0.20, process: 0.90 },
    pole: '-', element: 'fire',
    keywords: ['rottura', 'rivelazione', 'crollo'],
    waite: 'Misery, distress, adversity, calamity, ruin'
  },
  17: {
    name: 'La Stella', type: 'archetipo', earSymbol: '◎≋◎',
    ear: { delta: 0.70, relation: 0.90, process: 0.85 },
    pole: '+', element: 'air',
    keywords: ['speranza', 'ispirazione', 'guida'],
    waite: 'Hope, bright prospects, loss, abandonment'
  },
  18: {
    name: 'La Luna', type: 'nodo', nodo: '∅', earSymbol: '∅',
    ear: { delta: 0.35, relation: 0.70, process: 0.75 },
    pole: '-', element: 'water',
    keywords: ['illusione', 'inconscio', 'paura'],
    waite: 'Hidden enemies, danger, darkness, terror'
  },
  19: {
    name: 'Il Sole', type: 'archetipo', earSymbol: '☉',
    ear: { delta: 0.70, relation: 0.85, process: 0.90 },
    pole: '+', element: 'fire',
    keywords: ['gioia', 'successo', 'chiarezza'],
    waite: 'Material happiness, fortunate marriage, contentment'
  },
  20: {
    name: 'Il Giudizio', type: 'archetipo', earSymbol: '👁∅👁',
    ear: { delta: 0.75, relation: 0.80, process: 0.85 },
    pole: '+', element: 'fire',
    keywords: ['risveglio', 'chiamata', 'resurrezione'],
    waite: 'Change of position, renewal, outcome'
  },
  21: {
    name: 'Il Mondo', type: 'soglia', earSymbol: '◉∞◉',
    ear: { delta: 0.90, relation: 0.90, process: 0.90 },
    pole: 'neutral', element: 'aether',
    keywords: ['completamento', 'integrazione', 'totalità'],
    waite: 'Assured success, recompense, voyage, change'
  }
};

// ══════════════════════════════════════════════════════════════════════════
// SEMI - Mappatura Elementale EAR
// ══════════════════════════════════════════════════════════════════════════

const SUITS = {
  bastoni: {
    name: 'Bastoni', symbol: '🜂', element: 'fire', dimension: 'D4',
    pole: '+',
    ear_mod: { delta: 0.10, relation: -0.05, process: 0.15 },
    keywords: ['volontà', 'azione', 'creatività', 'passione'],
    color: '#e74c3c'
  },
  coppe: {
    name: 'Coppe', symbol: '🜄', element: 'water', dimension: 'D2',
    pole: '-',
    ear_mod: { delta: -0.10, relation: 0.20, process: 0.05 },
    keywords: ['emozioni', 'relazioni', 'intuizione', 'amore'],
    color: '#3498db'
  },
  spade: {
    name: 'Spade', symbol: '🜁', element: 'air', dimension: 'D3',
    pole: 'neutral',
    ear_mod: { delta: 0.20, relation: -0.10, process: 0.00 },
    keywords: ['mente', 'conflitto', 'verità', 'decisione'],
    color: '#9b59b6'
  },
  denari: {
    name: 'Denari', symbol: '🜃', element: 'earth', dimension: 'D1',
    pole: '+',
    ear_mod: { delta: 0.05, relation: 0.10, process: -0.10 },
    keywords: ['materia', 'stabilità', 'risorse', 'corpo'],
    color: '#27ae60'
  }
};

// ══════════════════════════════════════════════════════════════════════════
// NUMERI - Progressione EAR
// ══════════════════════════════════════════════════════════════════════════

const NUMBERS = {
  1: { 
    name: 'Asso', 
    ear: { delta: 0.95, relation: 0.30, process: 0.50 },
    meaning: 'origine', keywords: ['inizio', 'potenziale', 'seme']
  },
  2: { 
    name: 'Due', 
    ear: { delta: 0.60, relation: 0.85, process: 0.35 },
    meaning: 'dualità', keywords: ['scelta', 'equilibrio', 'partnership']
  },
  3: { 
    name: 'Tre', 
    ear: { delta: 0.50, relation: 0.70, process: 0.75 },
    meaning: 'espansione', keywords: ['crescita', 'sintesi', 'creatività']
  },
  4: { 
    name: 'Quattro', 
    ear: { delta: 0.85, relation: 0.55, process: 0.40 },
    meaning: 'stabilità', keywords: ['fondazione', 'struttura', 'pausa']
  },
  5: { 
    name: 'Cinque', 
    ear: { delta: 0.65, relation: 0.40, process: 0.70 },
    meaning: 'conflitto', keywords: ['sfida', 'cambiamento', 'instabilità']
  },
  6: { 
    name: 'Sei', 
    ear: { delta: 0.50, relation: 0.90, process: 0.60 },
    meaning: 'equilibrio', keywords: ['armonia', 'reciprocità', 'scambio']
  },
  7: { 
    name: 'Sette', 
    ear: { delta: 0.75, relation: 0.45, process: 0.80 },
    meaning: 'visione', keywords: ['riflessione', 'sfida', 'introspezione']
  },
  8: { 
    name: 'Otto', 
    ear: { delta: 0.60, relation: 0.60, process: 0.85 },
    meaning: 'movimento', keywords: ['azione', 'velocità', 'potere']
  },
  9: { 
    name: 'Nove', 
    ear: { delta: 0.70, relation: 0.70, process: 0.75 },
    meaning: 'compimento', keywords: ['realizzazione', 'saggezza', 'solitudine']
  },
  10: { 
    name: 'Dieci', 
    ear: { delta: 0.80, relation: 0.80, process: 0.50 },
    meaning: 'culminazione', keywords: ['completamento', 'eccesso', 'eredità']
  }
};

// ══════════════════════════════════════════════════════════════════════════
// FIGURE DI CORTE
// ══════════════════════════════════════════════════════════════════════════

const COURT = {
  fante: {
    name: 'Fante', node: '△', weight: 1.3,
    ear: { delta: 0.45, relation: 0.60, process: 0.70 },
    keywords: ['messaggero', 'inizio', 'apprendimento']
  },
  cavallo: {
    name: 'Cavallo', node: '○', weight: 1.4,
    ear: { delta: 0.65, relation: 0.55, process: 0.85 },
    keywords: ['azione', 'movimento', 'passione']
  },
  regina: {
    name: 'Regina', node: '◇', weight: 1.5,
    ear: { delta: 0.55, relation: 0.85, process: 0.65 },
    keywords: ['ricettività', 'maturità', 'intuizione']
  },
  re: {
    name: 'Re', node: '□', weight: 1.6,
    ear: { delta: 0.90, relation: 0.60, process: 0.55 },
    keywords: ['autorità', 'padronanza', 'comando']
  }
};

// ══════════════════════════════════════════════════════════════════════════
// POSIZIONI STESA
// ══════════════════════════════════════════════════════════════════════════

const POSITIONS = {
  centro: { weight: 1.0, role: 'Nucleo', temporal: 'presente', symbol: '⊙' },
  alto: { weight: 0.8, role: 'Aspirazione', temporal: 'ideale', symbol: '△' },
  basso: { weight: 0.8, role: 'Fondamenta', temporal: 'radice', symbol: '▽' },
  sinistra: { weight: 0.7, role: 'Passato', temporal: 'origine', symbol: '◁' },
  destra: { weight: 0.9, role: 'Futuro', temporal: 'destino', symbol: '▷' },
  sopra_sinistra: { weight: 0.6, role: 'Influenza Passata', temporal: 'eco', symbol: '◤' },
  sopra_destra: { weight: 0.7, role: 'Possibilità', temporal: 'potenziale', symbol: '◥' }
};

const SPREADS = {
  tre_carte: {
    name: 'Tre Carte',
    positions: ['sinistra', 'centro', 'destra'],
    layout: [['sinistra', 'centro', 'destra']],
    interactions: [
      { from: 'sinistra', to: 'centro', weight: 1.0, type: 'flusso' },
      { from: 'centro', to: 'destra', weight: 1.0, type: 'flusso' },
      { from: 'sinistra', to: 'destra', weight: 0.5, type: 'arco' }
    ]
  },
  croce_semplice: {
    name: 'Croce Semplice',
    positions: ['centro', 'alto', 'basso', 'sinistra', 'destra'],
    layout: [
      [null, 'alto', null],
      ['sinistra', 'centro', 'destra'],
      [null, 'basso', null]
    ],
    interactions: [
      { from: 'centro', to: 'alto', weight: 1.0, type: 'aspirazione' },
      { from: 'centro', to: 'basso', weight: 1.0, type: 'fondamento' },
      { from: 'centro', to: 'sinistra', weight: 1.0, type: 'origine' },
      { from: 'centro', to: 'destra', weight: 1.0, type: 'direzione' },
      { from: 'alto', to: 'basso', weight: 0.5, type: 'asse_verticale' },
      { from: 'sinistra', to: 'destra', weight: 0.5, type: 'asse_temporale' }
    ]
  },
  esagramma: {
    name: 'Esagramma',
    positions: ['centro', 'alto', 'basso', 'sinistra', 'destra', 'sopra_sinistra', 'sopra_destra'],
    layout: [
      ['sopra_sinistra', 'alto', 'sopra_destra'],
      ['sinistra', 'centro', 'destra'],
      [null, 'basso', null]
    ],
    interactions: [
      { from: 'centro', to: 'alto', weight: 1.0, type: 'aspirazione' },
      { from: 'centro', to: 'basso', weight: 1.0, type: 'fondamento' },
      { from: 'centro', to: 'sinistra', weight: 1.0, type: 'origine' },
      { from: 'centro', to: 'destra', weight: 1.0, type: 'direzione' },
      { from: 'sopra_sinistra', to: 'alto', weight: 0.6, type: 'influenza' },
      { from: 'sopra_destra', to: 'alto', weight: 0.6, type: 'influenza' },
      { from: 'alto', to: 'basso', weight: 0.5, type: 'asse' },
      { from: 'sinistra', to: 'destra', weight: 0.5, type: 'tempo' }
    ]
  }
};

// ══════════════════════════════════════════════════════════════════════════
// FUNZIONI DI PARSING E CALCOLO
// ══════════════════════════════════════════════════════════════════════════

function parseCardInput(input) {
  const normalized = input.toLowerCase().trim();
  if (!normalized) return null;

  // 1. Check Arcani Maggiori
  for (const [num, data] of Object.entries(ARCANI_MAGGIORI)) {
    const searchTerms = [
      data.name.toLowerCase(),
      `arcano ${num}`,
      num.toString()
    ];
    
    // Add common variations
    if (data.name.includes('Matto')) searchTerms.push('matto', 'fool');
    if (data.name.includes('Mago')) searchTerms.push('mago', 'magician');
    if (data.name.includes('Papessa')) searchTerms.push('papessa', 'high priestess');
    if (data.name.includes('Imperatrice')) searchTerms.push('imperatrice', 'empress');
    if (data.name.includes('Imperatore')) searchTerms.push('imperatore', 'emperor');
    if (data.name.includes('Papa')) searchTerms.push('papa', 'hierophant');
    if (data.name.includes('Amanti')) searchTerms.push('amanti', 'lovers');
    if (data.name.includes('Carro')) searchTerms.push('carro', 'chariot');
    if (data.name.includes('Giustizia')) searchTerms.push('giustizia', 'justice');
    if (data.name.includes('Eremita')) searchTerms.push('eremita', 'hermit');
    if (data.name.includes('Ruota')) searchTerms.push('ruota', 'wheel');
    if (data.name.includes('Forza')) searchTerms.push('forza', 'strength');
    if (data.name.includes('Appeso')) searchTerms.push('appeso', 'hanged');
    if (data.name.includes('Morte')) searchTerms.push('morte', 'death');
    if (data.name.includes('Temperanza')) searchTerms.push('temperanza', 'temperance');
    if (data.name.includes('Diavolo')) searchTerms.push('diavolo', 'devil');
    if (data.name.includes('Torre')) searchTerms.push('torre', 'tower');
    if (data.name.includes('Stella')) searchTerms.push('stella', 'star');
    if (data.name.includes('Luna')) searchTerms.push('luna', 'moon');
    if (data.name.includes('Sole')) searchTerms.push('sole', 'sun');
    if (data.name.includes('Giudizio')) searchTerms.push('giudizio', 'judgement');
    if (data.name.includes('Mondo')) searchTerms.push('mondo', 'world');

    for (const term of searchTerms) {
      if (normalized.includes(term) || normalized === num) {
        return {
          type: 'major',
          number: parseInt(num),
          name: data.name,
          ear: { ...data.ear },
          earSymbol: data.earSymbol,
          pole: data.pole,
          element: data.element,
          keywords: data.keywords,
          waite: data.waite,
          cardType: data.type,
          nodo: data.nodo,
          weight: 2.0
        };
      }
    }
  }

  // 2. Check Figure di Corte
  for (const [suitKey, suitData] of Object.entries(SUITS)) {
    const suitMatch = normalized.includes(suitKey) || 
                      normalized.includes(suitKey.slice(0, -1)) ||
                      normalized.includes(suitData.name.toLowerCase());
    
    if (suitMatch) {
      for (const [courtKey, courtData] of Object.entries(COURT)) {
        if (normalized.includes(courtKey) || 
            (courtKey === 'cavallo' && normalized.includes('cavaliere'))) {
          const ear = {
            delta: Math.max(0, Math.min(1, courtData.ear.delta + suitData.ear_mod.delta)),
            relation: Math.max(0, Math.min(1, courtData.ear.relation + suitData.ear_mod.relation)),
            process: Math.max(0, Math.min(1, courtData.ear.process + suitData.ear_mod.process))
          };
          
          return {
            type: 'court',
            suit: suitKey,
            suitData: suitData,
            court: courtKey,
            courtData: courtData,
            name: `${courtData.name} di ${suitData.name}`,
            ear: ear,
            pole: suitData.pole,
            element: suitData.element,
            keywords: [...courtData.keywords, ...suitData.keywords.slice(0, 2)],
            weight: courtData.weight
          };
        }
      }

      // 3. Check Numeri
      const numMatch = normalized.match(/(\d+)/);
      if (numMatch) {
        const num = parseInt(numMatch[1]);
        if (num >= 1 && num <= 10 && NUMBERS[num]) {
          const numData = NUMBERS[num];
          const ear = {
            delta: Math.max(0, Math.min(1, numData.ear.delta + suitData.ear_mod.delta)),
            relation: Math.max(0, Math.min(1, numData.ear.relation + suitData.ear_mod.relation)),
            process: Math.max(0, Math.min(1, numData.ear.process + suitData.ear_mod.process))
          };
          
          return {
            type: 'numeral',
            suit: suitKey,
            suitData: suitData,
            number: num,
            numData: numData,
            name: `${num} di ${suitData.name}`,
            ear: ear,
            pole: suitData.pole,
            element: suitData.element,
            meaning: numData.meaning,
            keywords: [...numData.keywords, ...suitData.keywords.slice(0, 2)],
            weight: 1.0
          };
        }
      }
    }
  }

  return null;
}

function applyReversal(card, isReversed) {
  if (!isReversed) return card;
  
  // Inversione ontologica: non solo riduzione ma inversione della polarità
  const invertedEar = {
    delta: card.ear.delta * 0.4,      // Blocco della distinzione
    relation: card.ear.relation * 0.3, // Blocco della relazione
    process: card.ear.process * 0.5    // Rallentamento del processo
  };
  
  // Se i valori sono alti, li invertiamo verso la tensione
  if (card.ear.delta > 0.7) invertedEar.delta = 0.9 - card.ear.delta * 0.5;
  if (card.ear.relation > 0.7) invertedEar.relation = -0.2 + card.ear.relation * 0.3;
  
  return {
    ...card,
    reversed: true,
    ear: invertedEar,
    weight: card.weight * 0.5,
    pole: card.pole === '+' ? '-' : card.pole === '-' ? '+' : 'blocked',
    keywords: card.keywords.map(k => `[R] ${k}`)
  };
}

function calculateInteraction(card1, card2) {
  const ear1 = card1.ear;
  const ear2 = card2.ear;
  
  // Correlazione geometrica
  const dot = ear1.delta * ear2.delta + ear1.relation * ear2.relation + ear1.process * ear2.process;
  const mag1 = Math.sqrt(ear1.delta**2 + ear1.relation**2 + ear1.process**2);
  const mag2 = Math.sqrt(ear2.delta**2 + ear2.relation**2 + ear2.process**2);
  const geometricCorrelation = mag1 > 0 && mag2 > 0 ? dot / (mag1 * mag2) : 0;
  
  // Check opposizioni (solo per Arcani Maggiori)
  let isPolarOpposite = false;
  let isDynamicTension = false;
  let isDeepResonance = false;
  
  if (card1.type === 'major' && card2.type === 'major') {
    isPolarOpposite = OPPOSITIONS.polar.some(
      ([a, b]) => (a === card1.number && b === card2.number) || (a === card2.number && b === card1.number)
    );
    isDynamicTension = OPPOSITIONS.dynamic.some(
      ([a, b]) => (a === card1.number && b === card2.number) || (a === card2.number && b === card1.number)
    );
    isDeepResonance = OPPOSITIONS.resonance.some(
      ([a, b]) => (a === card1.number && b === card2.number) || (a === card2.number && b === card1.number)
    );
  }
  
  // Tensioni
  let polarityTension = 0;
  if (card1.pole === '+' && card2.pole === '-') polarityTension = 0.2;
  if (card1.pole === '-' && card2.pole === '+') polarityTension = 0.2;
  
  let elementTension = 0;
  const elementOpposites = { fire: 'water', water: 'fire', air: 'earth', earth: 'air' };
  if (elementOpposites[card1.element] === card2.element) elementTension = 0.15;
  
  // Bonus stesso elemento/seme
  let sameElementBonus = 0;
  if (card1.element === card2.element) sameElementBonus = 0.1;
  if (card1.suit && card2.suit && card1.suit === card2.suit) sameElementBonus = 0.15;
  
  // Calcolo finale
  let finalScore;
  let interactionType;
  
  if (isPolarOpposite) {
    finalScore = -0.6 - polarityTension - elementTension;
    interactionType = 'OPPOSIZIONE POLARE';
  } else if (isDynamicTension) {
    finalScore = 0.1 - polarityTension;
    interactionType = 'TENSIONE DINAMICA';
  } else if (isDeepResonance) {
    finalScore = geometricCorrelation + 0.2 + sameElementBonus;
    interactionType = 'RISONANZA PROFONDA';
  } else {
    finalScore = geometricCorrelation - polarityTension - elementTension + sameElementBonus;
    
    // Penalità per carte rovesciate
    if (card1.reversed || card2.reversed) finalScore -= 0.15;
    if (card1.reversed && card2.reversed) finalScore -= 0.1;
    
    if (finalScore > 0.85) interactionType = 'Forte Risonanza';
    else if (finalScore > 0.6) interactionType = 'Risonanza';
    else if (finalScore > 0.3) interactionType = 'Affinità';
    else if (finalScore > 0) interactionType = 'Neutralità';
    else if (finalScore > -0.3) interactionType = 'Tensione';
    else interactionType = 'Forte Tensione';
  }
  
  return {
    cards: [card1.name, card2.name],
    correlation: geometricCorrelation,
    finalScore: Math.max(-1, Math.min(1.5, finalScore)),
    type: interactionType,
    poles: [card1.pole, card2.pole],
    elements: [card1.element, card2.element],
    reversed: [card1.reversed || false, card2.reversed || false]
  };
}

function computeReading(cards, spread) {
  // Calcola pesi normalizzati
  const totalWeight = cards.reduce((sum, c) => sum + (c.weight || 1), 0);
  const weightedCards = cards.map(c => ({
    ...c,
    normalizedWeight: (c.weight || 1) / totalWeight
  }));
  
  // Vettore composito
  const composite = { delta: 0, relation: 0, process: 0 };
  for (const card of weightedCards) {
    composite.delta += card.normalizedWeight * card.ear.delta;
    composite.relation += card.normalizedWeight * card.ear.relation;
    composite.process += card.normalizedWeight * card.ear.process;
  }
  
  // Interazioni
  const interactions = [];
  for (const interaction of spread.interactions) {
    const c1 = weightedCards.find(c => c.position === interaction.from);
    const c2 = weightedCards.find(c => c.position === interaction.to);
    if (c1 && c2) {
      const result = calculateInteraction(c1, c2);
      interactions.push({
        ...result,
        from: interaction.from,
        to: interaction.to,
        semanticType: interaction.type,
        weight: interaction.weight
      });
    }
  }
  
  // Coerenza
  const positiveInteractions = interactions.filter(i => i.finalScore > 0);
  const negativeInteractions = interactions.filter(i => i.finalScore < 0);
  const coherenceSum = interactions.reduce((sum, i) => sum + i.finalScore * i.weight, 0);
  const maxCoherence = interactions.reduce((sum, i) => sum + i.weight, 0);
  const coherence = maxCoherence > 0 ? coherenceSum / maxCoherence : 0;
  
  // Attributo dominante
  const total = composite.delta + composite.relation + composite.process;
  const percentages = {
    delta: ((composite.delta / total) * 100).toFixed(1),
    relation: ((composite.relation / total) * 100).toFixed(1),
    process: ((composite.process / total) * 100).toFixed(1)
  };
  
  const dominant = composite.delta > composite.relation && composite.delta > composite.process 
    ? 'Δ Distinzione' 
    : composite.relation > composite.process 
      ? '⇄ Relazione' 
      : '⟳ Processo';
  
  // Dimensioni
  const dimensions = { D1: 0, D2: 0, D3: 0, D4: 0 };
  for (const card of weightedCards) {
    const dim = card.suitData?.dimension || 
                (card.type === 'major' && card.element === 'fire' ? 'D4' : 
                 card.element === 'water' ? 'D2' : 
                 card.element === 'air' ? 'D3' : 
                 card.element === 'earth' ? 'D1' : 'D4');
    dimensions[dim] = (dimensions[dim] || 0) + card.normalizedWeight;
  }
  
  // Elementi
  const elements = { fire: 0, water: 0, air: 0, earth: 0, aether: 0 };
  for (const card of weightedCards) {
    if (card.element) {
      elements[card.element] += card.normalizedWeight;
    }
  }
  
  return {
    cards: weightedCards,
    composite,
    percentages,
    dominant,
    dimensions,
    elements,
    interactions: interactions.sort((a, b) => Math.abs(b.finalScore) - Math.abs(a.finalScore)),
    coherence,
    positiveFlows: positiveInteractions,
    tensions: negativeInteractions,
    stats: {
      majorCount: weightedCards.filter(c => c.type === 'major').length,
      reversedCount: weightedCards.filter(c => c.reversed).length,
      totalCards: weightedCards.length
    }
  };
}

// ══════════════════════════════════════════════════════════════════════════
// COMPONENTE REACT
// ══════════════════════════════════════════════════════════════════════════

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=JetBrains+Mono:wght@400;500&display=swap');
  
  :root {
    --gold: #c4a35a;
    --gold-bright: #e8d5a3;
    --gold-dark: #8b7355;
    --obsidian: #0a0a0f;
    --midnight: #12121a;
    --twilight: #1a1a2e;
    --silver: #a8a8b3;
    --crimson: #8b2942;
    --emerald: #2a5f4a;
    --sapphire: #2a4a6b;
    --violet: #4a2a5f;
    --fire: #e74c3c;
    --water: #3498db;
    --air: #9b59b6;
    --earth: #27ae60;
  }
  
  * { box-sizing: border-box; margin: 0; padding: 0; }
  
  .ear-app {
    min-height: 100vh;
    background: 
      radial-gradient(ellipse at top, var(--twilight) 0%, transparent 50%),
      radial-gradient(ellipse at bottom right, rgba(196, 163, 90, 0.05) 0%, transparent 40%),
      var(--obsidian);
    color: var(--silver);
    font-family: 'Cormorant Garamond', serif;
    padding: 1.5rem;
  }
  
  .header {
    text-align: center;
    margin-bottom: 2rem;
  }
  
  .header::before {
    content: '⊕ ☽ ◎ ☉ ⊕';
    display: block;
    font-size: 0.75rem;
    letter-spacing: 1.5rem;
    color: var(--gold-dark);
    margin-bottom: 0.75rem;
  }
  
  .title {
    font-family: 'Cinzel', serif;
    font-size: clamp(1.5rem, 4vw, 2.5rem);
    font-weight: 700;
    color: var(--gold);
    text-transform: uppercase;
    letter-spacing: 0.25em;
    text-shadow: 0 0 30px rgba(196, 163, 90, 0.3);
  }
  
  .subtitle {
    font-style: italic;
    font-size: 1rem;
    color: var(--silver);
    margin-top: 0.25rem;
    letter-spacing: 0.1em;
  }
  
  .main-grid {
    display: grid;
    grid-template-columns: 1fr 1.2fr;
    gap: 1.5rem;
    max-width: 1400px;
    margin: 0 auto;
  }
  
  @media (max-width: 1000px) {
    .main-grid { grid-template-columns: 1fr; }
  }
  
  .panel {
    background: linear-gradient(135deg, var(--midnight) 0%, var(--twilight) 100%);
    border: 1px solid rgba(196, 163, 90, 0.2);
    border-radius: 4px;
    padding: 1.25rem;
    position: relative;
  }
  
  .panel::before {
    content: '';
    position: absolute;
    top: -1px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 1px;
    background: linear-gradient(90deg, transparent, var(--gold), transparent);
  }
  
  .panel-title {
    font-family: 'Cinzel', serif;
    font-size: 0.9rem;
    color: var(--gold);
    text-transform: uppercase;
    letter-spacing: 0.15em;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
  
  .panel-title::after {
    content: '';
    flex: 1;
    height: 1px;
    background: linear-gradient(90deg, rgba(196, 163, 90, 0.3), transparent);
  }
  
  .spread-selector {
    display: flex;
    gap: 0.4rem;
    flex-wrap: wrap;
    margin-bottom: 1rem;
  }
  
  .spread-btn {
    background: transparent;
    border: 1px solid var(--gold-dark);
    color: var(--silver);
    padding: 0.4rem 0.8rem;
    font-family: 'Cormorant Garamond', serif;
    font-size: 0.85rem;
    cursor: pointer;
    transition: all 0.3s ease;
    border-radius: 2px;
  }
  
  .spread-btn:hover, .spread-btn.active {
    background: rgba(196, 163, 90, 0.15);
    border-color: var(--gold);
    color: var(--gold);
  }
  
  .question-input {
    width: 100%;
    background: var(--obsidian);
    border: 1px solid rgba(196, 163, 90, 0.3);
    color: var(--silver);
    padding: 0.6rem;
    font-family: 'Cormorant Garamond', serif;
    font-size: 0.95rem;
    font-style: italic;
    border-radius: 2px;
    resize: none;
    min-height: 50px;
    margin-bottom: 1rem;
  }
  
  .question-input:focus {
    outline: none;
    border-color: var(--gold);
  }
  
  .card-inputs {
    display: flex;
    flex-direction: column;
    gap: 0.6rem;
  }
  
  .card-input-row {
    display: flex;
    gap: 0.4rem;
    align-items: center;
  }
  
  .position-label {
    min-width: 70px;
    font-family: 'Cinzel', serif;
    font-size: 0.65rem;
    color: var(--gold-dark);
    text-transform: uppercase;
  }
  
  .card-input {
    flex: 1;
    background: var(--obsidian);
    border: 1px solid rgba(196, 163, 90, 0.3);
    color: var(--silver);
    padding: 0.5rem 0.6rem;
    font-family: 'Cormorant Garamond', serif;
    font-size: 0.95rem;
    border-radius: 2px;
  }
  
  .card-input:focus {
    outline: none;
    border-color: var(--gold);
    box-shadow: 0 0 8px rgba(196, 163, 90, 0.2);
  }
  
  .card-input::placeholder {
    color: rgba(168, 168, 179, 0.4);
    font-style: italic;
  }
  
  .card-input.valid { border-color: var(--emerald); }
  .card-input.invalid { border-color: var(--crimson); }
  
  .reversal-toggle {
    cursor: pointer;
    user-select: none;
  }
  
  .reversal-icon {
    width: 28px;
    height: 28px;
    border: 1px solid var(--gold-dark);
    border-radius: 2px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.9rem;
    color: var(--silver);
    transition: all 0.3s ease;
  }
  
  .reversal-toggle input { display: none; }
  
  .reversal-toggle input:checked + .reversal-icon {
    background: var(--crimson);
    border-color: var(--crimson);
    color: white;
    transform: rotate(180deg);
  }
  
  .compute-btn {
    width: 100%;
    background: linear-gradient(135deg, var(--gold-dark) 0%, var(--gold) 100%);
    border: none;
    color: var(--obsidian);
    padding: 0.8rem;
    font-family: 'Cinzel', serif;
    font-size: 0.9rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.15em;
    cursor: pointer;
    border-radius: 2px;
    transition: all 0.3s ease;
    margin-top: 1rem;
  }
  
  .compute-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(196, 163, 90, 0.3);
  }
  
  .compute-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  
  .element-legend {
    display: flex;
    gap: 1rem;
    justify-content: center;
    padding: 0.5rem;
    font-size: 0.75rem;
    color: rgba(168, 168, 179, 0.6);
    margin-top: 0.5rem;
  }
  
  .element-legend span { display: flex; align-items: center; gap: 0.25rem; }
  .el-fire { color: var(--fire); }
  .el-water { color: var(--water); }
  .el-air { color: var(--air); }
  .el-earth { color: var(--earth); }
  
  /* Results */
  .results-panel { display: flex; flex-direction: column; gap: 1rem; }
  
  .no-results {
    text-align: center;
    padding: 3rem 1rem;
    color: rgba(168, 168, 179, 0.5);
    font-style: italic;
  }
  
  .stats-row {
    display: flex;
    gap: 1.5rem;
    justify-content: center;
    padding: 0.75rem;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 4px;
  }
  
  .stat-item { text-align: center; }
  
  .stat-value {
    font-family: 'JetBrains Mono', monospace;
    font-size: 1.3rem;
    color: var(--gold);
  }
  
  .stat-label {
    font-size: 0.65rem;
    text-transform: uppercase;
    color: rgba(168, 168, 179, 0.6);
    letter-spacing: 0.05em;
  }
  
  .ear-display {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 0.75rem;
  }
  
  .ear-component {
    text-align: center;
    padding: 0.75rem;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 4px;
  }
  
  .ear-symbol { font-size: 1.5rem; margin-bottom: 0.25rem; }
  .ear-delta { color: #e74c3c; }
  .ear-relation { color: #3498db; }
  .ear-process { color: #2ecc71; }
  
  .ear-value {
    font-family: 'JetBrains Mono', monospace;
    font-size: 1.2rem;
    color: var(--gold);
  }
  
  .ear-percent {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.8rem;
    color: var(--silver);
  }
  
  .ear-label {
    font-size: 0.7rem;
    text-transform: uppercase;
    color: rgba(168, 168, 179, 0.6);
    margin-top: 0.25rem;
  }
  
  .coherence-bar {
    background: rgba(0, 0, 0, 0.3);
    padding: 0.75rem;
    border-radius: 4px;
  }
  
  .coherence-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.4rem;
    font-size: 0.85rem;
  }
  
  .coherence-value {
    font-family: 'JetBrains Mono', monospace;
    color: var(--gold);
  }
  
  .meter {
    height: 6px;
    background: var(--twilight);
    border-radius: 3px;
    overflow: hidden;
  }
  
  .meter-fill {
    height: 100%;
    border-radius: 3px;
    transition: width 0.5s ease;
  }
  
  .meter-positive { background: linear-gradient(90deg, var(--emerald), #4ecdc4); }
  .meter-neutral { background: linear-gradient(90deg, var(--sapphire), #74b9ff); }
  .meter-negative { background: linear-gradient(90deg, var(--crimson), #e17055); }
  
  .dimensions-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 0.5rem;
  }
  
  .dim-block {
    text-align: center;
    padding: 0.5rem;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 4px;
  }
  
  .dim-name {
    font-family: 'Cinzel', serif;
    font-size: 0.65rem;
    color: var(--gold-dark);
  }
  
  .dim-value {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.95rem;
    color: var(--gold);
  }
  
  .interactions-list {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    max-height: 200px;
    overflow-y: auto;
  }
  
  .interaction-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0.75rem;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 4px;
    border-left: 3px solid;
    font-size: 0.85rem;
  }
  
  .interaction-item.positive { border-color: var(--emerald); }
  .interaction-item.negative { border-color: var(--crimson); }
  .interaction-item.neutral { border-color: var(--sapphire); }
  
  .interaction-score {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.8rem;
  }
  
  .interpretation-block {
    background: rgba(0, 0, 0, 0.3);
    padding: 1rem;
    border-radius: 4px;
    border: 1px solid rgba(196, 163, 90, 0.1);
  }
  
  .interpretation-title {
    font-family: 'Cinzel', serif;
    font-size: 0.8rem;
    color: var(--gold);
    margin-bottom: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
  }
  
  .interpretation-text {
    font-size: 0.95rem;
    line-height: 1.6;
  }
  
  .interpretation-text p { margin-bottom: 0.75rem; }
  .interpretation-text strong { color: var(--gold-bright); }
  .interpretation-text .tension { color: var(--crimson); }
  .interpretation-text .resonance { color: var(--emerald); }
  
  .card-visual-grid {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.4rem;
    margin: 1rem 0;
  }
  
  .card-row {
    display: flex;
    gap: 0.4rem;
  }
  
  .card-slot {
    width: 80px;
    height: 110px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: rgba(0, 0, 0, 0.4);
    border: 1px solid rgba(196, 163, 90, 0.2);
    border-radius: 4px;
    padding: 0.4rem;
    transition: all 0.3s ease;
  }
  
  .card-slot.empty { opacity: 0; pointer-events: none; }
  
  .card-slot.filled {
    border-color: var(--gold);
    background: linear-gradient(135deg, rgba(196, 163, 90, 0.1) 0%, transparent 100%);
  }
  
  .card-slot.reversed { background: linear-gradient(135deg, rgba(139, 41, 66, 0.2) 0%, transparent 100%); }
  
  .card-slot .card-symbol { font-size: 1.2rem; }
  
  .card-slot .card-name {
    font-size: 0.55rem;
    text-align: center;
    line-height: 1.2;
    margin-top: 0.25rem;
  }
  
  .card-slot .position-name {
    font-family: 'Cinzel', serif;
    font-size: 0.5rem;
    color: var(--gold-dark);
    text-transform: uppercase;
    margin-top: auto;
  }
`;

export default function EARTarotEngine() {
  const [selectedSpread, setSelectedSpread] = useState('croce_semplice');
  const [question, setQuestion] = useState('');
  const [cardInputs, setCardInputs] = useState({});
  const [reversals, setReversals] = useState({});
  const [results, setResults] = useState(null);
  const [parsedCards, setParsedCards] = useState({});

  const spread = SPREADS[selectedSpread];

  const handleCardChange = useCallback((position, value) => {
    setCardInputs(prev => ({ ...prev, [position]: value }));
    const parsed = parseCardInput(value);
    setParsedCards(prev => ({ ...prev, [position]: parsed }));
  }, []);

  const toggleReversal = useCallback((position) => {
    setReversals(prev => ({ ...prev, [position]: !prev[position] }));
  }, []);

  const handleCompute = useCallback(() => {
    const cards = [];

    for (const position of spread.positions) {
      const parsed = parsedCards[position];
      if (!parsed) continue;

      let card = { ...parsed, position, positionData: POSITIONS[position] };
      card.weight *= POSITIONS[position].weight;
      card = applyReversal(card, reversals[position]);
      cards.push(card);
    }

    if (cards.length < 2) {
      alert('Inserisci almeno 2 carte valide');
      return;
    }

    const reading = computeReading(cards, spread);
    setResults(reading);
  }, [cardInputs, reversals, spread, parsedCards]);

  const validCardCount = useMemo(() => 
    Object.values(parsedCards).filter(Boolean).length
  , [parsedCards]);

  const renderCardGrid = useMemo(() => {
    if (!results) return null;

    return (
      <div className="card-visual-grid">
        {spread.layout.map((row, rowIdx) => (
          <div key={rowIdx} className="card-row">
            {row.map((pos, colIdx) => {
              if (!pos) return <div key={colIdx} className="card-slot empty" />;
              const card = results.cards.find(c => c.position === pos);
              if (!card) return <div key={colIdx} className="card-slot empty" />;

              return (
                <div
                  key={colIdx}
                  className={`card-slot filled ${card.reversed ? 'reversed' : ''}`}
                  title={`${card.name}${card.reversed ? ' (Rovesciata)' : ''}`}
                >
                  <span className="card-symbol">{card.earSymbol || card.suitData?.symbol || '✦'}</span>
                  <span className="card-name">{card.name}</span>
                  <span className="position-name">{pos}</span>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    );
  }, [results, spread]);

  const generateInterpretation = useMemo(() => {
    if (!results) return null;

    const { dominant, percentages, stats, coherence, interactions, cards } = results;
    const nucleo = cards.find(c => c.position === 'centro');
    const futuro = cards.find(c => c.position === 'destra');
    const strongestPositive = results.positiveFlows[0];
    const strongestTension = results.tensions[0];

    const narrative = [];

    narrative.push(
      <p key="profile">
        <strong>Profilo EAR:</strong> Dominante {dominant} ({
          dominant.includes('Δ') ? percentages.delta :
          dominant.includes('⇄') ? percentages.relation : percentages.process
        }%). 
        Coerenza stesa: {(coherence * 100).toFixed(0)}%.
        {stats.majorCount > 0 && ` ${stats.majorCount} Arcani Maggiori presenti.`}
        {stats.reversedCount > 0 && ` ${stats.reversedCount} carte rovesciate.`}
      </p>
    );

    if (nucleo) {
      narrative.push(
        <p key="nucleo">
          <strong>Nucleo ({nucleo.name}):</strong> {nucleo.keywords.slice(0, 3).join(', ')}.
          {nucleo.waite && <em> "{nucleo.waite.split(',')[0]}"</em>}
          {nucleo.reversed && <span className="tension"> [Energia bloccata/invertita]</span>}
        </p>
      );
    }

    if (futuro) {
      narrative.push(
        <p key="futuro">
          <strong>Direzione ({futuro.name}):</strong> {futuro.keywords.slice(0, 3).join(', ')}.
          {futuro.reversed && <span className="tension"> [Ostacoli sul percorso]</span>}
        </p>
      );
    }

    if (strongestPositive) {
      narrative.push(
        <p key="resonance">
          <span className="resonance"><strong>Risonanza Principale:</strong></span> {strongestPositive.cards.join(' ↔ ')} 
          {' '}({strongestPositive.type}, score {strongestPositive.finalScore.toFixed(2)}).
          Questo flusso supporta la lettura.
        </p>
      );
    }

    if (strongestTension) {
      narrative.push(
        <p key="tension">
          <span className="tension"><strong>Tensione da Integrare:</strong></span> {strongestTension.cards.join(' ⊗ ')} 
          {' '}({strongestTension.type}, score {strongestTension.finalScore.toFixed(2)}).
          Quest'area richiede attenzione.
        </p>
      );
    }

    return narrative;
  }, [results]);

  return (
    <>
      <style>{styles}</style>
      <div className="ear-app">
        <header className="header">
          <h1 className="title">EAR Tarot Engine</h1>
          <p className="subtitle">Framework Ontologico per Letture Computazionali • v2.1</p>
        </header>

        <div className="main-grid">
          {/* Input Panel */}
          <div className="panel">
            <h2 className="panel-title">☉ Configurazione Stesa</h2>

            <div className="spread-selector">
              {Object.entries(SPREADS).map(([key, s]) => (
                <button
                  key={key}
                  className={`spread-btn ${selectedSpread === key ? 'active' : ''}`}
                  onClick={() => {
                    setSelectedSpread(key);
                    setCardInputs({});
                    setReversals({});
                    setParsedCards({});
                    setResults(null);
                  }}
                >
                  {s.name}
                </button>
              ))}
            </div>

            <textarea
              className="question-input"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Domanda del consultante..."
            />

            <div className="card-inputs">
              {spread.positions.map((pos) => (
                <div key={pos} className="card-input-row">
                  <span className="position-label">{POSITIONS[pos].symbol} {pos}</span>
                  <input
                    type="text"
                    className={`card-input ${
                      cardInputs[pos] 
                        ? parsedCards[pos] ? 'valid' : 'invalid' 
                        : ''
                    }`}
                    value={cardInputs[pos] || ''}
                    onChange={(e) => handleCardChange(pos, e.target.value)}
                    placeholder="Es: Il Mago, 6 di Coppe, Regina Spade..."
                  />
                  <label className="reversal-toggle">
                    <input
                      type="checkbox"
                      checked={reversals[pos] || false}
                      onChange={() => toggleReversal(pos)}
                    />
                    <span className="reversal-icon">↻</span>
                  </label>
                </div>
              ))}
            </div>

            <button
              className="compute-btn"
              onClick={handleCompute}
              disabled={validCardCount < 2}
            >
              ⚗ Computa Lettura EAR
            </button>

            <div className="element-legend">
              <span className="el-fire">🜂 Fuoco</span>
              <span className="el-water">🜄 Acqua</span>
              <span className="el-air">🜁 Aria</span>
              <span className="el-earth">🜃 Terra</span>
            </div>
          </div>

          {/* Results Panel */}
          <div className="panel results-panel">
            <h2 className="panel-title">☽ Analisi Computata</h2>

            {!results ? (
              <div className="no-results">
                Inserisci le carte e clicca "Computa Lettura" per vedere l'analisi EAR.
                <br /><br />
                <small>Supporta tutti i 78 Arcani: Maggiori (0-21), Numerali (1-10), Figure (Fante, Cavallo, Regina, Re)</small>
              </div>
            ) : (
              <>
                {renderCardGrid}

                <div className="stats-row">
                  <div className="stat-item">
                    <div className="stat-value">{results.stats.totalCards}</div>
                    <div className="stat-label">Carte</div>
                  </div>
                  <div className="stat-item">
                    <div className="stat-value">{results.stats.majorCount}</div>
                    <div className="stat-label">Maggiori</div>
                  </div>
                  <div className="stat-item">
                    <div className="stat-value">{results.stats.reversedCount}</div>
                    <div className="stat-label">Rovesciate</div>
                  </div>
                  <div className="stat-item">
                    <div className="stat-value">{(results.coherence * 100).toFixed(0)}%</div>
                    <div className="stat-label">Coerenza</div>
                  </div>
                </div>

                <div className="ear-display">
                  <div className="ear-component">
                    <div className="ear-symbol ear-delta">Δ</div>
                    <div className="ear-value">{results.composite.delta.toFixed(2)}</div>
                    <div className="ear-percent">{results.percentages.delta}%</div>
                    <div className="ear-label">Distinzione</div>
                  </div>
                  <div className="ear-component">
                    <div className="ear-symbol ear-relation">⇄</div>
                    <div className="ear-value">{results.composite.relation.toFixed(2)}</div>
                    <div className="ear-percent">{results.percentages.relation}%</div>
                    <div className="ear-label">Relazione</div>
                  </div>
                  <div className="ear-component">
                    <div className="ear-symbol ear-process">⟳</div>
                    <div className="ear-value">{results.composite.process.toFixed(2)}</div>
                    <div className="ear-percent">{results.percentages.process}%</div>
                    <div className="ear-label">Processo</div>
                  </div>
                </div>

                <div className="coherence-bar">
                  <div className="coherence-header">
                    <span>Indice di Coerenza</span>
                    <span className="coherence-value">{(results.coherence * 100).toFixed(1)}%</span>
                  </div>
                  <div className="meter">
                    <div
                      className={`meter-fill ${
                        results.coherence > 0.5 ? 'meter-positive' :
                        results.coherence > 0 ? 'meter-neutral' : 'meter-negative'
                      }`}
                      style={{ width: `${Math.max(5, (results.coherence + 1) * 50)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="panel-title" style={{ fontSize: '0.75rem', marginBottom: '0.5rem' }}>
                    Dimensioni Attive
                  </div>
                  <div className="dimensions-grid">
                    {['D1', 'D2', 'D3', 'D4'].map(dim => (
                      <div key={dim} className="dim-block">
                        <div className="dim-name">{dim}</div>
                        <div className="dim-value">{((results.dimensions[dim] || 0) * 100).toFixed(0)}%</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="panel-title" style={{ fontSize: '0.75rem', marginBottom: '0.5rem' }}>
                    Interazioni ({results.interactions.length})
                  </div>
                  <div className="interactions-list">
                    {results.interactions.slice(0, 8).map((int, idx) => (
                      <div
                        key={idx}
                        className={`interaction-item ${
                          int.finalScore > 0.3 ? 'positive' :
                          int.finalScore < -0.2 ? 'negative' : 'neutral'
                        }`}
                      >
                        <span>{int.cards[0]} ↔ {int.cards[1]}</span>
                        <span className="interaction-score" style={{
                          color: int.finalScore > 0.3 ? 'var(--emerald)' :
                                 int.finalScore < -0.2 ? 'var(--crimson)' : 'var(--sapphire)'
                        }}>
                          {int.finalScore.toFixed(2)} • {int.type}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="interpretation-block">
                  <div className="interpretation-title">⚗ Sintesi Interpretativa</div>
                  <div className="interpretation-text">
                    {generateInterpretation}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
