// ═══════════════════════════════════════════════════════════════════════════
// EAR vs LLM COMPARISON TEST
// Generazione output EAR per le 20 carte selezionate
// ═══════════════════════════════════════════════════════════════════════════

// ARCANI MAGGIORI (dal motore EAR v2.1)
const ARCANI_MAGGIORI = {
  0: { name: 'Il Matto', ear: { delta: 0.50, relation: 0.50, process: 0.99 }, pole: 'neutral', element: 'aether', keywords: ['potenziale', 'salto', 'follia sacra'] },
  1: { name: 'Il Mago', ear: { delta: 0.90, relation: 0.50, process: 0.90 }, pole: '+', element: 'air', keywords: ['volontà', 'manifestazione', 'potere'] },
  2: { name: 'La Papessa', ear: { delta: 0.50, relation: 0.85, process: 0.70 }, pole: '-', element: 'water', keywords: ['intuizione', 'mistero', 'ricettività'] },
  3: { name: "L'Imperatrice", ear: { delta: 0.45, relation: 0.95, process: 0.80 }, pole: '+', element: 'earth', keywords: ['fertilità', 'abbondanza', 'creazione'] },
  4: { name: "L'Imperatore", ear: { delta: 0.95, relation: 0.60, process: 0.55 }, pole: '+', element: 'fire', keywords: ['autorità', 'struttura', 'ordine'] },
  5: { name: 'Il Papa', ear: { delta: 0.60, relation: 0.85, process: 0.60 }, pole: '+', element: 'earth', keywords: ['tradizione', 'insegnamento', 'ponte'] },
  6: { name: 'Gli Amanti', ear: { delta: 0.45, relation: 0.98, process: 0.65 }, pole: '+', element: 'air', keywords: ['scelta', 'unione', 'armonia'] },
  7: { name: 'Il Carro', ear: { delta: 0.75, relation: 0.55, process: 0.90 }, pole: '+', element: 'water', keywords: ['trionfo', 'movimento', 'conquista'] },
  8: { name: 'La Giustizia', ear: { delta: 0.95, relation: 0.65, process: 0.45 }, pole: 'neutral', element: 'air', keywords: ['equilibrio', 'verità', 'karma'] },
  9: { name: "L'Eremita", ear: { delta: 0.85, relation: 0.35, process: 0.70 }, pole: '-', element: 'earth', keywords: ['introspezione', 'solitudine', 'guida'] },
  10: { name: 'La Ruota', ear: { delta: 0.50, relation: 0.60, process: 0.98 }, pole: 'neutral', element: 'fire', keywords: ['destino', 'ciclo', 'cambiamento'] },
  11: { name: 'La Forza', ear: { delta: 0.60, relation: 0.80, process: 0.75 }, pole: '+', element: 'fire', keywords: ['forza', 'pazienza', 'controllo'] },
  12: { name: "L'Appeso", ear: { delta: 0.30, relation: 0.80, process: 0.40 }, pole: '-', element: 'water', keywords: ['sospensione', 'sacrificio', 'resa'] },
  13: { name: 'La Morte', ear: { delta: 0.90, relation: 0.25, process: 0.85 }, pole: '-', element: 'water', keywords: ['trasformazione', 'fine', 'rinascita'] },
  14: { name: 'La Temperanza', ear: { delta: 0.50, relation: 0.90, process: 0.75 }, pole: 'neutral', element: 'water', keywords: ['equilibrio', 'pazienza', 'alchimia'] },
  15: { name: 'Il Diavolo', ear: { delta: 0.85, relation: 0.40, process: 0.35 }, pole: '-', element: 'earth', keywords: ['ombra', 'legame', 'materia'] },
  16: { name: 'La Torre', ear: { delta: 0.98, relation: 0.20, process: 0.90 }, pole: '-', element: 'fire', keywords: ['rottura', 'rivelazione', 'crollo'] },
  17: { name: 'La Stella', ear: { delta: 0.70, relation: 0.90, process: 0.85 }, pole: '+', element: 'air', keywords: ['speranza', 'ispirazione', 'guida'] },
  18: { name: 'La Luna', ear: { delta: 0.35, relation: 0.70, process: 0.75 }, pole: '-', element: 'water', keywords: ['illusione', 'inconscio', 'paura'] },
  19: { name: 'Il Sole', ear: { delta: 0.70, relation: 0.85, process: 0.90 }, pole: '+', element: 'fire', keywords: ['gioia', 'successo', 'chiarezza'] },
  20: { name: 'Il Giudizio', ear: { delta: 0.75, relation: 0.80, process: 0.85 }, pole: '+', element: 'fire', keywords: ['risveglio', 'chiamata', 'resurrezione'] },
  21: { name: 'Il Mondo', ear: { delta: 0.90, relation: 0.90, process: 0.90 }, pole: 'neutral', element: 'aether', keywords: ['completamento', 'integrazione', 'totalità'] }
};

// SEMI
const SUITS = {
  bastoni: { element: 'fire', pole: '+', ear_mod: { delta: 0.10, relation: -0.05, process: 0.15 }, keywords: ['volontà', 'azione', 'creatività', 'passione'] },
  coppe: { element: 'water', pole: '-', ear_mod: { delta: -0.10, relation: 0.20, process: 0.05 }, keywords: ['emozioni', 'relazioni', 'intuizione', 'amore'] },
  spade: { element: 'air', pole: 'neutral', ear_mod: { delta: 0.20, relation: -0.10, process: 0.00 }, keywords: ['mente', 'conflitto', 'verità', 'decisione'] },
  denari: { element: 'earth', pole: '+', ear_mod: { delta: 0.05, relation: 0.10, process: -0.10 }, keywords: ['materia', 'stabilità', 'risorse', 'corpo'] }
};

// NUMERI
const NUMBERS = {
  1: { meaning: 'origine', ear: { delta: 0.95, relation: 0.30, process: 0.50 }, keywords: ['inizio', 'potenziale', 'seme'] },
  2: { meaning: 'dualità', ear: { delta: 0.60, relation: 0.85, process: 0.35 }, keywords: ['scelta', 'equilibrio', 'partnership'] },
  3: { meaning: 'espansione', ear: { delta: 0.50, relation: 0.70, process: 0.75 }, keywords: ['crescita', 'sintesi', 'creatività'] },
  4: { meaning: 'stabilità', ear: { delta: 0.85, relation: 0.55, process: 0.40 }, keywords: ['fondazione', 'struttura', 'pausa'] },
  5: { meaning: 'conflitto', ear: { delta: 0.65, relation: 0.40, process: 0.70 }, keywords: ['sfida', 'cambiamento', 'instabilità'] },
  6: { meaning: 'equilibrio', ear: { delta: 0.50, relation: 0.90, process: 0.60 }, keywords: ['armonia', 'reciprocità', 'scambio'] },
  7: { meaning: 'visione', ear: { delta: 0.75, relation: 0.45, process: 0.80 }, keywords: ['riflessione', 'sfida', 'introspezione'] },
  8: { meaning: 'movimento', ear: { delta: 0.60, relation: 0.60, process: 0.85 }, keywords: ['azione', 'velocità', 'potere'] },
  9: { meaning: 'compimento', ear: { delta: 0.70, relation: 0.70, process: 0.75 }, keywords: ['realizzazione', 'saggezza', 'solitudine'] },
  10: { meaning: 'culminazione', ear: { delta: 0.80, relation: 0.80, process: 0.50 }, keywords: ['completamento', 'eccesso', 'eredità'] }
};

// FIGURE
const COURT = {
  fante: { ear: { delta: 0.45, relation: 0.60, process: 0.70 }, keywords: ['messaggero', 'inizio', 'apprendimento'] },
  cavallo: { ear: { delta: 0.65, relation: 0.55, process: 0.85 }, keywords: ['azione', 'movimento', 'passione'] },
  regina: { ear: { delta: 0.55, relation: 0.85, process: 0.65 }, keywords: ['ricettività', 'maturità', 'intuizione'] },
  re: { ear: { delta: 0.90, relation: 0.60, process: 0.55 }, keywords: ['autorità', 'padronanza', 'comando'] }
};

// ═══════════════════════════════════════════════════════════════════════════
// FUNZIONI DI CALCOLO
// ═══════════════════════════════════════════════════════════════════════════

function clamp(val) {
  return Math.max(0, Math.min(1, val));
}

function applyReversal(ear) {
  const inverted = {
    delta: ear.delta * 0.4,
    relation: ear.relation * 0.3,
    process: ear.process * 0.5
  };
  
  if (ear.delta > 0.7) inverted.delta = 0.9 - ear.delta * 0.5;
  if (ear.relation > 0.7) inverted.relation = -0.2 + ear.relation * 0.3;
  
  return inverted;
}

function getDominant(ear) {
  if (ear.delta >= ear.relation && ear.delta >= ear.process) return 'Δ';
  if (ear.relation >= ear.process) return '⇄';
  return '⟳';
}

function deriveKeywords(ear, pole, element, baseKeywords, reversed) {
  const derived = [];
  
  // Da componente dominante
  if (ear.delta > 0.7 && !reversed) derived.push('manifestazione');
  if (ear.delta > 0.7 && reversed) derived.push('blocco');
  if (ear.relation > 0.7 && !reversed) derived.push('connessione');
  if (ear.relation > 0.7 && reversed) derived.push('isolamento');
  if (ear.process > 0.7 && !reversed) derived.push('trasformazione');
  if (ear.process > 0.7 && reversed) derived.push('stagnazione');
  
  // Aggiungi keywords base (max 2)
  derived.push(...baseKeywords.slice(0, 2));
  
  // Limita a 5
  return derived.slice(0, 5);
}

function earToValence(ear, reversed) {
  // Valenza basata su equilibrio EAR e polarità
  const balance = (ear.delta + ear.relation + ear.process) / 3;
  const harmony = 1 - Math.abs(ear.delta - ear.relation) - Math.abs(ear.relation - ear.process);
  let valence = (balance * 0.6 + harmony * 0.4);
  
  if (reversed) valence = valence * 0.3 - 0.3;
  
  return Math.max(-1, Math.min(1, valence * 2 - 0.5));
}

function earToEnergy(ear, pole, reversed) {
  const dominance = ear.delta + ear.process * 0.5;
  const passivity = ear.relation + ear.process * 0.3;
  
  if (reversed) {
    return 'passive'; // Rovesciamento blocca energia
  }
  
  if (dominance > passivity + 0.2) return 'active';
  if (passivity > dominance + 0.2) return 'passive';
  return 'neutral';
}

function elementToDomain(element) {
  const map = {
    'fire': 'spiritual',
    'water': 'emotional',
    'air': 'mental',
    'earth': 'material',
    'aether': 'spiritual'
  };
  return map[element] || 'spiritual';
}

function generateInterpretation(ear, keywords, pole, reversed) {
  const dom = getDominant(ear);
  const domName = dom === 'Δ' ? 'Distinzione' : dom === '⇄' ? 'Relazione' : 'Processo';
  
  if (reversed) {
    return `${domName} bloccata. ${keywords[0]} invertito verso ${keywords[1] || 'ombra'}.`;
  }
  return `${domName} dominante (${(Math.max(ear.delta, ear.relation, ear.process) * 100).toFixed(0)}%). Polarità ${pole === '+' ? 'attiva' : pole === '-' ? 'ricettiva' : 'equilibrata'}.`;
}

// ═══════════════════════════════════════════════════════════════════════════
// GENERAZIONE OUTPUT PER LE 20 CARTE TEST
// ═══════════════════════════════════════════════════════════════════════════

const testCards = [
  { id: 1, type: 'major', num: 1, name: 'Il Mago', reversed: false },
  { id: 2, type: 'major', num: 18, name: 'La Luna', reversed: true },
  { id: 3, type: 'numeral', num: 10, suit: 'spade', name: 'Dieci di Spade', reversed: false },
  { id: 4, type: 'court', court: 'regina', suit: 'coppe', name: 'Regina di Coppe', reversed: false },
  { id: 5, type: 'major', num: 15, name: 'Il Diavolo', reversed: true },
  { id: 6, type: 'numeral', num: 3, suit: 'bastoni', name: 'Tre di Bastoni', reversed: false },
  { id: 7, type: 'court', court: 'cavallo', suit: 'denari', name: 'Cavaliere di Denari', reversed: true },
  { id: 8, type: 'major', num: 17, name: 'La Stella', reversed: false },
  { id: 9, type: 'court', court: 'fante', suit: 'spade', name: 'Fante di Spade', reversed: false },
  { id: 10, type: 'major', num: 4, name: "L'Imperatore", reversed: true },
  { id: 11, type: 'numeral', num: 6, suit: 'coppe', name: 'Sei di Coppe', reversed: false },
  { id: 12, type: 'major', num: 16, name: 'La Torre', reversed: false },
  { id: 13, type: 'numeral', num: 1, suit: 'denari', name: 'Asso di Denari', reversed: true },
  { id: 14, type: 'numeral', num: 2, suit: 'bastoni', name: 'Due di Bastoni', reversed: false },
  { id: 15, type: 'major', num: 2, name: 'La Papessa', reversed: false },
  { id: 16, type: 'numeral', num: 8, suit: 'spade', name: 'Otto di Spade', reversed: true },
  { id: 17, type: 'court', court: 're', suit: 'bastoni', name: 'Re di Bastoni', reversed: false },
  { id: 18, type: 'major', num: 10, name: 'La Ruota della Fortuna', reversed: false },
  { id: 19, type: 'numeral', num: 5, suit: 'coppe', name: 'Cinque di Coppe', reversed: true },
  { id: 20, type: 'major', num: 21, name: 'Il Mondo', reversed: false }
];

function generateEAROutput(card) {
  let baseEar, pole, element, keywords;
  
  if (card.type === 'major') {
    const data = ARCANI_MAGGIORI[card.num];
    baseEar = { ...data.ear };
    pole = data.pole;
    element = data.element;
    keywords = [...data.keywords];
  } else if (card.type === 'numeral') {
    const numData = NUMBERS[card.num];
    const suitData = SUITS[card.suit];
    baseEar = {
      delta: clamp(numData.ear.delta + suitData.ear_mod.delta),
      relation: clamp(numData.ear.relation + suitData.ear_mod.relation),
      process: clamp(numData.ear.process + suitData.ear_mod.process)
    };
    pole = suitData.pole;
    element = suitData.element;
    keywords = [...numData.keywords, ...suitData.keywords.slice(0, 2)];
  } else if (card.type === 'court') {
    const courtData = COURT[card.court];
    const suitData = SUITS[card.suit];
    baseEar = {
      delta: clamp(courtData.ear.delta + suitData.ear_mod.delta),
      relation: clamp(courtData.ear.relation + suitData.ear_mod.relation),
      process: clamp(courtData.ear.process + suitData.ear_mod.process)
    };
    pole = suitData.pole;
    element = suitData.element;
    keywords = [...courtData.keywords, ...suitData.keywords.slice(0, 2)];
  }
  
  // Applica rovesciamento se necessario
  const finalEar = card.reversed ? applyReversal(baseEar) : baseEar;
  const finalPole = card.reversed ? (pole === '+' ? '-' : pole === '-' ? '+' : 'blocked') : pole;
  
  return {
    id: card.id,
    name: card.name,
    reversed: card.reversed,
    vector: [
      parseFloat(finalEar.delta.toFixed(2)),
      parseFloat(finalEar.relation.toFixed(2)),
      parseFloat(finalEar.process.toFixed(2))
    ],
    pole: finalPole,
    dominant: getDominant(finalEar),
    keywords_derived: deriveKeywords(finalEar, finalPole, element, keywords, card.reversed),
    valence: parseFloat(earToValence(finalEar, card.reversed).toFixed(2)),
    energy: earToEnergy(finalEar, finalPole, card.reversed),
    domain: elementToDomain(element),
    interpretation: generateInterpretation(finalEar, keywords, finalPole, card.reversed)
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// ESECUZIONE TEST
// ═══════════════════════════════════════════════════════════════════════════

console.log("═══════════════════════════════════════════════════════════════════════════");
console.log("EAR TAROT ENGINE - OUTPUT PER 20 CARTE TEST");
console.log("═══════════════════════════════════════════════════════════════════════════\n");

const results = [];

for (const card of testCards) {
  const output = generateEAROutput(card);
  results.push(output);
  
  console.log(`\n${output.id}. ${output.name}${output.reversed ? ' (ROVESCIATA)' : ''}`);
  console.log(`   Vector: [Δ:${output.vector[0]}, ⇄:${output.vector[1]}, ⟳:${output.vector[2]}]`);
  console.log(`   Pole: ${output.pole} | Dominant: ${output.dominant}`);
  console.log(`   Keywords: ${output.keywords_derived.join(', ')}`);
  console.log(`   Valence: ${output.valence} | Energy: ${output.energy} | Domain: ${output.domain}`);
  console.log(`   Interpretation: ${output.interpretation}`);
}

// Output JSON per confronto
console.log("\n\n═══════════════════════════════════════════════════════════════════════════");
console.log("JSON OUTPUT PER CONFRONTO METRICHE");
console.log("═══════════════════════════════════════════════════════════════════════════\n");

const jsonOutput = results.map(r => ({
  id: r.id,
  name: r.name,
  reversed: r.reversed,
  keywords: r.keywords_derived,
  valence: r.valence,
  energy: r.energy,
  domain: r.domain,
  archetype: r.interpretation
}));

console.log(JSON.stringify(jsonOutput, null, 2));
