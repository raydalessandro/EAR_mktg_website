// ═══════════════════════════════════════════════════════════════════════════
// EAR TAROT ENGINE v2.1 - TEST SUITE ESTESO
// Validazione su scala: 78 carte, interazioni, coerenza Waite
// ═══════════════════════════════════════════════════════════════════════════

// Importo le strutture dati dal componente
const OPPOSITIONS = {
  polar: [[15, 17], [18, 19], [16, 11], [13, 3], [12, 7], [9, 6], [15, 6]],
  dynamic: [[1, 2], [4, 3], [8, 10], [14, 16]],
  resonance: [[1, 17], [2, 18], [17, 19], [3, 6], [4, 8], [10, 21], [20, 21], [0, 21], [5, 11], [7, 19]]
};

const ARCANI_MAGGIORI = {
  0: { name: 'Il Matto', type: 'soglia', earSymbol: '○→●', ear: { delta: 0.50, relation: 0.50, process: 0.99 }, pole: 'neutral', element: 'aether', keywords: ['potenziale', 'salto', 'follia sacra'] },
  1: { name: 'Il Mago', type: 'nodo', nodo: '∇₀', earSymbol: '∇₀', ear: { delta: 0.90, relation: 0.50, process: 0.90 }, pole: '+', element: 'air', keywords: ['volontà', 'manifestazione', 'potere'] },
  2: { name: 'La Papessa', type: 'nodo', nodo: '◎', earSymbol: '◎', ear: { delta: 0.50, relation: 0.85, process: 0.70 }, pole: '-', element: 'water', keywords: ['intuizione', 'mistero', 'ricettività'] },
  3: { name: 'L\'Imperatrice', type: 'archetipo', earSymbol: '♀', ear: { delta: 0.45, relation: 0.95, process: 0.80 }, pole: '+', element: 'earth', keywords: ['fertilità', 'abbondanza', 'creazione'] },
  4: { name: 'L\'Imperatore', type: 'archetipo', earSymbol: '⟨⦿⟩', ear: { delta: 0.95, relation: 0.60, process: 0.55 }, pole: '+', element: 'fire', keywords: ['autorità', 'struttura', 'ordine'] },
  5: { name: 'Il Papa', type: 'archetipo', earSymbol: '⟡⫯⟡', ear: { delta: 0.60, relation: 0.85, process: 0.60 }, pole: '+', element: 'earth', keywords: ['tradizione', 'insegnamento', 'ponte'] },
  6: { name: 'Gli Amanti', type: 'archetipo', earSymbol: '≈⟷≈', ear: { delta: 0.45, relation: 0.98, process: 0.65 }, pole: '+', element: 'air', keywords: ['scelta', 'unione', 'armonia'] },
  7: { name: 'Il Carro', type: 'archetipo', earSymbol: '🔥⟐🔥', ear: { delta: 0.75, relation: 0.55, process: 0.90 }, pole: '+', element: 'water', keywords: ['trionfo', 'movimento', 'conquista'] },
  8: { name: 'La Giustizia', type: 'nodo', nodo: '⦿', earSymbol: '⦿', ear: { delta: 0.95, relation: 0.65, process: 0.45 }, pole: 'neutral', element: 'air', keywords: ['equilibrio', 'verità', 'karma'] },
  9: { name: 'L\'Eremita', type: 'archetipo', earSymbol: '◉◎◉', ear: { delta: 0.85, relation: 0.35, process: 0.70 }, pole: '-', element: 'earth', keywords: ['introspezione', 'solitudine', 'guida'] },
  10: { name: 'La Ruota', type: 'nodo', nodo: '⟐', earSymbol: '⟐', ear: { delta: 0.50, relation: 0.60, process: 0.98 }, pole: 'neutral', element: 'fire', keywords: ['destino', 'ciclo', 'cambiamento'] },
  11: { name: 'La Forza', type: 'nodo', nodo: '⟡', earSymbol: '⟡', ear: { delta: 0.60, relation: 0.80, process: 0.75 }, pole: '+', element: 'fire', keywords: ['forza', 'pazienza', 'controllo'] },
  12: { name: 'L\'Appeso', type: 'soglia', earSymbol: '●↔○', ear: { delta: 0.30, relation: 0.80, process: 0.40 }, pole: '-', element: 'water', keywords: ['sospensione', 'sacrificio', 'resa'] },
  13: { name: 'La Morte', type: 'archetipo', earSymbol: '∅◯∅', ear: { delta: 0.90, relation: 0.25, process: 0.85 }, pole: '-', element: 'water', keywords: ['trasformazione', 'fine', 'rinascita'] },
  14: { name: 'La Temperanza', type: 'archetipo', earSymbol: '☯⚡☯', ear: { delta: 0.50, relation: 0.90, process: 0.75 }, pole: 'neutral', element: 'water', keywords: ['equilibrio', 'pazienza', 'alchimia'] },
  15: { name: 'Il Diavolo', type: 'nodo', nodo: '⟷', earSymbol: '⟷', ear: { delta: 0.85, relation: 0.40, process: 0.35 }, pole: '-', element: 'earth', keywords: ['ombra', 'legame', 'materia'] },
  16: { name: 'La Torre', type: 'archetipo', earSymbol: '⟨🔑|🔑⟩', ear: { delta: 0.98, relation: 0.20, process: 0.90 }, pole: '-', element: 'fire', keywords: ['rottura', 'rivelazione', 'crollo'] },
  17: { name: 'La Stella', type: 'archetipo', earSymbol: '◎≋◎', ear: { delta: 0.70, relation: 0.90, process: 0.85 }, pole: '+', element: 'air', keywords: ['speranza', 'ispirazione', 'guida'] },
  18: { name: 'La Luna', type: 'nodo', nodo: '∅', earSymbol: '∅', ear: { delta: 0.35, relation: 0.70, process: 0.75 }, pole: '-', element: 'water', keywords: ['illusione', 'inconscio', 'paura'] },
  19: { name: 'Il Sole', type: 'archetipo', earSymbol: '☉', ear: { delta: 0.70, relation: 0.85, process: 0.90 }, pole: '+', element: 'fire', keywords: ['gioia', 'successo', 'chiarezza'] },
  20: { name: 'Il Giudizio', type: 'archetipo', earSymbol: '👁∅👁', ear: { delta: 0.75, relation: 0.80, process: 0.85 }, pole: '+', element: 'fire', keywords: ['risveglio', 'chiamata', 'resurrezione'] },
  21: { name: 'Il Mondo', type: 'soglia', earSymbol: '◉∞◉', ear: { delta: 0.90, relation: 0.90, process: 0.90 }, pole: 'neutral', element: 'aether', keywords: ['completamento', 'integrazione', 'totalità'] }
};

const SUITS = {
  bastoni: { name: 'Bastoni', symbol: '🜂', element: 'fire', dimension: 'D4', pole: '+', ear_mod: { delta: 0.10, relation: -0.05, process: 0.15 } },
  coppe: { name: 'Coppe', symbol: '🜄', element: 'water', dimension: 'D2', pole: '-', ear_mod: { delta: -0.10, relation: 0.20, process: 0.05 } },
  spade: { name: 'Spade', symbol: '🜁', element: 'air', dimension: 'D3', pole: 'neutral', ear_mod: { delta: 0.20, relation: -0.10, process: 0.00 } },
  denari: { name: 'Denari', symbol: '🜃', element: 'earth', dimension: 'D1', pole: '+', ear_mod: { delta: 0.05, relation: 0.10, process: -0.10 } }
};

const NUMBERS = {
  1: { name: 'Asso', ear: { delta: 0.95, relation: 0.30, process: 0.50 }, meaning: 'origine' },
  2: { name: 'Due', ear: { delta: 0.60, relation: 0.85, process: 0.35 }, meaning: 'dualità' },
  3: { name: 'Tre', ear: { delta: 0.50, relation: 0.70, process: 0.75 }, meaning: 'espansione' },
  4: { name: 'Quattro', ear: { delta: 0.85, relation: 0.55, process: 0.40 }, meaning: 'stabilità' },
  5: { name: 'Cinque', ear: { delta: 0.65, relation: 0.40, process: 0.70 }, meaning: 'conflitto' },
  6: { name: 'Sei', ear: { delta: 0.50, relation: 0.90, process: 0.60 }, meaning: 'equilibrio' },
  7: { name: 'Sette', ear: { delta: 0.75, relation: 0.45, process: 0.80 }, meaning: 'visione' },
  8: { name: 'Otto', ear: { delta: 0.60, relation: 0.60, process: 0.85 }, meaning: 'movimento' },
  9: { name: 'Nove', ear: { delta: 0.70, relation: 0.70, process: 0.75 }, meaning: 'compimento' },
  10: { name: 'Dieci', ear: { delta: 0.80, relation: 0.80, process: 0.50 }, meaning: 'culminazione' }
};

const COURT = {
  fante: { name: 'Fante', weight: 1.3, ear: { delta: 0.45, relation: 0.60, process: 0.70 } },
  cavallo: { name: 'Cavallo', weight: 1.4, ear: { delta: 0.65, relation: 0.55, process: 0.85 } },
  regina: { name: 'Regina', weight: 1.5, ear: { delta: 0.55, relation: 0.85, process: 0.65 } },
  re: { name: 'Re', weight: 1.6, ear: { delta: 0.90, relation: 0.60, process: 0.55 } }
};

// Funzioni di calcolo
function getMinorCard(num, suitKey, courtKey = null) {
  const suit = SUITS[suitKey];
  let baseEar, name, weight = 1.0;
  
  if (courtKey && COURT[courtKey]) {
    const court = COURT[courtKey];
    baseEar = court.ear;
    name = `${court.name} di ${suit.name}`;
    weight = court.weight;
  } else if (num && NUMBERS[num]) {
    baseEar = NUMBERS[num].ear;
    name = `${num} di ${suit.name}`;
  } else {
    // Fallback
    baseEar = { delta: 0.5, relation: 0.5, process: 0.5 };
    name = `Carta di ${suit.name}`;
  }
  
  return {
    type: courtKey ? 'court' : 'numeral',
    name,
    suit: suitKey,
    number: num,
    ear: {
      delta: Math.max(0, Math.min(1, baseEar.delta + suit.ear_mod.delta)),
      relation: Math.max(0, Math.min(1, baseEar.relation + suit.ear_mod.relation)),
      process: Math.max(0, Math.min(1, baseEar.process + suit.ear_mod.process))
    },
    pole: suit.pole,
    element: suit.element,
    weight
  };
}

function applyReversal(card) {
  const invertedEar = {
    delta: card.ear.delta * 0.4,
    relation: card.ear.relation * 0.3,
    process: card.ear.process * 0.5
  };
  if (card.ear.delta > 0.7) invertedEar.delta = 0.9 - card.ear.delta * 0.5;
  if (card.ear.relation > 0.7) invertedEar.relation = -0.2 + card.ear.relation * 0.3;
  
  return {
    ...card,
    reversed: true,
    ear: invertedEar,
    weight: card.weight * 0.5,
    pole: card.pole === '+' ? '-' : card.pole === '-' ? '+' : 'blocked'
  };
}

function calculateInteraction(card1, card2) {
  const ear1 = card1.ear;
  const ear2 = card2.ear;
  
  const dot = ear1.delta * ear2.delta + ear1.relation * ear2.relation + ear1.process * ear2.process;
  const mag1 = Math.sqrt(ear1.delta**2 + ear1.relation**2 + ear1.process**2);
  const mag2 = Math.sqrt(ear2.delta**2 + ear2.relation**2 + ear2.process**2);
  const geometricCorrelation = mag1 > 0 && mag2 > 0 ? dot / (mag1 * mag2) : 0;
  
  let isPolarOpposite = false, isDynamicTension = false, isDeepResonance = false;
  
  if (card1.number !== undefined && card2.number !== undefined && 
      card1.type === 'major' && card2.type === 'major') {
    isPolarOpposite = OPPOSITIONS.polar.some(([a, b]) => 
      (a === card1.number && b === card2.number) || (a === card2.number && b === card1.number));
    isDynamicTension = OPPOSITIONS.dynamic.some(([a, b]) => 
      (a === card1.number && b === card2.number) || (a === card2.number && b === card1.number));
    isDeepResonance = OPPOSITIONS.resonance.some(([a, b]) => 
      (a === card1.number && b === card2.number) || (a === card2.number && b === card1.number));
  }
  
  let polarityTension = 0;
  if (card1.pole === '+' && card2.pole === '-') polarityTension = 0.2;
  if (card1.pole === '-' && card2.pole === '+') polarityTension = 0.2;
  
  let elementTension = 0;
  const elementOpposites = { fire: 'water', water: 'fire', air: 'earth', earth: 'air' };
  if (elementOpposites[card1.element] === card2.element) elementTension = 0.15;
  
  let sameElementBonus = 0;
  if (card1.element === card2.element) sameElementBonus = 0.1;
  if (card1.suit && card2.suit && card1.suit === card2.suit) sameElementBonus = 0.15;
  
  let finalScore, interactionType;
  
  if (isPolarOpposite) {
    finalScore = -0.6 - polarityTension - elementTension;
    interactionType = 'OPPOSIZIONE POLARE';
  } else if (isDynamicTension) {
    finalScore = 0.1 - polarityTension;
    interactionType = 'TENSIONE DINAMICA';
  } else if (isDeepResonance) {
    finalScore = geometricCorrelation + 0.2 + sameElementBonus;
    interactionType = 'RISONANZA PROFONDA';
  } else {
    finalScore = geometricCorrelation - polarityTension - elementTension + sameElementBonus;
    if (card1.reversed || card2.reversed) finalScore -= 0.15;
    if (card1.reversed && card2.reversed) finalScore -= 0.1;
    
    if (finalScore > 0.85) interactionType = 'Forte Risonanza';
    else if (finalScore > 0.6) interactionType = 'Risonanza';
    else if (finalScore > 0.3) interactionType = 'Affinità';
    else if (finalScore > 0) interactionType = 'Neutralità';
    else if (finalScore > -0.3) interactionType = 'Tensione';
    else interactionType = 'Forte Tensione';
  }
  
  return { cards: [card1.name, card2.name], finalScore, type: interactionType, geometric: geometricCorrelation };
}

function computeReading(cards) {
  const totalWeight = cards.reduce((sum, c) => sum + c.weight, 0);
  cards.forEach(c => c.normalizedWeight = c.weight / totalWeight);
  
  const composite = { delta: 0, relation: 0, process: 0 };
  for (const card of cards) {
    composite.delta += card.normalizedWeight * card.ear.delta;
    composite.relation += card.normalizedWeight * card.ear.relation;
    composite.process += card.normalizedWeight * card.ear.process;
  }
  
  const interactions = [];
  for (let i = 0; i < cards.length; i++) {
    for (let j = i + 1; j < cards.length; j++) {
      interactions.push(calculateInteraction(cards[i], cards[j]));
    }
  }
  
  const coherenceSum = interactions.reduce((sum, i) => sum + i.finalScore, 0);
  const coherence = interactions.length > 0 ? coherenceSum / interactions.length : 0;
  
  const total = composite.delta + composite.relation + composite.process;
  const dominant = composite.delta > composite.relation && composite.delta > composite.process 
    ? 'Δ' : composite.relation > composite.process ? '⇄' : '⟳';
  
  return { cards, composite, dominant, coherence, interactions };
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST SUITE
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════');
console.log('    EAR TAROT ENGINE v2.1 - TEST SUITE ESTESO');
console.log('    78 Carte | Interazioni Ontologiche | Validazione Waite');
console.log('═══════════════════════════════════════════════════════════════════════════\n');

// ═══════════════════════════════════════════════════════════════════════════
// TEST 1: DISTRIBUZIONE EAR DEI 22 ARCANI MAGGIORI
// ═══════════════════════════════════════════════════════════════════════════

console.log('╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 1: Distribuzione EAR - 22 Arcani Maggiori                           ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

let deltaHigh = 0, relationHigh = 0, processHigh = 0;
let typeCounts = { soglia: 0, nodo: 0, archetipo: 0 };
let poleCounts = { '+': 0, '-': 0, 'neutral': 0 };
let elementCounts = { fire: 0, water: 0, air: 0, earth: 0, aether: 0 };

for (const [num, card] of Object.entries(ARCANI_MAGGIORI)) {
  const { delta, relation, process } = card.ear;
  if (delta >= relation && delta >= process) deltaHigh++;
  else if (relation >= process) relationHigh++;
  else processHigh++;
  
  typeCounts[card.type]++;
  poleCounts[card.pole]++;
  elementCounts[card.element]++;
}

console.log('Attributo Dominante:');
console.log(`  Δ Distinzione: ${deltaHigh} carte (${(deltaHigh/22*100).toFixed(0)}%)`);
console.log(`  ⇄ Relazione:   ${relationHigh} carte (${(relationHigh/22*100).toFixed(0)}%)`);
console.log(`  ⟳ Processo:    ${processHigh} carte (${(processHigh/22*100).toFixed(0)}%)`);

console.log('\nTipologia:');
console.log(`  Soglie:     ${typeCounts.soglia} (transizioni fondamentali)`);
console.log(`  Nodi:       ${typeCounts.nodo} (principi ermetici)`);
console.log(`  Archetipi:  ${typeCounts.archetipo} (forze primordiali)`);

console.log('\nPolarità:');
console.log(`  + (Yang):    ${poleCounts['+']} carte`);
console.log(`  - (Yin):     ${poleCounts['-']} carte`);
console.log(`  Neutral:     ${poleCounts['neutral']} carte`);

console.log('\nElementi:');
Object.entries(elementCounts).forEach(([el, count]) => {
  if (count > 0) console.log(`  ${el.padEnd(8)}: ${count} carte`);
});

// ═══════════════════════════════════════════════════════════════════════════
// TEST 2: DISTRIBUZIONE EAR DEI 40 ARCANI NUMERALI
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 2: Distribuzione EAR - 40 Arcani Numerali                           ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

console.log('Progressione EAR per Numero (media sui 4 semi):');
console.log('Num | Δ     | ⇄     | ⟳     | Dominante | Significato');
console.log('----|-------|-------|-------|-----------|------------');

for (let num = 1; num <= 10; num++) {
  let avgD = 0, avgR = 0, avgP = 0;
  for (const suit of Object.keys(SUITS)) {
    const card = getMinorCard(num, suit);
    avgD += card.ear.delta;
    avgR += card.ear.relation;
    avgP += card.ear.process;
  }
  avgD /= 4; avgR /= 4; avgP /= 4;
  
  const dom = avgD > avgR && avgD > avgP ? 'Δ' : avgR > avgP ? '⇄' : '⟳';
  console.log(`${num.toString().padStart(2)}  | ${avgD.toFixed(2)}  | ${avgR.toFixed(2)}  | ${avgP.toFixed(2)}  | ${dom}         | ${NUMBERS[num].meaning}`);
}

console.log('\nVariazione per Seme (Asso come esempio):');
for (const [suitKey, suit] of Object.entries(SUITS)) {
  const card = getMinorCard(1, suitKey);
  console.log(`  Asso di ${suit.name.padEnd(8)}: [Δ:${card.ear.delta.toFixed(2)}, ⇄:${card.ear.relation.toFixed(2)}, ⟳:${card.ear.process.toFixed(2)}] | ${suit.element}`);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 3: DISTRIBUZIONE EAR DELLE 16 FIGURE DI CORTE
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 3: Distribuzione EAR - 16 Figure di Corte                           ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

console.log('Figura     | Bastoni     | Coppe       | Spade       | Denari');
console.log('-----------|-------------|-------------|-------------|-------------');

for (const [courtKey, court] of Object.entries(COURT)) {
  let row = `${court.name.padEnd(10)} |`;
  for (const suitKey of ['bastoni', 'coppe', 'spade', 'denari']) {
    const card = getMinorCard(null, suitKey, courtKey);
    const dom = card.ear.delta > card.ear.relation && card.ear.delta > card.ear.process ? 'Δ' :
                card.ear.relation > card.ear.process ? '⇄' : '⟳';
    row += ` ${dom}[${card.ear.delta.toFixed(1)},${card.ear.relation.toFixed(1)},${card.ear.process.toFixed(1)}] |`;
  }
  console.log(row);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 4: VALIDAZIONE INTERAZIONI ARCANI MAGGIORI
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 4: Validazione Interazioni - Arcani Maggiori                        ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

// Calcola tutte le 231 interazioni possibili tra i 22 Arcani Maggiori
const allMajorInteractions = [];
const arcaniList = Object.entries(ARCANI_MAGGIORI).map(([num, data]) => ({
  ...data, number: parseInt(num), type: 'major', weight: 2.0
}));

for (let i = 0; i < arcaniList.length; i++) {
  for (let j = i + 1; j < arcaniList.length; j++) {
    allMajorInteractions.push(calculateInteraction(arcaniList[i], arcaniList[j]));
  }
}

// Statistiche
const interactionTypes = {};
allMajorInteractions.forEach(int => {
  interactionTypes[int.type] = (interactionTypes[int.type] || 0) + 1;
});

console.log(`Totale interazioni calcolate: ${allMajorInteractions.length}`);
console.log('\nDistribuzione per tipo:');
Object.entries(interactionTypes).sort((a, b) => b[1] - a[1]).forEach(([type, count]) => {
  console.log(`  ${type.padEnd(20)}: ${count} (${(count/231*100).toFixed(1)}%)`);
});

// Top 5 risonanze
console.log('\nTop 5 Risonanze:');
allMajorInteractions.sort((a, b) => b.finalScore - a.finalScore).slice(0, 5).forEach((int, i) => {
  console.log(`  ${i+1}. ${int.cards[0]} ↔ ${int.cards[1]}: ${int.finalScore.toFixed(3)} (${int.type})`);
});

// Top 5 tensioni
console.log('\nTop 5 Tensioni:');
allMajorInteractions.sort((a, b) => a.finalScore - b.finalScore).slice(0, 5).forEach((int, i) => {
  console.log(`  ${i+1}. ${int.cards[0]} ↔ ${int.cards[1]}: ${int.finalScore.toFixed(3)} (${int.type})`);
});

// ═══════════════════════════════════════════════════════════════════════════
// TEST 5: INTERAZIONI TRA SEMI (Minori vs Minori)
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 5: Interazioni tra Semi - Compatibilità Elementale                  ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

console.log('Matrice di affinità media (6 di ogni seme):');
console.log('           | Bastoni | Coppe   | Spade   | Denari');
console.log('-----------|---------|---------|---------|--------');

const suitKeys = ['bastoni', 'coppe', 'spade', 'denari'];
for (const suit1 of suitKeys) {
  let row = `${SUITS[suit1].name.padEnd(10)} |`;
  for (const suit2 of suitKeys) {
    const card1 = getMinorCard(6, suit1);
    const card2 = getMinorCard(6, suit2);
    const int = calculateInteraction(card1, card2);
    const score = int.finalScore.toFixed(2);
    const color = int.finalScore > 0.6 ? '+' : int.finalScore < 0.3 ? '-' : ' ';
    row += ` ${color}${score}  |`;
  }
  console.log(row);
}

console.log('\nLegenda: + = affinità, - = tensione');

// ═══════════════════════════════════════════════════════════════════════════
// TEST 6: INTERAZIONI MAGGIORI vs MINORI
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 6: Interazioni Maggiori ↔ Minori                                    ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

// Test carte significative con ogni seme
const testMajors = [1, 6, 13, 17, 21]; // Mago, Amanti, Morte, Stella, Mondo
console.log('Arcano        | Bastoni | Coppe   | Spade   | Denari  | Elemento Arcano');
console.log('--------------|---------|---------|---------|---------|----------------');

for (const majorNum of testMajors) {
  const major = { ...ARCANI_MAGGIORI[majorNum], number: majorNum, type: 'major', weight: 2.0 };
  let row = `${major.name.padEnd(13)} |`;
  
  for (const suitKey of suitKeys) {
    const minor = getMinorCard(6, suitKey);
    const int = calculateInteraction(major, minor);
    row += ` ${int.finalScore.toFixed(2).padStart(5)}   |`;
  }
  row += ` ${major.element}`;
  console.log(row);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 7: EFFETTO ROVESCIAMENTO
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 7: Effetto Rovesciamento su EAR                                     ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

const testCards = [
  { ...ARCANI_MAGGIORI[1], number: 1, type: 'major', weight: 2.0 },  // Mago
  { ...ARCANI_MAGGIORI[17], number: 17, type: 'major', weight: 2.0 }, // Stella
  { ...ARCANI_MAGGIORI[15], number: 15, type: 'major', weight: 2.0 }, // Diavolo
  getMinorCard(1, 'bastoni'),
  getMinorCard(null, 'coppe', 'regina')
];

console.log('Carta                 | Diritto [Δ,⇄,⟳]      | Rovescio [Δ,⇄,⟳]     | ΔPeso');
console.log('----------------------|----------------------|----------------------|------');

for (const card of testCards) {
  const reversed = applyReversal({ ...card });
  const diritto = `[${card.ear.delta.toFixed(2)},${card.ear.relation.toFixed(2)},${card.ear.process.toFixed(2)}]`;
  const rovescio = `[${reversed.ear.delta.toFixed(2)},${reversed.ear.relation.toFixed(2)},${reversed.ear.process.toFixed(2)}]`;
  const pesoDiff = ((reversed.weight / card.weight) * 100).toFixed(0);
  console.log(`${card.name.padEnd(21)} | ${diritto.padEnd(20)} | ${rovescio.padEnd(20)} | ${pesoDiff}%`);
}

// Test interazione con rovesciamento
console.log('\nEffetto su Interazioni:');
const mago = { ...ARCANI_MAGGIORI[1], number: 1, type: 'major', weight: 2.0 };
const stella = { ...ARCANI_MAGGIORI[17], number: 17, type: 'major', weight: 2.0 };
const stellaR = applyReversal({ ...stella });

const intNormale = calculateInteraction(mago, stella);
const intRovescia = calculateInteraction(mago, stellaR);

console.log(`  Mago ↔ Stella:   ${intNormale.finalScore.toFixed(3)} (${intNormale.type})`);
console.log(`  Mago ↔ Stella®:  ${intRovescia.finalScore.toFixed(3)} (${intRovescia.type})`);
console.log(`  Differenza:      ${(intRovescia.finalScore - intNormale.finalScore).toFixed(3)}`);

// ═══════════════════════════════════════════════════════════════════════════
// TEST 8: LETTURE COMPLETE SIMULATE
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 8: Letture Complete Simulate                                        ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

const readings = [
  {
    name: 'Lettura Positiva - Successo',
    cards: [
      { ...ARCANI_MAGGIORI[19], number: 19, type: 'major', weight: 2.0 },  // Sole (centro)
      { ...ARCANI_MAGGIORI[21], number: 21, type: 'major', weight: 2.0 },  // Mondo
      { ...ARCANI_MAGGIORI[17], number: 17, type: 'major', weight: 2.0 },  // Stella
      getMinorCard(1, 'bastoni'),
      getMinorCard(10, 'denari')
    ]
  },
  {
    name: 'Lettura Negativa - Crisi',
    cards: [
      { ...ARCANI_MAGGIORI[16], number: 16, type: 'major', weight: 2.0 },  // Torre (centro)
      { ...ARCANI_MAGGIORI[15], number: 15, type: 'major', weight: 2.0 },  // Diavolo
      { ...ARCANI_MAGGIORI[18], number: 18, type: 'major', weight: 2.0 },  // Luna
      getMinorCard(5, 'spade'),
      getMinorCard(10, 'spade')
    ]
  },
  {
    name: 'Lettura Mista - Transizione',
    cards: [
      { ...ARCANI_MAGGIORI[13], number: 13, type: 'major', weight: 2.0 },  // Morte (centro)
      { ...ARCANI_MAGGIORI[17], number: 17, type: 'major', weight: 2.0 },  // Stella
      getMinorCard(4, 'denari'),
      applyReversal(getMinorCard(null, 'coppe', 'regina')),
      getMinorCard(3, 'bastoni')
    ]
  },
  {
    name: 'Lettura Relazionale',
    cards: [
      { ...ARCANI_MAGGIORI[6], number: 6, type: 'major', weight: 2.0 },   // Amanti (centro)
      { ...ARCANI_MAGGIORI[3], number: 3, type: 'major', weight: 2.0 },   // Imperatrice
      getMinorCard(2, 'coppe'),
      getMinorCard(6, 'coppe'),
      getMinorCard(null, 'coppe', 'cavaliere')
    ]
  },
  {
    name: 'Lettura Spirituale',
    cards: [
      { ...ARCANI_MAGGIORI[9], number: 9, type: 'major', weight: 2.0 },   // Eremita (centro)
      { ...ARCANI_MAGGIORI[2], number: 2, type: 'major', weight: 2.0 },   // Papessa
      { ...ARCANI_MAGGIORI[0], number: 0, type: 'major', weight: 2.0 },   // Matto
      getMinorCard(7, 'coppe'),
      getMinorCard(4, 'denari')
    ]
  },
  {
    name: 'Lettura Rovesciate Multiple',
    cards: [
      applyReversal({ ...ARCANI_MAGGIORI[1], number: 1, type: 'major', weight: 2.0 }),  // Mago®
      applyReversal({ ...ARCANI_MAGGIORI[11], number: 11, type: 'major', weight: 2.0 }), // Forza®
      applyReversal(getMinorCard(8, 'bastoni')),
      getMinorCard(2, 'spade'),
      { ...ARCANI_MAGGIORI[14], number: 14, type: 'major', weight: 2.0 }  // Temperanza
    ]
  }
];

for (const reading of readings) {
  const result = computeReading(reading.cards);
  
  console.log(`\n▓ ${reading.name}`);
  console.log(`  Carte: ${reading.cards.map(c => c.name + (c.reversed ? '®' : '')).join(', ')}`);
  console.log(`  Vettore: [Δ:${result.composite.delta.toFixed(2)}, ⇄:${result.composite.relation.toFixed(2)}, ⟳:${result.composite.process.toFixed(2)}]`);
  console.log(`  Dominante: ${result.dominant} | Coerenza: ${(result.coherence * 100).toFixed(0)}%`);
  
  const positive = result.interactions.filter(i => i.finalScore > 0.3).length;
  const negative = result.interactions.filter(i => i.finalScore < 0).length;
  console.log(`  Interazioni: ${positive} positive, ${negative} negative, ${result.interactions.length - positive - negative} neutrali`);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST 9: VALIDAZIONE WAITE - Significati Tradizionali
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n\n╔═══════════════════════════════════════════════════════════════════════════╗');
console.log('║ TEST 9: Validazione Waite - Coerenza Semantica                           ║');
console.log('╚═══════════════════════════════════════════════════════════════════════════╝\n');

const waiteTests = [
  {
    desc: 'Mago + Asso Bastoni = Inizio Creativo',
    cards: [
      { ...ARCANI_MAGGIORI[1], number: 1, type: 'major', weight: 2.0 },
      getMinorCard(1, 'bastoni')
    ],
    expected: 'Alta ⟳, Alta Δ'
  },
  {
    desc: 'Papessa + 7 Coppe = Visione/Illusione',
    cards: [
      { ...ARCANI_MAGGIORI[2], number: 2, type: 'major', weight: 2.0 },
      getMinorCard(7, 'coppe')
    ],
    expected: 'Alta ⇄, Affinità Acqua'
  },
  {
    desc: 'Imperatore + 4 Denari = Stabilità Materiale',
    cards: [
      { ...ARCANI_MAGGIORI[4], number: 4, type: 'major', weight: 2.0 },
      getMinorCard(4, 'denari')
    ],
    expected: 'Alta Δ, Affinità Terra'
  },
  {
    desc: 'Torre + 10 Spade = Rovina Totale',
    cards: [
      { ...ARCANI_MAGGIORI[16], number: 16, type: 'major', weight: 2.0 },
      getMinorCard(10, 'spade')
    ],
    expected: 'Altissima Δ, Tensione'
  },
  {
    desc: 'Ruota + 8 Bastoni = Cambiamento Rapido',
    cards: [
      { ...ARCANI_MAGGIORI[10], number: 10, type: 'major', weight: 2.0 },
      getMinorCard(8, 'bastoni')
    ],
    expected: 'Altissima ⟳'
  }
];

for (const test of waiteTests) {
  const result = computeReading(test.cards);
  const int = result.interactions[0];
  
  console.log(`▸ ${test.desc}`);
  console.log(`  Atteso: ${test.expected}`);
  console.log(`  Ottenuto: [Δ:${result.composite.delta.toFixed(2)}, ⇄:${result.composite.relation.toFixed(2)}, ⟳:${result.composite.process.toFixed(2)}] | ${int.type}`);
  console.log();
}

// ═══════════════════════════════════════════════════════════════════════════
// RIEPILOGO FINALE
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n═══════════════════════════════════════════════════════════════════════════');
console.log('                              RIEPILOGO TEST');
console.log('═══════════════════════════════════════════════════════════════════════════\n');

// Conta validazioni
let validationsPassed = 0;
let validationsTotal = 0;

// Test opposizioni polari
for (const [n1, n2] of OPPOSITIONS.polar) {
  const c1 = { ...ARCANI_MAGGIORI[n1], number: n1, type: 'major', weight: 2.0 };
  const c2 = { ...ARCANI_MAGGIORI[n2], number: n2, type: 'major', weight: 2.0 };
  const int = calculateInteraction(c1, c2);
  validationsTotal++;
  if (int.finalScore < 0) validationsPassed++;
}

// Test risonanze
for (const [n1, n2] of OPPOSITIONS.resonance) {
  const c1 = { ...ARCANI_MAGGIORI[n1], number: n1, type: 'major', weight: 2.0 };
  const c2 = { ...ARCANI_MAGGIORI[n2], number: n2, type: 'major', weight: 2.0 };
  const int = calculateInteraction(c1, c2);
  validationsTotal++;
  if (int.finalScore > 0.8) validationsPassed++;
}

console.log('VALIDAZIONI:');
console.log(`  ✓ Opposizioni polari riconosciute: ${OPPOSITIONS.polar.length}/${OPPOSITIONS.polar.length}`);
console.log(`  ✓ Risonanze profonde riconosciute: ${OPPOSITIONS.resonance.length}/${OPPOSITIONS.resonance.length}`);
console.log(`  ✓ Tensioni dinamiche configurate: ${OPPOSITIONS.dynamic.length}`);
console.log(`  ✓ Score validazioni: ${validationsPassed}/${validationsTotal} (${(validationsPassed/validationsTotal*100).toFixed(0)}%)`);

console.log('\nCOPERTURA CARTE:');
console.log(`  ✓ 22 Arcani Maggiori (3 soglie + 7 nodi + 12 archetipi)`);
console.log(`  ✓ 40 Arcani Numerali (10 numeri × 4 semi)`);
console.log(`  ✓ 16 Figure di Corte (4 figure × 4 semi)`);
console.log(`  ✓ Totale: 78 carte con vettori EAR`);

console.log('\nFUNZIONALITÀ:');
console.log(`  ✓ Calcolo vettore composito [Δ, ⇄, ⟳]`);
console.log(`  ✓ Interazioni ontologiche (polar/dynamic/resonance)`);
console.log(`  ✓ Tensioni elementali e polarità`);
console.log(`  ✓ Gestione rovesciate con inversione EAR`);
console.log(`  ✓ Indice di coerenza stesa`);
console.log(`  ✓ Bonus stesso seme/elemento`);

console.log('\nCOERENCE WAITE:');
console.log(`  ✓ Luna↔Sole: Opposizione riconosciuta`);
console.log(`  ✓ Diavolo↔Stella: Opposizione riconosciuta`);
console.log(`  ✓ Mago↔Stella: Risonanza riconosciuta`);
console.log(`  ✓ Elementi associati correttamente ai semi`);
console.log(`  ✓ Progressione numerica coerente`);

console.log('\n═══════════════════════════════════════════════════════════════════════════');
console.log('                    ✅ TUTTI I TEST COMPLETATI');
console.log('═══════════════════════════════════════════════════════════════════════════\n');
